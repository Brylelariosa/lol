package com.outcrop.sync

// Placeholder module -- see app spec S1.10 (optional, off by default).
// Not yet implemented. Exists so the module graph matches the designed
// architecture and the project builds as a whole (settings.gradle.kts
// includes this module; ./gradlew assembleDebug touches every module).
object SyncPlaceholder
