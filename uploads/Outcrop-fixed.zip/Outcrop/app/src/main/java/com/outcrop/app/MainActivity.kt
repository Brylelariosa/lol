package com.outcrop.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.outcrop.app.navigation.OutcropNavHost
import com.outcrop.core.designsystem.OutcropTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            OutcropTheme {
                OutcropNavHost()
            }
        }
    }
}
