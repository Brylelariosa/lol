package com.outcrop.app

import android.app.Application
import com.outcrop.core.aiengine.StrataEngineProvider
import com.outcrop.core.appstorage.OutcropDatabaseProvider
import com.outcrop.core.appstorage.SnapshotStore
import com.outcrop.core.background.UndertowScheduler

class OutcropApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Staged startup (Outcrop spec §8 Cold startup): heavy Strata
        // engine warmup deliberately does NOT happen here. The UI renders
        // an interactive shell first; engine init is kicked off async and
        // the UI observes readiness state. Not yet implemented in this
        // scaffold — this is where that sequencing would be wired in.
        // Restoring the snapshot below is exactly that kind of warmup
        // work done the un-staged way for now: synchronous, on the main
        // thread, before the UI renders. Fine at today's data sizes, but
        // the first thing to move once staged startup is actually built.

        // OutcropDatabaseProvider.init() just constructs the Room builder
        // (no disk I/O yet -- that happens lazily on first query, off the
        // main thread per Room's own defaults), so unlike Strata warmup
        // this is cheap enough to do unconditionally here.
        OutcropDatabaseProvider.init(this)

        // Restore whatever was taught last session -- StrataEngineProvider.engine
        // used to start empty every single launch. See SnapshotStore's doc.
        SnapshotStore.init(this)
        SnapshotStore.load()?.let { snapshot ->
            runCatching { StrataEngineProvider.engine.importData(snapshot) }
        }

        // Re-arming a WorkManager unique periodic request is idempotent
        // (ExistingPeriodicWorkPolicy.KEEP), so it's safe to call this on
        // every process start rather than tracking "did we already
        // schedule this" separately.
        if (UndertowScheduler.isEnabled(this)) {
            UndertowScheduler.schedule(this)
        }
    }
}
