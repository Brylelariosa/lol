package com.outcrop.feature.knowledgegraph

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector2D
import androidx.compose.animation.core.TwoWayConverter
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.outcrop.core.aiengine.GrainType
import com.outcrop.core.aiengine.Tier
import com.outcrop.core.designsystem.LegendRow
import com.outcrop.core.designsystem.OutcropConfidenceScale
import com.outcrop.core.designsystem.OutcropMotion
import com.outcrop.core.designsystem.OutcropPalette
import kotlinx.coroutines.launch

private val OffsetToVector: TwoWayConverter<Offset, AnimationVector2D> = TwoWayConverter(
    convertToVector = { offset -> AnimationVector2D(offset.x, offset.y) },
    convertFromVector = { vector -> Offset(vector.v1, vector.v2) }
)

private const val TAP_RADIUS_DP = 48

/**
 * Visualizes every grain as a subject -> object edge, laid out by
 * ForceLayout and settled with visible spring physics -- the exact use
 * case OutcropMotion.graphNodeSpring() was reserved for (app spec S4.3).
 * Tap a node to see everything connected to it; tap empty space to
 * deselect. This is a genuine custom Canvas visualization, not a chart
 * library -- consistent with the rest of this app's zero-chart-dependency
 * approach, just applied to a harder shape than a bar or histogram.
 */
@Composable
fun KnowledgeGraphScreen(viewModel: KnowledgeGraphViewModel = viewModel()) {
    val data by viewModel.data.collectAsState()
    val selected by viewModel.selected.collectAsState()

    val animatables = remember { mutableStateMapOf<String, Animatable<Offset, AnimationVector2D>>() }
    LaunchedEffect(data) {
        val currentKeys = data.positions.keys
        animatables.keys.filter { it !in currentKeys }.forEach { animatables.remove(it) }
        for ((key, point) in data.positions) {
            val target = Offset(point.x, point.y)
            val existing = animatables[key]
            if (existing == null) {
                animatables[key] = Animatable(target, OffsetToVector)
            } else {
                launch { existing.animateTo(target, animationSpec = OutcropMotion.graphNodeSpring()) }
            }
        }
    }

    // Read fresh every recomposition (including mid-animation frames) so
    // both the Canvas draw pass and the label overlay track live motion.
    val normalized: Map<String, Offset> = data.nodes.associate {
        it.key to (animatables[it.key]?.value ?: Offset(0.5f, 0.5f))
    }

    var canvasSize by remember { mutableStateOf(IntSize.Zero) }

    Column(modifier = Modifier.fillMaxSize()) {
        LegendRow(
            entries = listOf(
                "Fact" to OutcropPalette.StrataBand1,
                "Rule" to OutcropPalette.StrataBand2,
                "Hypothesis" to OutcropPalette.StrataBand3
            ),
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        )

        Box(modifier = Modifier.weight(1f).fillMaxSize()) {
            if (data.nodes.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize().padding(24.dp)) {
                    BasicText(text = "Nothing to graph yet. Ingest something in Teach, then come back.")
                }
            } else {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .onSizeChanged { canvasSize = it }
                        .pointerInput(Unit) {
                            detectTapGestures { tap ->
                                val w = canvasSize.width.toFloat()
                                val h = canvasSize.height.toFloat()
                                if (w <= 0f || h <= 0f) return@detectTapGestures
                                val thresholdPx = TAP_RADIUS_DP.dp.toPx()
                                var bestKey: String? = null
                                var bestDistSq = Float.MAX_VALUE
                                for ((key, anim) in animatables) {
                                    val dx = anim.value.x * w - tap.x
                                    val dy = anim.value.y * h - tap.y
                                    val distSq = dx * dx + dy * dy
                                    if (distSq < bestDistSq) { bestDistSq = distSq; bestKey = key }
                                }
                                if (bestKey != null && bestDistSq <= thresholdPx * thresholdPx) {
                                    viewModel.selectNode(bestKey)
                                } else {
                                    viewModel.selectNode(null)
                                }
                            }
                        }
                ) {
                    val w = size.width
                    val h = size.height

                    data.edges.forEach { edge ->
                        val from = normalized[edge.fromKey] ?: return@forEach
                        val to = normalized[edge.toKey] ?: return@forEach
                        val fromPx = Offset(from.x * w, from.y * h)
                        val toPx = Offset(to.x * w, to.y * h)

                        val touchesSelected = selected != null && (edge.fromKey == selected || edge.toKey == selected)
                        val dimmed = selected != null && !touchesSelected

                        val baseColor = when (edge.type) {
                            GrainType.FACT -> OutcropPalette.StrataBand1
                            GrainType.RULE -> OutcropPalette.StrataBand2
                            GrainType.HYPOTHESIS -> OutcropPalette.StrataBand3
                        }
                        var alpha = (0.35f + 0.65f * edge.confidence.toFloat()).coerceIn(0.15f, 1f)
                        if (edge.tier == Tier.DORMANT) alpha *= 0.35f
                        if (dimmed) alpha *= 0.15f

                        val strokeWidth = if (edge.type == GrainType.RULE) 4.dp.toPx() else 2.dp.toPx()
                        val pathEffect = if (edge.type == GrainType.HYPOTHESIS)
                            PathEffect.dashPathEffect(floatArrayOf(14f, 10f)) else null

                        drawLine(
                            color = baseColor, start = fromPx, end = toPx,
                            strokeWidth = strokeWidth, pathEffect = pathEffect, alpha = alpha
                        )
                    }

                    data.nodes.forEach { node ->
                        val pos = normalized[node.key] ?: return@forEach
                        val center = Offset(pos.x * w, pos.y * h)
                        val degree = data.edges.count { it.fromKey == node.key || it.toKey == node.key }
                        val radius = (6f + degree * 1.5f).coerceAtMost(18f).dp.toPx()
                        val isSelected = node.key == selected

                        val fillColor = when {
                            node.isWildcard -> OutcropPalette.StrataDark
                            isSelected -> OutcropConfidenceScale.High
                            else -> OutcropPalette.Surface
                        }
                        drawCircle(color = fillColor, radius = radius, center = center)
                        if (isSelected) {
                            drawCircle(
                                color = OutcropConfidenceScale.High, radius = radius + 4.dp.toPx(),
                                center = center, style = Stroke(width = 2.dp.toPx())
                            )
                        }
                    }
                }

                if (canvasSize.width > 0) {
                    data.nodes.forEach { node ->
                        val pos = normalized[node.key] ?: return@forEach
                        BasicText(
                            text = node.label,
                            modifier = Modifier.offset {
                                IntOffset(
                                    x = (pos.x * canvasSize.width).toInt() - node.label.length * 3,
                                    y = (pos.y * canvasSize.height).toInt() + 12
                                )
                            }
                        )
                    }
                }
            }
        }

        selected?.let { key ->
            data.nodes.firstOrNull { it.key == key }?.let { node ->
                DetailPanel(
                    node = node,
                    edges = data.edges.filter { it.fromKey == key || it.toKey == key },
                    allNodes = data.nodes
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(OutcropPalette.StrataDark)
                .clickable { viewModel.refresh() }
                .padding(12.dp)
        ) {
            BasicText(text = "Refresh (${data.nodes.size} node(s), ${data.edges.size} edge(s))")
        }
    }
}

@Composable
private fun DetailPanel(node: GraphNode, edges: List<GraphEdge>, allNodes: List<GraphNode>) {
    val labelOf = allNodes.associate { it.key to it.label }
    Column(
        modifier = Modifier.fillMaxWidth().background(OutcropPalette.StrataBand3).padding(12.dp)
    ) {
        BasicText(text = node.label)
        Spacer(modifier = Modifier.height(4.dp))
        edges.forEach { edge ->
            val otherKey = if (edge.fromKey == node.key) edge.toKey else edge.fromKey
            val otherLabel = labelOf[otherKey] ?: otherKey
            val arrow = if (edge.fromKey == node.key) "\u2192" else "\u2190"
            BasicText(
                text = "$arrow ${edge.relation} $otherLabel " +
                    "(conf ${"%.2f".format(edge.confidence)}, ${edge.type})"
            )
        }
    }
}
