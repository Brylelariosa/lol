package com.outcrop.feature.knowledgegraph

import androidx.lifecycle.ViewModel
import com.outcrop.core.aiengine.StrataEngineProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Every distinct subject/object string across all grains becomes a node
 *  (case-insensitive key, first-seen casing kept for display); every
 *  grain becomes one edge. Rule grains (subject == "*") get a single
 *  shared "Any" node rather than one wildcard node per relation, since
 *  they all mean the same thing: "every known subject". */
class KnowledgeGraphViewModel : ViewModel() {
    private val engine = StrataEngineProvider.engine

    private val _data = MutableStateFlow(GraphData())
    val data: StateFlow<GraphData> = _data

    private val _selected = MutableStateFlow<String?>(null)
    val selected: StateFlow<String?> = _selected

    init { refresh() }

    fun refresh() {
        val grains = engine.allGrains()
        val nodesByKey = linkedMapOf<String, GraphNode>()

        fun register(raw: String) {
            val key = raw.lowercase()
            if (!nodesByKey.containsKey(key)) {
                nodesByKey[key] = GraphNode(key = key, label = if (raw == "*") "Any" else raw, isWildcard = raw == "*")
            }
        }

        val edges = grains.map { g ->
            register(g.subject)
            register(g.obj)
            GraphEdge(
                fromKey = g.subject.lowercase(), toKey = g.obj.lowercase(),
                relation = g.relation, type = g.type, tier = g.tier, confidence = g.confidence()
            )
        }

        val nodes = nodesByKey.values.toList()
        val positions = ForceLayout.compute(
            keys = nodes.map { it.key },
            edges = edges.map { it.fromKey to it.toKey }
        )

        _data.value = GraphData(nodes = nodes, positions = positions, edges = edges)
        val currentSelected = _selected.value
        if (currentSelected != null && currentSelected !in nodesByKey.keys) {
            _selected.value = null
        }
    }

    fun selectNode(key: String?) {
        _selected.value = if (_selected.value == key) null else key
    }
}
