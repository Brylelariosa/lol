package com.outcrop.core.background

import android.content.Context

/** Just a handful of scalars -- the enabled toggle, the daily gate that
 *  keeps weatherTick() from double-decaying (see UndertowScheduler's
 *  doc), and last-run bookkeeping for the Settings status readout. Not
 *  worth a Room table for. */
internal class UndertowPrefs(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = prefs.getBoolean(KEY_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_ENABLED, value).apply()

    /** Long.MIN_VALUE (never) rather than 0 (epoch day 0 = 1970-01-01),
     *  so "not ticked yet" can never accidentally equal a real date. */
    var lastTickedEpochDay: Long
        get() = prefs.getLong(KEY_LAST_TICKED_DAY, Long.MIN_VALUE)
        set(value) = prefs.edit().putLong(KEY_LAST_TICKED_DAY, value).apply()

    var lastRunAtMillis: Long
        get() = prefs.getLong(KEY_LAST_RUN_AT, 0L)
        set(value) = prefs.edit().putLong(KEY_LAST_RUN_AT, value).apply()

    var lastEffort: String?
        get() = prefs.getString(KEY_LAST_EFFORT, null)
        set(value) = prefs.edit().putString(KEY_LAST_EFFORT, value).apply()

    private companion object {
        const val PREFS_NAME = "undertow"
        const val KEY_ENABLED = "enabled"
        const val KEY_LAST_TICKED_DAY = "last_ticked_epoch_day"
        const val KEY_LAST_RUN_AT = "last_run_at_millis"
        const val KEY_LAST_EFFORT = "last_effort"
    }
}
