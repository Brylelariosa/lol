package com.outcrop.core.background

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import java.util.concurrent.TimeUnit

enum class UndertowEffort { MINIMAL, STANDARD, FULL }

data class UndertowStatus(
    val enabled: Boolean,
    val lastRunAtMillis: Long,
    val lastEffort: UndertowEffort?
)

/**
 * Graded Undertow Effort Levels (app spec S1.6): a periodic background
 * worker (UndertowWorker) that keeps Strata's decay and rule
 * crystallization current even when Teach isn't open, so "time passing"
 * is real rather than only happening whenever you next visit. Purely
 * local maintenance -- no networking, consistent with this app carrying
 * no INTERNET permission at all.
 *
 * "Graded" is about how much runs each tick, not whether it runs:
 * MINIMAL only checks the once-a-day decay tick, STANDARD adds rule
 * crystallization, FULL (device charging) also re-crystallizes once more
 * to catch same-tick cascades and always persists a snapshot. See
 * UndertowWorker for why the decay tick itself is gated to once per
 * calendar day regardless of how often WorkManager invokes this.
 */
object UndertowScheduler {
    private const val PERIODIC_WORK_NAME = "undertow_periodic"
    private const val RUN_NOW_WORK_NAME = "undertow_run_now"
    private val PERIODIC_INTERVAL = 15L to TimeUnit.MINUTES // WorkManager's own floor for periodic work

    fun schedule(context: Context) {
        val request = PeriodicWorkRequestBuilder<UndertowWorker>(PERIODIC_INTERVAL.first, PERIODIC_INTERVAL.second)
            .setConstraints(Constraints.Builder().setRequiresBatteryNotLow(false).build())
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            PERIODIC_WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, request
        )
    }

    fun cancel(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(PERIODIC_WORK_NAME)
    }

    fun setEnabled(context: Context, enabled: Boolean) {
        UndertowPrefs(context).enabled = enabled
        if (enabled) schedule(context) else cancel(context)
    }

    fun isEnabled(context: Context): Boolean = UndertowPrefs(context).enabled

    fun status(context: Context): UndertowStatus {
        val prefs = UndertowPrefs(context)
        return UndertowStatus(
            enabled = prefs.enabled,
            lastRunAtMillis = prefs.lastRunAtMillis,
            lastEffort = prefs.lastEffort?.let { runCatching { UndertowEffort.valueOf(it) }.getOrNull() }
        )
    }

    /** For a "Run now" button in Settings -- runs once immediately,
     *  bypassing the enabled flag (an explicit tap is its own consent),
     *  without disturbing the periodic schedule. */
    fun runNow(context: Context) {
        val request = OneTimeWorkRequestBuilder<UndertowWorker>()
            .setInputData(workDataOf(UndertowWorker.KEY_FORCE to true))
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            RUN_NOW_WORK_NAME, ExistingWorkPolicy.REPLACE, request
        )
    }
}
