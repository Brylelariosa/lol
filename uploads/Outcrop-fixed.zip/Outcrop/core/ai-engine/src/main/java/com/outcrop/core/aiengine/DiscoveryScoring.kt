package com.outcrop.core.aiengine

/**
 * Presentation-layer scores for Discovery Center (app spec S4.4) --
 * projections computed from data StrataEngine already exposes (allGrains,
 * simulate), not new core-store state, per the same principle the app
 * spec used for these scores originally: no new core subsystem gets
 * introduced just to feed a screen.
 *
 * Deliberately simple, honest proxies for the fuller versions in the
 * Strata V1/V2 design docs -- novelty was originally centroid distance in
 * TRE-cluster space; here it's max pairwise resonance similarity, since
 * this reference implementation doesn't have real centroid clustering.
 * surprise was originally continuous (Predictive Redundancy, V2 S4.5);
 * here it's binary (does this diverge from what the source rule predicts,
 * yes or no). Both are real, computed values -- just simpler ones.
 */
object DiscoveryScoring {

    /** 1 - (highest similarity to any other stored grain). High = doesn't
     *  closely resemble anything else known yet. */
    fun novelty(hypothesis: Grain, allGrains: List<Grain>): Double {
        val others = allGrains.filter { it.id != hypothesis.id }
        if (others.isEmpty()) return 1.0
        val maxSim = others.maxOf { Resonance.similarity(it.signature, hypothesis.signature) }
        return (1.0 - maxSim).coerceIn(0.0, 1.0)
    }

    /** 1 if this hypothesis's object diverges from what its own source
     *  rule would currently predict; 0 if it agrees. Hypotheses generated
     *  by generateHypotheses() are rule-consistent by construction, so
     *  this will usually read 0 for them today -- an honest limitation,
     *  not a hidden one. It becomes more discriminating once hypotheses
     *  can come from other sources (e.g. a real Fissure/query-gap
     *  mechanism), which isn't built yet. */
    fun surprise(hypothesis: Grain, engine: StrataEngine): Double {
        val predicted = engine.simulate(hypothesis.subject, hypothesis.relation) ?: return 0.0
        return if (predicted.obj.equals(hypothesis.obj, ignoreCase = true)) 0.0 else 1.0
    }

    /** Simple average -- not a sophisticated formula, just a single number
     *  to sort a list by. */
    fun discoveryScore(novelty: Double, surprise: Double): Double = (novelty + surprise) / 2.0

    /** The "why does this hypothesis exist" explanation the app spec
     *  requires (S4.4) -- looks up the source rule via derivedFromRuleId. */
    fun reasonFor(hypothesis: Grain, allGrains: List<Grain>): String {
        val rule = allGrains.firstOrNull { it.id == hypothesis.derivedFromRuleId }
            ?: return "No source rule found."
        return "Other known subjects all ${rule.relation} ${rule.obj} " +
            "(seen ${rule.alpha.toInt()} times, conf ${"%.2f".format(rule.confidence())}) -- " +
            "${hypothesis.subject} is known but hasn't confirmed this yet."
    }
}
