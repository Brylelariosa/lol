package com.outcrop.core.aiengine

import java.time.LocalDate
import kotlin.math.exp

private const val MERGE_THRESHOLD = 0.55
private const val CEMENT_CONFIDENCE = 0.75
private const val MIN_EVIDENCE = 3.0
private const val CORRECTION_AUTHORITY = 3.0
private const val DORMANT_FLOOR = 0.05
private const val MIN_RULE_INSTANCES = 3
private const val MAX_EVENTS = 200

/**
 * The real Strata learning loop, in-memory. This logic was written and
 * verified as a Java port first (compiled and run outside Android -- no
 * Kotlin toolchain was available to test this file directly) before being
 * translated here; the translation preserves that verified behavior
 * rather than introducing new untested logic in a less forgiving runtime.
 *
 * Known simplifications vs the full Strata V1/V2 spec:
 *  - In-memory only. No mmap/tiered binary storage (V1 S6) yet.
 *  - crystallize() finds single-relation majority-object rules, not the
 *    full cross-relation Category Induction (V2 S4.4).
 *  - simulate() does single-hop rule application, not bounded multi-hop
 *    frontier expansion (V2 S4.8).
 *  - generateHypotheses() proposes a hypothesis for every known subject
 *    missing a newly-crystallized relation -- a simple, honest version of
 *    proactive discovery, not the full structural Curiosity Sweep (V2 S4.9).
 *  - No Twin-Axis Placement, Undertow scheduling, Combinator Evolution,
 *    or Fault Attribution yet -- those remain design, not code, for now.
 */
class StrataStore {
    private val grains = linkedMapOf<Int, Grain>()
    private var nextId = 1
    private val eventLog = mutableListOf<LearningEvent>()

    /** Gates generateHypotheses() below -- backs the Settings screen's
     *  "Discovery" toggle. */
    var hypothesesEnabled: Boolean = true

    fun allGrains(): List<Grain> = grains.values.toList()

    /** Clears every grain and the event log -- backs Diagnostics' "reset
     *  memory" action. */
    fun clear() {
        grains.clear()
        nextId = 1
        eventLog.clear()
    }

    /** Plain-text snapshot -- see PersistenceCodec for the format and why
     *  it's hand-rolled rather than JSON. */
    fun exportData(): String = PersistenceCodec.encode(grains.values.toList())

    /** Replaces the current store entirely rather than merging -- merging
     *  would need real ID-conflict reconciliation, which isn't built yet. */
    fun importData(text: String) {
        clear()
        val restored = PersistenceCodec.decode(text)
        for (g in restored) grains[g.id] = g
        nextId = (restored.maxOfOrNull { it.id } ?: 0) + 1
    }

    /** Most recent first -- backs the Learning Dashboard (app spec S4.6). */
    fun recentEvents(limit: Int = 50): List<LearningEvent> = eventLog.takeLast(limit).reversed()

    private fun recordEvent(event: LearningEvent) {
        eventLog.add(event)
        if (eventLog.size > MAX_EVENTS) eventLog.removeAt(0)
    }

    fun ingest(subject: String, relation: String, obj: String, authorityWeight: Double = 1.0): IngestResult {
        val sig = Resonance.encode(subject, relation, obj)
        val today = LocalDate.now().toEpochDay()

        // Primary match: EXACT (subject, relation) identity -- ground truth,
        // not an estimate, so it always qualifies as a reinforce/arbitrate
        // candidate regardless of resonance similarity.
        val exactMatch = grains.values.firstOrNull {
            it.subject.equals(subject, ignoreCase = true) && it.relation.equals(relation, ignoreCase = true)
        }

        if (exactMatch != null) {
            return if (exactMatch.obj.equals(obj, ignoreCase = true)) {
                reinforce(exactMatch, authorityWeight, today)
                IngestResult.Reinforced(exactMatch)
            } else {
                arbitrate(exactMatch, subject, relation, obj, sig, authorityWeight, today)
            }
        }

        // Secondary match: fuzzy resonance similarity, for near-duplicates
        // when subject/relation strings aren't identical.
        val best = grains.values.maxByOrNull { Resonance.similarity(it.signature, sig) }
        if (best != null && Resonance.similarity(best.signature, sig) > MERGE_THRESHOLD &&
            best.subject.equals(subject, ignoreCase = true) && best.obj.equals(obj, ignoreCase = true)
        ) {
            reinforce(best, authorityWeight, today)
            return IngestResult.Reinforced(best)
        }

        val grain = Grain(
            id = nextId++, subject = subject, relation = relation, obj = obj,
            lastTouchedEpochDay = today, signature = sig
        )
        grain.touchedDays.add(today)
        grains[grain.id] = grain
        recordEvent(LearningEvent.Learned(System.currentTimeMillis(), subject, relation, obj, grain.confidence()))
        return IngestResult.Created(grain)
    }

    /** Promotes a confirmed Hypothesis to a real Fact -- reinforce() is
     *  only ever called from ingest(), i.e. because a real observation
     *  matched an existing grain, so seeing type == HYPOTHESIS here always
     *  means direct confirmation, not another guess. */
    private fun reinforce(grain: Grain, weight: Double, today: Long) {
        val wasHypothesis = grain.type == GrainType.HYPOTHESIS
        grain.alpha += weight
        grain.vitality = minOf(1.0, grain.vitality + 0.2)
        grain.lastTouchedEpochDay = today
        grain.touchedDays.add(today)
        if (wasHypothesis) {
            grain.type = GrainType.FACT
            recordEvent(
                LearningEvent.HypothesisConfirmed(System.currentTimeMillis(), grain.subject, grain.relation, grain.obj)
            )
        }
        if (grain.tier == Tier.SEED && meetsCementation(grain)) grain.tier = Tier.LATTICE
        recordEvent(
            LearningEvent.Reinforced(
                System.currentTimeMillis(), grain.subject, grain.relation, grain.obj, grain.confidence()
            )
        )
    }

    /** Requires evidence spread across >=2 distinct days on purpose, so one
     *  enthusiastic session can't over-commit a fact (Strata V1 S4). */
    private fun meetsCementation(grain: Grain): Boolean =
        grain.confidence() >= CEMENT_CONFIDENCE &&
            grain.touchedDays.size >= 2 &&
            (grain.alpha + grain.beta) >= MIN_EVIDENCE

    private fun arbitrate(
        existing: Grain, subject: String, relation: String, obj: String,
        sig: TritVector, weight: Double, today: Long
    ): IngestResult {
        return if (weight >= CORRECTION_AUTHORITY) {
            existing.beta += weight
            val challenger = Grain(
                id = nextId++, subject = subject, relation = relation, obj = obj,
                alpha = weight, lastTouchedEpochDay = today, signature = sig
            )
            challenger.touchedDays.add(today)
            grains[challenger.id] = challenger
            recordEvent(LearningEvent.Disputed(System.currentTimeMillis(), subject, relation, resolved = true))
            IngestResult.Disputed(existing, challenger, resolved = true)
        } else {
            existing.beta += weight * 0.5
            recordEvent(LearningEvent.Disputed(System.currentTimeMillis(), subject, relation, resolved = false))
            IngestResult.Disputed(existing, null, resolved = false)
        }
    }

    /** Keyword-overlap x confidence ranking -- NOT semantic search. */
    fun query(text: String, k: Int = 5): List<Grain> {
        val tokens = text.lowercase().split(Regex("\\W+")).filter { it.length > 2 }
        return grains.values
            .filter { it.tier != Tier.DORMANT }
            .map { grain ->
                val haystack = "${grain.subject} ${grain.relation} ${grain.obj}".lowercase()
                val matches = tokens.count { haystack.contains(it) }
                grain to matches * grain.confidence()
            }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
            .take(k)
            .map { it.first }
    }

    /** Two-stage decay -- crossing DORMANT_FLOOR moves a grain to
     *  Tier.DORMANT rather than deleting it outright (Strata V1 S9).
     *  wasDormant guards against re-recording the same transition every
     *  subsequent tick. */
    fun weatherTick() {
        val today = LocalDate.now().toEpochDay()
        for (g in grains.values) {
            val wasDormant = g.tier == Tier.DORMANT
            val age = today - g.lastTouchedEpochDay
            val decay = if (g.tier == Tier.LATTICE) 0.02 else 0.08
            g.vitality *= exp(-decay * age)
            if (g.vitality < DORMANT_FLOOR && !wasDormant) {
                g.tier = Tier.DORMANT
                recordEvent(LearningEvent.WentDormant(System.currentTimeMillis(), g.subject, g.relation, g.obj))
            }
        }
    }

    /** Simplified rule induction: within one relation, if enough distinct
     *  subjects confidently share the same object, propose a rule. Guards
     *  against minting a duplicate rule on every call -- crystallize() can
     *  run many times as facts accumulate (TeachViewModel calls it after
     *  every message), and without this check it would create a new "*
     *  chases ball"-style rule on every single call once the underlying
     *  facts qualify, not just the first time. Found while adding
     *  hypothesis generation below, which would have compounded it. */
    fun crystallize(): List<Grain> {
        val newRules = mutableListOf<Grain>()
        val byRelation = grains.values.filter { it.type == GrainType.FACT }.groupBy { it.relation }
        for ((relation, members) in byRelation) {
            val (topObject, group) = members.groupBy { it.obj }.maxByOrNull { it.value.size } ?: continue
            if (group.size < MIN_RULE_INSTANCES || !group.all { it.confidence() > 0.6 }) continue

            val alreadyExists = grains.values.any {
                it.type == GrainType.RULE && it.relation.equals(relation, ignoreCase = true) &&
                    it.obj.equals(topObject, ignoreCase = true)
            }
            if (alreadyExists) continue

            val today = LocalDate.now().toEpochDay()
            val rule = Grain(
                id = nextId++, subject = "*", relation = relation, obj = topObject,
                alpha = group.size.toDouble(), beta = 1.0,
                lastTouchedEpochDay = today, signature = Resonance.encode("*", relation, topObject),
                type = GrainType.RULE, tier = Tier.LATTICE
            )
            rule.touchedDays.add(today)
            grains[rule.id] = rule
            newRules.add(rule)
            recordEvent(
                LearningEvent.Crystallized(System.currentTimeMillis(), relation, topObject, group.size, rule.confidence())
            )
            if (hypothesesEnabled) generateHypotheses(rule)
        }
        return newRules
    }

    /** For a freshly-crystallized rule, proposes a persistent Hypothesis
     *  Grain for every other known subject that doesn't yet have a fact
     *  (or an existing hypothesis) for that relation. Backs Discovery
     *  Center (app spec S4.4) -- a simple, honest version of proactive
     *  discovery, not the full structural Curiosity Sweep from V2 S4.9. */
    private fun generateHypotheses(rule: Grain) {
        val knownSubjects = grains.values.filter { it.type == GrainType.FACT }.map { it.subject }.distinct()
        for (subject in knownSubjects) {
            if (subject == "*") continue
            val alreadyHasSomething = grains.values.any {
                it.subject.equals(subject, ignoreCase = true) && it.relation.equals(rule.relation, ignoreCase = true)
            }
            if (alreadyHasSomething) continue

            val conf = rule.confidence()
            val today = LocalDate.now().toEpochDay()
            val hypothesis = Grain(
                id = nextId++, subject = subject, relation = rule.relation, obj = rule.obj,
                alpha = conf, beta = 1 - conf, lastTouchedEpochDay = today,
                signature = Resonance.encode(subject, rule.relation, rule.obj),
                type = GrainType.HYPOTHESIS, tier = Tier.SEED, derivedFromRuleId = rule.id
            )
            grains[hypothesis.id] = hypothesis
            recordEvent(
                LearningEvent.Hypothesized(System.currentTimeMillis(), subject, rule.relation, rule.obj)
            )
        }
    }

    /** Single-hop rule application. Returns a DERIVED grain, marked
     *  GrainType.HYPOTHESIS with derivedFromRuleId set -- never silently
     *  conflated with an observed fact. Real bounded multi-hop frontier
     *  expansion is not implemented in this reference pass. */
    fun simulate(subject: String, relation: String): Grain? {
        val rule = grains.values.firstOrNull {
            it.type == GrainType.RULE && it.relation.equals(relation, ignoreCase = true) &&
                (it.subject == "*" || it.subject.equals(subject, ignoreCase = true))
        } ?: return null

        val conf = rule.confidence()
        return Grain(
            id = -1, subject = subject, relation = relation, obj = rule.obj,
            alpha = conf, beta = 1 - conf,
            lastTouchedEpochDay = LocalDate.now().toEpochDay(), signature = rule.signature,
            type = GrainType.HYPOTHESIS, tier = Tier.SEED, derivedFromRuleId = rule.id
        )
    }
}
