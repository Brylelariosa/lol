package com.outcrop.core.aiengine

import kotlin.random.Random

/**
 * Ternary Resonance Encoding, simplified (Strata V1 S8). Real spec: 2048
 * trits packed at 2 bits/dim. This reference implementation uses 512
 * unpacked trits {-1, 0, 1} for a fast, easy-to-verify demo.
 *
 * bind/bundle are standard hyperdimensional-computing role-filler binding
 * and majority-superposition operations (Kanerva; Plate) -- not novel,
 * used here exactly as described in the Strata design docs.
 */
private const val VECTOR_DIM = 512

object Resonance {
    fun symbolHV(seed: Int): TritVector {
        val rnd = Random(seed)
        return ByteArray(VECTOR_DIM) { (rnd.nextInt(3) - 1).toByte() }
    }

    fun bind(a: TritVector, b: TritVector): TritVector =
        ByteArray(VECTOR_DIM) { i -> (a[i] * b[i]).toByte() }

    fun bundle(vectors: List<TritVector>): TritVector = ByteArray(VECTOR_DIM) { i ->
        val sum = vectors.sumOf { it[i].toInt() }
        (if (sum > 0) 1 else if (sum < 0) -1 else 0).toByte()
    }

    fun similarity(a: TritVector, b: TritVector): Double {
        var dot = 0
        for (i in 0 until VECTOR_DIM) dot += a[i] * b[i]
        return dot.toDouble() / VECTOR_DIM
    }

    /** Deterministic: the same (subject, relation, obj) always encodes to
     *  the same signature, seeded off each string's hash. This supports
     *  structural similarity between triples -- it is NOT a semantic text
     *  embedding, and shouldn't be read as one. */
    fun encode(subject: String, relation: String, obj: String): TritVector {
        val vs = symbolHV(subject.lowercase().hashCode())
        val vr = symbolHV(relation.lowercase().hashCode())
        val vo = symbolHV(obj.lowercase().hashCode())
        return bundle(listOf(vs, bind(vr, vo)))
    }
}
