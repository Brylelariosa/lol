package com.outcrop.core.aiengine

/**
 * Hand-rolled, dependency-free grain serialization -- no JSON library
 * added just for this. Uses the ASCII unit separator (0x1F) as a field
 * delimiter specifically because it can never appear in normal typed
 * text, so no escaping logic is needed at all.
 *
 * Verified as a Java port first against a deliberate trailing-empty-field
 * case (derivedFromRuleId is often absent) before being translated here.
 * That's why derivedFromRuleId is encoded as -1 rather than an empty
 * string: Kotlin's String.split() and Java's regex-based split() don't
 * necessarily agree on whether a trailing empty field survives, so the
 * format avoids depending on that distinction at all rather than
 * trusting it either way.
 *
 * The stored signature vector is deliberately NOT part of this format --
 * Resonance.encode() is a pure, deterministic function of (subject,
 * relation, obj), so it's cheaper and just as correct to recompute it on
 * decode than to serialize 512 bytes per grain.
 */
object PersistenceCodec {
    private const val FIELD_SEP = "\u001F"
    private const val DAY_SEP = ","
    private const val NO_RULE_ID = -1

    fun encode(grains: List<Grain>): String =
        grains.joinToString("\n") { g ->
            listOf(
                g.id, g.subject, g.relation, g.obj,
                g.alpha, g.beta, g.vitality, g.lastTouchedEpochDay,
                g.touchedDays.joinToString(DAY_SEP),
                g.tier.name, g.type.name,
                g.derivedFromRuleId ?: NO_RULE_ID
            ).joinToString(FIELD_SEP)
        }

    fun decode(text: String): List<Grain> {
        if (text.isBlank()) return emptyList()
        return text.lines().filter { it.isNotBlank() }.map { line ->
            val f = line.split(FIELD_SEP)
            val subject = f[1]
            val relation = f[2]
            val obj = f[3]
            val ruleId = f[11].toInt()
            Grain(
                id = f[0].toInt(), subject = subject, relation = relation, obj = obj,
                alpha = f[4].toDouble(), beta = f[5].toDouble(), vitality = f[6].toDouble(),
                lastTouchedEpochDay = f[7].toLong(),
                touchedDays = f[8].split(DAY_SEP).filter { it.isNotBlank() }.map { it.toLong() }.toMutableSet(),
                signature = Resonance.encode(subject, relation, obj),
                tier = Tier.valueOf(f[9]),
                type = GrainType.valueOf(f[10]),
                derivedFromRuleId = if (ruleId == NO_RULE_ID) null else ruleId
            )
        }
    }
}
