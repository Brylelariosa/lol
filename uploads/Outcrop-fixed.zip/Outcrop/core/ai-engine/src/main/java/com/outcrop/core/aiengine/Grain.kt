package com.outcrop.core.aiengine

/** A grain's Resonance Signature -- currently a fixed-length trit array,
 *  see Resonance.kt. Real Strata (V1 S6) packs this at 2 bits/trit; this
 *  reference implementation keeps it as a plain ByteArray for clarity. */
typealias TritVector = ByteArray

enum class Tier { SEED, LATTICE, DORMANT }
enum class GrainType { FACT, RULE, HYPOTHESIS }

/**
 * The atomic unit of stored knowledge (Strata V1 S6). This reference
 * implementation keeps it as a plain Kotlin object in memory -- the real
 * spec's fixed-size binary record / mmap layout is not implemented here.
 */
data class Grain(
    val id: Int,
    val subject: String,
    val relation: String,
    val obj: String,
    var alpha: Double = 1.0,
    var beta: Double = 1.0,
    var vitality: Double = 1.0,
    var lastTouchedEpochDay: Long,
    val touchedDays: MutableSet<Long> = mutableSetOf(),
    var tier: Tier = Tier.SEED,
    val signature: TritVector,
    var type: GrainType = GrainType.FACT,
    var derivedFromRuleId: Int? = null
) {
    /** Bayesian Beta-mean confidence (Strata V1 S10). */
    fun confidence(): Double = alpha / (alpha + beta)
}

/** Result of StrataStore.ingest() -- every branch is a real, distinct
 *  outcome, not a boolean success flag, so callers can be transparent
 *  about what actually happened (app spec's "everything should be
 *  transparent" learning-experience requirement). */
sealed class IngestResult {
    data class Created(val grain: Grain) : IngestResult()
    data class Reinforced(val grain: Grain) : IngestResult()
    data class Disputed(val existing: Grain, val challenger: Grain?, val resolved: Boolean) : IngestResult()
}
