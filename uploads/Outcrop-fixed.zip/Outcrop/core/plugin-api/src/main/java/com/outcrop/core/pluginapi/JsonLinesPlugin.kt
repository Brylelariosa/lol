package com.outcrop.core.pluginapi

/** One flat {"subject":...,"relation":...,"object":...} object per line.
 *  Hand-rolled on purpose -- this app doesn't pull in a JSON library
 *  anywhere else (see PersistenceCodec), and the shape here is fixed and
 *  flat enough that a real parser would be overkill for what's really
 *  three string fields with escaping. */
private object JsonLinesFormat {
    fun parse(text: String): List<PluginTriple> =
        text.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .mapNotNull { line ->
                val subject = field(line, "subject") ?: return@mapNotNull null
                val relation = field(line, "relation") ?: return@mapNotNull null
                val obj = field(line, "object") ?: return@mapNotNull null
                PluginTriple(subject, relation, obj)
            }
            .toList()

    fun render(triples: List<PluginTriple>): String =
        triples.joinToString("\n") { t ->
            "{\"subject\":${quote(t.subject)},\"relation\":${quote(t.relation)},\"object\":${quote(t.obj)}}"
        }

    private fun field(line: String, key: String): String? {
        val marker = "\"$key\""
        val keyIndex = line.indexOf(marker)
        if (keyIndex < 0) return null
        var i = keyIndex + marker.length
        while (i < line.length && (line[i] == ':' || line[i].isWhitespace())) i++
        if (i >= line.length || line[i] != '"') return null
        i++
        val sb = StringBuilder()
        while (i < line.length && line[i] != '"') {
            if (line[i] == '\\' && i + 1 < line.length) {
                i++
                when (line[i]) {
                    'n' -> sb.append('\n')
                    't' -> sb.append('\t')
                    '"' -> sb.append('"')
                    '\\' -> sb.append('\\')
                    else -> sb.append(line[i])
                }
            } else {
                sb.append(line[i])
            }
            i++
        }
        return sb.toString()
    }

    private fun quote(value: String): String {
        val sb = StringBuilder("\"")
        for (c in value) {
            when (c) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\n' -> sb.append("\\n")
                '\t' -> sb.append("\\t")
                else -> sb.append(c)
            }
        }
        return sb.append('"').toString()
    }
}

object JsonLinesImporterPlugin : ImporterPlugin {
    override val descriptor = PluginDescriptor(
        id = "builtin.jsonlines.importer", kind = PluginKind.IMPORTER,
        displayName = "JSON Lines", description = "one {subject,relation,object} record per line"
    )
    override fun parse(text: String): List<PluginTriple> = JsonLinesFormat.parse(text)
}

object JsonLinesExporterPlugin : ExporterPlugin {
    override val descriptor = PluginDescriptor(
        id = "builtin.jsonlines.exporter", kind = PluginKind.EXPORTER,
        displayName = "JSON Lines", description = "one {subject,relation,object} record per line"
    )
    override fun render(triples: List<PluginTriple>): String = JsonLinesFormat.render(triples)
}
