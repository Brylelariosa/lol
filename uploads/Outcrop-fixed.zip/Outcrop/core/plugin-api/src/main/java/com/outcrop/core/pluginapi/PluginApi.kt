package com.outcrop.core.pluginapi

/** Mirrors PluginEntity.kind in core/app-storage (kept as a plain String
 *  column there for Room) -- an enum here wherever call sites want type
 *  safety. VISUALIZATION and COMBINATOR_PROCEDURE are modeled for schema
 *  completeness against the app spec (S1.7) but have no implementations
 *  yet: COMBINATOR_PROCEDURE specifically needs Combinator Evolution
 *  itself, which -- per StrataStore.kt -- remains design, not code. */
enum class PluginKind {
    IMPORTER,
    EXPORTER,
    VISUALIZATION,
    COMBINATOR_PROCEDURE
}

data class PluginDescriptor(
    val id: String,
    val kind: PluginKind,
    val displayName: String,
    val description: String
)

/** Not real code-signing -- nothing in this registry is dynamically
 *  loaded, every plugin below is compiled straight into the app, so
 *  there's no untrusted bytecode to verify. This just gives
 *  PluginEntity.sourceHash a real, stable, non-fake value derived from
 *  the plugin's own declared identity, so the column means something
 *  today and the check has somewhere real to grow if a genuine install
 *  pathway is ever added. */
fun PluginDescriptor.sourceHash(): String =
    "$id:$kind:$displayName".hashCode().toUInt().toString(16)

/** One (subject, relation, object) fact -- independent of
 *  core/ai-engine's Grain on purpose. A plugin author should only ever
 *  need to think about the three fields that came from the source file,
 *  not confidence, tier, or vitality; StrataEngine.ingest() is what
 *  turns a PluginTriple into a real Grain. */
data class PluginTriple(val subject: String, val relation: String, val obj: String)

interface ImporterPlugin {
    val descriptor: PluginDescriptor
    fun parse(text: String): List<PluginTriple>
}

interface ExporterPlugin {
    val descriptor: PluginDescriptor
    fun render(triples: List<PluginTriple>): String
}
