package com.outcrop.core.pluginapi

/**
 * Every plugin this build ships with. There is no dynamic install
 * pathway -- no dex/class loading of third-party code, which is a real
 * security boundary this app deliberately doesn't cross -- so "registry"
 * here means the fixed, compiled-in set of importers and exporters, each
 * individually toggleable via PluginEntity.enabled (core/app-storage).
 * Feature code should go through this object rather than referencing
 * CsvImporterPlugin etc. directly, so adding a new built-in plugin is a
 * one-line change here instead of a hunt through every call site.
 */
object PluginRegistry {
    val importers: List<ImporterPlugin> = listOf(CsvImporterPlugin, JsonLinesImporterPlugin)
    val exporters: List<ExporterPlugin> = listOf(CsvExporterPlugin, JsonLinesExporterPlugin)

    val all: List<PluginDescriptor> = importers.map { it.descriptor } + exporters.map { it.descriptor }

    fun importerById(id: String): ImporterPlugin? = importers.firstOrNull { it.descriptor.id == id }
    fun exporterById(id: String): ExporterPlugin? = exporters.firstOrNull { it.descriptor.id == id }
}
