package com.outcrop.core.designsystem

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class NavDestination(val route: String, val label: String)

/** Custom bottom navigation chrome -- no Material3 NavigationBar, per
 *  spec S3. Lives here rather than in :app because navigation chrome is
 *  a reusable design-system concern, not app-shell wiring. */
@Composable
fun OutcropBottomNav(
    destinations: List<NavDestination>,
    currentRoute: String?,
    onNavigate: (String) -> Unit
) {
    Row(modifier = Modifier.fillMaxWidth().background(OutcropPalette.StrataDark)) {
        destinations.forEach { dest ->
            val selected = dest.route == currentRoute
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onNavigate(dest.route) }
                    .background(if (selected) OutcropPalette.StrataBand1 else OutcropPalette.StrataDark)
                    .padding(vertical = 14.dp),
                contentAlignment = Alignment.Center
            ) {
                BasicText(text = dest.label)
            }
        }
    }
}
