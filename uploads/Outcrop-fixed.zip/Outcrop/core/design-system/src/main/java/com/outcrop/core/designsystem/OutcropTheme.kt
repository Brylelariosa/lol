package com.outcrop.core.designsystem

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

data class OutcropColors(
    val background: Color,
    val strataDark: Color
)

val LocalOutcropColors = staticCompositionLocalOf {
    OutcropColors(background = OutcropPalette.Surface, strataDark = OutcropPalette.StrataDark)
}

/**
 * Root theme composable AND root layout container. Deliberately does NOT
 * wrap MaterialTheme -- spec S3: no Material3 widgets anywhere in this app.
 *
 * Also owns system-bar/IME inset handling for the whole app, so every
 * screen gets safe-area padding automatically instead of each one having
 * to remember it individually.
 *
 * FIX (found via a real device screenshot after a CI build): MainActivity
 * calls enableEdgeToEdge() on purpose, for a premium edge-to-edge look --
 * but without inset padding somewhere, content renders underneath the
 * system navigation bar. The Teach composer bar was doing exactly that:
 * present, but physically underneath the nav bar and effectively
 * untappable. systemBarsPadding() + imePadding() here fixes it for every
 * screen at once, including the keyboard-covers-the-input-field case.
 */
@Composable
fun OutcropTheme(content: @Composable () -> Unit) {
    val colors = OutcropColors(
        background = OutcropPalette.Surface,
        strataDark = OutcropPalette.StrataDark
    )
    CompositionLocalProvider(LocalOutcropColors provides colors) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(colors.background)
                .systemBarsPadding()
                .imePadding()
        ) {
            content()
        }
    }
}
