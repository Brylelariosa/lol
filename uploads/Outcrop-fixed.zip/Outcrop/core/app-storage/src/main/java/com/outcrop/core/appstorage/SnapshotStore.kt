package com.outcrop.core.appstorage

import android.content.Context
import java.io.File

/**
 * A generic private-file text blob store. Deliberately knows nothing
 * about StrataEngine or Grain -- it just persists/restores whatever
 * string it's given. The caller is responsible for encoding/decoding
 * that string (StrataEngine.exportData()/importData(), the same
 * PersistenceCodec format Data I/O's "Outcrop native" export already
 * uses). That split keeps this module from needing a dependency on
 * core:ai-engine, and keeps core:ai-engine from needing one on Android
 * Context -- it stays plain, dependency-free Kotlin.
 *
 * Before this, StrataEngineProvider.engine was purely in-memory: closing
 * the app (or the process getting killed) lost every taught grain. init()
 * + load() at app startup and save() after mutations close that gap.
 */
object SnapshotStore {
    private const val FILE_NAME = "strata_snapshot.txt"

    @Volatile private var appContext: Context? = null

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    /** Null if there's no snapshot yet (first run) or it couldn't be read
     *  -- callers should treat both the same as "start empty" rather than
     *  crash on a missing or corrupt file. */
    fun load(): String? =
        try {
            file()?.takeIf { it.exists() }?.readText()
        } catch (e: Exception) {
            null
        }

    /** Best-effort -- a failed save shouldn't crash whatever triggered
     *  it (teaching a fact, importing a file, a background tick). Callers
     *  should invoke this off the main thread (e.g.
     *  viewModelScope.launch(Dispatchers.IO) { ... }); this function
     *  itself does no dispatching. */
    fun save(text: String) {
        try {
            file()?.writeText(text)
        } catch (e: Exception) {
            // Best-effort; next successful save will catch up.
        }
    }

    private fun file(): File? = appContext?.let { File(it.filesDir, FILE_NAME) }
}
