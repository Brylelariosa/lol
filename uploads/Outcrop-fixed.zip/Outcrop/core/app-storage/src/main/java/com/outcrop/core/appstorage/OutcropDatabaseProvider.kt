package com.outcrop.core.appstorage

import android.content.Context
import androidx.room.Room

/**
 * Shared OutcropDatabase instance, mirroring StrataEngineProvider's
 * pattern in core/ai-engine -- one instance for the whole app instead of
 * every screen's ViewModel building its own. Unlike StrataEngine, Room
 * needs a Context to build, so this can't just be a bare `by lazy { }`;
 * OutcropApp.onCreate() calls init(applicationContext) once at startup,
 * before anything touches .database.
 *
 * A proper DI setup (Hilt) is the natural next step here too, same as
 * noted on StrataEngineProvider -- this is the minimal thing that's
 * actually correct today, and the first real use of OutcropDatabase in
 * this codebase (the entities and DAOs existed; nothing had built the
 * database itself yet).
 */
object OutcropDatabaseProvider {
    @Volatile private var instance: OutcropDatabase? = null

    fun init(context: Context) {
        if (instance != null) return
        synchronized(this) {
            if (instance == null) {
                instance = Room.databaseBuilder(
                    context.applicationContext,
                    OutcropDatabase::class.java,
                    "outcrop.db"
                ).build()
            }
        }
    }

    val database: OutcropDatabase
        get() = instance ?: error(
            "OutcropDatabaseProvider.init(context) must run before .database is used " +
                "-- OutcropApp.onCreate() is where that happens."
        )
}
