package com.outcrop.core.appstorage.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "plugin_registry")
data class PluginEntity(
    @PrimaryKey val id: String,
    val kind: String,          // "visualization" | "combinator_procedure" | "importer" | "exporter"
    val enabled: Boolean,
    val sourceHash: String,    // integrity check on install
    // Present only when kind == "combinator_procedure" — a program in the
    // same closed, sandboxed DSL Combinator Evolution uses internally
    // (Strata V2 §4.12 / app spec §1.7).
    val combinatorProgram: String?
)
