package com.outcrop.core.appstorage.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "backups")
data class BackupMetadataEntity(
    @PrimaryKey val id: String,
    val createdAt: Long,
    val strataSnapshotChecksum: String,   // ties to Strata V1 §6 Keystone CRC32
    val encrypted: Boolean,
    val sizeBytes: Long
)
