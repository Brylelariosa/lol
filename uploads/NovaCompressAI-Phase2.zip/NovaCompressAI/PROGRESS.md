# NovaCompress AI — Phase Progress

Tracking status against the full multi-part master spec. Each phase is only
marked done when it is fully generated, internally reviewed, and (where
this sandbox allows) tested — never partially.

## Phase 1 — Core Engine & Minimal Working App — ✅ DONE

- File Analyzer (entropy, histogram, run-length score, repeated-block score)
- 4 compression plugins: Delta, RLE, Huffman, LZ77 (all Python-prototyped
  and round-trip-tested before porting to Kotlin)
- Pipeline engine (chains plugins, reverses correctly)
- 4 hand-crafted genome presets + heuristic selector (behind a
  `GenomeSelector` interface so Phase 2's real Evolution Engine slots in
  without touching callers)
- Verification Engine enforcing compress→decompress→compare→SHA-256 before
  any chunk is trusted
- Full streaming, chunked `.nova` archive format v1 with per-chunk and
  whole-file SHA-256, corruption detection, truncation detection
- Room database for compression history; Dashboard/Compress/Decompress/
  Settings Compose screens
- JUnit tests covering every plugin, pipeline combination, and the archive
  format (including deliberate corruption injection); GitHub Actions CI
  workflow (regenerates the Gradle wrapper, runs tests, assembles a debug
  APK). See the Phase 2 entry below for the corrected, accurate test count.

## Phase 2 — Genome Evolution & Real Benchmark Laboratory — ✅ DONE

- **Real Benchmark Laboratory**: every candidate genome is actually
  compressed, decompressed, timed (`System.nanoTime()`), and verified
  against the real file sample - no estimates, no guessing.
- **Real Evolution Engine**: `MutationEngine` (insert/delete/swap/replace,
  always producing a structurally valid, duplicate-free pipeline) and
  `CrossoverEngine` (single-point recombination of two parent pipelines,
  de-duplicated). Every compression job benchmarks the best 3 known
  genomes plus a fresh mutation and a fresh crossover child, records
  *every* result as knowledge (win or lose), and picks the genuinely
  measured winner.
- **Multidimensional fitness**: `FitnessCalculator` combines ratio with a
  speed penalty, matching the spec's "Compression Ratio x ... x Reliability
  x ... x Battery Score" idea in a simplified, explainable form.
- **Knowledge Database expansion**: new `genomes` and `benchmark_records`
  Room tables. Genomes carry generation, species (classified from which
  plugins they use), lifecycle status (Experimental -> Verified -> Stable
  -> Elite -> Retired), and parent lineage.
- **Fixed a real spec-compliance gap while building this**: the master
  spec explicitly requires rejecting duplicate-plugin pipelines during
  validation, which Phase 1 hadn't enforced. Added the check to
  `PipelineDescriptor`, which required corresponding fixes to
  `MutationEngine` (only insert/replace with an unused plugin) and
  `CrossoverEngine` (de-duplicate overlapping parent plugins) so neither
  could ever attempt to construct an invalid pipeline.
- **New plugin**: Move-To-Front (Python-prototyped and round-trip-tested
  first, like every other plugin). Burrows-Wheeler Transform, Arithmetic
  Coding, and Predictive Coding are deliberately deferred - see the Phase 3
  note below for why.
- **Dashboard now shows real population growth**: "Genomes Discovered" and
  "Benchmarks Run" stat cards, reactively observed from Room.
- `EvolutionEngine`'s logic is tested against an `InMemoryGenomeRepository`
  fake (Room's SQLite backing doesn't work in plain JVM unit tests without
  Robolectric, and the evolutionary logic has nothing to do with SQL) - the
  production `RoomGenomeRepository` implements the same interface.
- 20 net new test methods this phase (19 in new Phase 2 test files, plus 1
  added to Phase 1's `CompressionPipelineTest` for the duplicate-rejection
  fix above) - 50 test methods total across the project now. Phase 1's
  chat summary said 68, which was a miscount; 50 is the accurate, verified
  number, and many methods loop over 14 shared samples internally rather
  than being one-scenario-per-method.

## Phase 3 — More Plugins, Research Dashboard & Visualization — planned next

- Burrows-Wheeler Transform: deliberately deferred out of Phase 2. Building
  it correctly *and* efficiently without a sentinel byte needs a proper
  suffix-array construction (prefix-doubling or SA-IS); a naive O(n^2 log n)
  rotation sort is only safe at toy sizes and degrades badly on exactly the
  repetitive data BWT is meant to help with. This deserves its own
  dedicated, carefully-validated pass rather than being rushed alongside
  the Evolution Engine.
- Arithmetic Coding, Predictive Coding (same treatment: Python-prototyped
  and round-trip-tested before any Kotlin is written)
- Genome Explorer, Species Explorer, Evolution Timeline UI
- Live compression/benchmark graphs (Statistics Center)
- Archive Inspector (view a `.nova` file's metadata/pipeline/genome without
  extracting)

## Phase 4 — Android Runtime Maturity — planned

- WorkManager-driven background research (charging/idle/thermal-aware)
- Thermal Manager, Battery Manager, Memory Manager
- Checkpointing/resume for interrupted compression or research jobs
- Introduce Hilt once WorkManager workers need real DI

## Phase 5 — Archive Format Completion — planned

- Multi-file archives, dictionary section, recovery/repair mode
- Archive Export/Import (`.nova-backup`)
- R8/minification enabled with real keep rules

## Phase 6 — Plugin SDK & External Integration — planned

- Formal Plugin SDK (`PluginContext`, sandboxing, automatic plugin testing
  against the standard corpus: random/repeated/binary/APK/ROM/etc.)
- "Share to compress" / "Open with" external intents (removed from Phase 1's
  manifest deliberately until the handling code exists — see README)

## Phase 7 — Developer Mode & Polish — planned

- Genome/Pipeline/Plugin/Database inspectors, live thread/memory monitors
- Full Settings categories (research budget, thermal/battery limits, plugin
  permissions)
- Tablet/landscape layouts, accessibility pass
