package com.novacompress.ai.core.service

import com.novacompress.ai.core.analyzer.FeatureVector
import com.novacompress.ai.core.analyzer.FileAnalyzer
import com.novacompress.ai.core.archive.ArchiveMetadata
import com.novacompress.ai.core.archive.NovaArchiveWriter
import com.novacompress.ai.core.benchmark.BenchmarkResult
import com.novacompress.ai.core.evolution.EvolutionEngine
import com.novacompress.ai.core.genome.CompressionGenome
import com.novacompress.ai.core.genome.GenomeSelector
import com.novacompress.ai.core.genome.HeuristicGenomeSelector
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

/** The genome ultimately used, with a human-readable explanation for the UI - shape is the same whether it came from the Evolution Engine or the low-power fallback heuristic. */
data class ChosenGenome(
    val genome: CompressionGenome,
    val confidencePercent: Int,
    val explanation: String
)

data class CompressionOutcome(
    val metadata: ArchiveMetadata,
    val chosenGenome: ChosenGenome,
    val features: FeatureVector,
    /** Present when the Evolution Engine (rather than the low-power fallback heuristic) chose the genome. */
    val benchmark: BenchmarkResult? = null
)

/**
 * Orchestrates a full compress job: analyze a sample, choose a genome
 * (via the real [EvolutionEngine] by default, or a fast heuristic when
 * [preferLowPower] is set or no engine is supplied), stream-compress to a
 * temp file with per-chunk verification, and only then hand back a
 * finished archive. Plain Kotlin (no Android framework dependency), so
 * it is directly exercised from JVM unit tests; the UI layer supplies
 * stream factories bound to a real content Uri/File.
 */
class CompressionService(
    private val analyzer: FileAnalyzer = FileAnalyzer(),
    private val evolutionEngine: EvolutionEngine? = null,
    private val fallbackSelector: GenomeSelector = HeuristicGenomeSelector()
) {
    companion object {
        const val ANALYSIS_SAMPLE_BYTES = 1 * 1024 * 1024
    }

    /**
     * @param openStream must support being invoked twice: once to read an
     *   analysis sample, once more for the full compression pass.
     * @param tempDestination where the archive is written. Only considered
     *   final once this function returns successfully; on any failure
     *   (including a chunk failing verification) the temp file is deleted
     *   and the exception is rethrown for the caller to surface to the UI.
     * @param preferLowPower skips the Evolution Engine's multi-candidate
     *   benchmarking (real but relatively CPU-hungry) in favor of the
     *   Phase 1 heuristic's instant, feature-based guess.
     */
    suspend fun compress(
        openStream: () -> InputStream,
        originalFileName: String,
        originalSize: Long,
        tempDestination: File,
        preferLowPower: Boolean = false
    ): CompressionOutcome {
        val sample = openStream().use { readUpTo(it, ANALYSIS_SAMPLE_BYTES) }
        val features = analyzer.analyze(sample)

        var benchmark: BenchmarkResult? = null
        val chosen: ChosenGenome = if (!preferLowPower && evolutionEngine != null) {
            val evolutionResult = evolutionEngine.selectGenomeForCompression(sample)
            benchmark = evolutionResult.benchmark
            ChosenGenome(
                genome = evolutionResult.genome,
                // The Evolution Engine's pick is based on real, measured benchmarks
                // rather than a heuristic guess, so it's shown with high confidence.
                confidencePercent = 95,
                explanation = evolutionResult.explanation
            )
        } else {
            val heuristic = fallbackSelector.select(features, preferLowPower)
            ChosenGenome(
                genome = heuristic.genome,
                confidencePercent = heuristic.confidencePercent,
                explanation = heuristic.explanation
            )
        }

        try {
            openStream().use { input ->
                FileOutputStream(tempDestination).use { output ->
                    val metadata = NovaArchiveWriter.write(
                        output = output,
                        input = input,
                        originalFileName = originalFileName,
                        originalSize = originalSize,
                        genome = chosen.genome
                    )
                    return CompressionOutcome(metadata, chosen, features, benchmark)
                }
            }
        } catch (e: Exception) {
            tempDestination.delete()
            throw e
        }
    }

    private fun readUpTo(input: InputStream, maxBytes: Int): ByteArray {
        val buffer = ByteArray(maxBytes)
        var total = 0
        while (total < maxBytes) {
            val r = input.read(buffer, total, maxBytes - total)
            if (r == -1) break
            total += r
        }
        return if (total == buffer.size) buffer else buffer.copyOf(total)
    }
}
