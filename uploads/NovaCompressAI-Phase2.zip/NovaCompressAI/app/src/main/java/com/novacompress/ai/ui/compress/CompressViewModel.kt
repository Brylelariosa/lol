package com.novacompress.ai.ui.compress

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.novacompress.ai.core.service.CompressionService
import com.novacompress.ai.data.repository.CompressionRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

enum class CompressStage { IDLE, FILE_SELECTED, PROCESSING, SUCCESS, ERROR }

data class CompressUiState(
    val stage: CompressStage = CompressStage.IDLE,
    val fileName: String? = null,
    val fileSize: Long = 0,
    val originalSize: Long = 0,
    val compressedSize: Long = 0,
    val pipelineDescription: String? = null,
    val confidencePercent: Int? = null,
    val explanation: String? = null,
    val errorMessage: String? = null
) {
    val ratio: Double
        get() = if (compressedSize == 0L) 0.0 else originalSize.toDouble() / compressedSize.toDouble()
}

class CompressViewModel(
    private val application: Application,
    private val compressionService: CompressionService,
    private val repository: CompressionRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(CompressUiState())
    val uiState: StateFlow<CompressUiState> = _uiState.asStateFlow()

    fun onFileSelected(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val (name, size) = queryFileNameAndSize(uri)
            _uiState.value = CompressUiState(
                stage = CompressStage.FILE_SELECTED,
                fileName = name,
                fileSize = size
            )
        }
    }

    fun compress(uri: Uri, preferLowPower: Boolean = false) {
        val current = _uiState.value
        val fileName = current.fileName ?: return

        _uiState.value = current.copy(stage = CompressStage.PROCESSING, errorMessage = null)

        viewModelScope.launch(Dispatchers.IO) {
            val tempFile = File(application.cacheDir, "compressing_${System.currentTimeMillis()}.tmp")
            try {
                val outcome = compressionService.compress(
                    openStream = { application.contentResolver.openInputStream(uri)!! },
                    originalFileName = fileName,
                    originalSize = current.fileSize,
                    tempDestination = tempFile,
                    preferLowPower = preferLowPower
                )

                val archivesDir = File(application.getExternalFilesDir(null), "NovaCompressArchives")
                archivesDir.mkdirs()
                val finalFile = File(archivesDir, "$fileName.nova")
                tempFile.copyTo(finalFile, overwrite = true)
                tempFile.delete()

                repository.recordCompression(
                    originalFileName = fileName,
                    originalSize = outcome.metadata.originalSize,
                    compressedSize = finalFile.length(),
                    genomeId = outcome.metadata.genomeId,
                    pipelineDescription = outcome.chosenGenome.genome.pipeline.describe(),
                    archiveFilePath = finalFile.absolutePath
                )

                _uiState.value = CompressUiState(
                    stage = CompressStage.SUCCESS,
                    fileName = fileName,
                    fileSize = current.fileSize,
                    originalSize = outcome.metadata.originalSize,
                    compressedSize = finalFile.length(),
                    pipelineDescription = outcome.chosenGenome.genome.pipeline.describe(),
                    confidencePercent = outcome.chosenGenome.confidencePercent,
                    explanation = outcome.chosenGenome.explanation
                )
            } catch (e: Exception) {
                tempFile.delete()
                _uiState.value = current.copy(
                    stage = CompressStage.ERROR,
                    errorMessage = e.message ?: "Unknown error while compressing."
                )
            }
        }
    }

    fun reset() {
        _uiState.value = CompressUiState()
    }

    private fun queryFileNameAndSize(uri: Uri): Pair<String, Long> {
        var name = "file"
        var size = 0L
        application.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (cursor.moveToFirst()) {
                if (nameIndex >= 0) name = cursor.getString(nameIndex) ?: name
                if (sizeIndex >= 0) size = cursor.getLong(sizeIndex)
            }
        }
        return name to size
    }
}
