package com.novacompress.ai.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface CompressionRecordDao {

    @Insert
    suspend fun insert(record: CompressionRecordEntity): Long

    @Query("SELECT * FROM compression_records ORDER BY createdAtEpochMillis DESC")
    fun observeAll(): Flow<List<CompressionRecordEntity>>

    @Query("SELECT * FROM compression_records ORDER BY createdAtEpochMillis DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<CompressionRecordEntity>>

    @Query("SELECT COUNT(*) FROM compression_records")
    fun observeTotalCount(): Flow<Int>

    @Query("SELECT COALESCE(SUM(originalSize - compressedSize), 0) FROM compression_records")
    fun observeTotalBytesSaved(): Flow<Long>
}
