package com.novacompress.ai.core.evolution

import com.novacompress.ai.core.benchmark.BenchmarkResult
import com.novacompress.ai.core.genome.CompressionGenome

/**
 * Storage for the evolving genome population (the spec's Knowledge
 * Database, as it pertains to genomes and benchmarks). Kept as an
 * interface specifically so [EvolutionEngine]'s selection/mutation logic
 * can be unit tested against a plain in-memory implementation - Room's
 * SQLite backing does not work in plain JVM unit tests without Robolectric,
 * and the evolutionary logic itself has nothing to do with SQL.
 */
interface GenomeRepository {

    /** Inserts the hand-crafted seed presets if the population is empty. No-op otherwise. */
    suspend fun ensureSeeded(seeds: List<CompressionGenome>)

    /** The best-known genomes by historical fitness, excluding retired ones, best first. */
    suspend fun topGenomesByFitness(limit: Int): List<CompressionGenome>

    /** Persists a benchmark result as permanent knowledge and updates the genome's best-known fitness/ratio if improved. */
    suspend fun recordBenchmark(result: BenchmarkResult, fitness: Double)

    /** Total number of distinct genomes ever recorded (seed + evolved). */
    suspend fun genomeCount(): Int

    /** Total number of benchmark experiments ever recorded. */
    suspend fun benchmarkCount(): Int
}
