package com.novacompress.ai.core.common

/**
 * A lightweight result type for engine operations that can fail in ways the
 * caller is expected to handle (corrupted archive, verification failure),
 * as opposed to programmer errors, which still throw exceptions.
 */
sealed class EngineResult<out T> {
    data class Success<T>(val value: T) : EngineResult<T>()
    data class Failure(val message: String, val cause: Throwable? = null) : EngineResult<Nothing>()

    val isSuccess: Boolean get() = this is Success<*>

    fun getOrNull(): T? = when (this) {
        is Success -> value
        is Failure -> null
    }

    inline fun onSuccess(block: (T) -> Unit): EngineResult<T> {
        if (this is Success) block(value)
        return this
    }

    inline fun onFailure(block: (String, Throwable?) -> Unit): EngineResult<T> {
        if (this is Failure) block(message, cause)
        return this
    }
}
