package com.novacompress.ai.core.analyzer

/**
 * Numerical fingerprint of a file (or a representative sample of it),
 * computed once and reused by both genome selection and the UI's "why this
 * pipeline" explanation.
 */
data class FeatureVector(
    val sampledBytes: Int,
    val entropyBitsPerByte: Double,   // 0.0 (perfectly uniform/repetitive) .. 8.0 (maximally random)
    val uniqueByteCount: Int,         // 0..256 distinct byte values observed
    val runLengthScore: Double,       // fraction of sampled bytes that belong to a run of length >= 3
    val repeatedBlockScore: Double,   // fraction of 8-byte blocks that occur more than once in the sample
    val zeroByteFrequency: Double     // fraction of sampled bytes equal to 0x00
) {
    /** True when the sample looks like it is already compressed or encrypted (little point compressing further). */
    val looksAlreadyRandom: Boolean
        get() = entropyBitsPerByte >= 7.5 && repeatedBlockScore < 0.02
}
