package com.novacompress.ai.data.repository

import com.novacompress.ai.core.genome.CompressionGenome
import com.novacompress.ai.core.genome.GenomeStatus
import com.novacompress.ai.core.pipeline.PipelineDescriptor
import com.novacompress.ai.data.database.GenomeEntity

fun CompressionGenome.toEntity(bestFitness: Double, bestRatio: Double, createdAtEpochMillis: Long = System.currentTimeMillis()): GenomeEntity =
    GenomeEntity(
        genomeId = genomeId,
        displayName = displayName,
        pluginIdsCsv = pipeline.pluginIds.joinToString(","),
        rationale = rationale,
        generation = generation,
        species = species,
        status = status.name,
        parentIdsCsv = parentIds.joinToString(","),
        bestFitness = bestFitness,
        bestRatio = bestRatio,
        benchmarkCount = 0,
        createdAtEpochMillis = createdAtEpochMillis
    )

fun GenomeEntity.toDomain(): CompressionGenome = CompressionGenome(
    genomeId = genomeId,
    displayName = displayName,
    pipeline = PipelineDescriptor(pluginIdsCsv.split(",").filter { it.isNotBlank() }),
    rationale = rationale,
    generation = generation,
    species = species,
    status = GenomeStatus.valueOf(status),
    parentIds = if (parentIdsCsv.isBlank()) emptyList() else parentIdsCsv.split(",")
)
