package com.novacompress.ai.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface BenchmarkRecordDao {

    @Insert
    suspend fun insert(record: BenchmarkRecordEntity): Long

    @Query("SELECT COUNT(*) FROM benchmark_records")
    suspend fun count(): Int

    @Query("SELECT COUNT(*) FROM benchmark_records")
    fun observeCount(): Flow<Int>

    @Query("SELECT * FROM benchmark_records WHERE genomeId = :genomeId ORDER BY createdAtEpochMillis DESC")
    suspend fun forGenome(genomeId: String): List<BenchmarkRecordEntity>
}
