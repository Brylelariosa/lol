package com.novacompress.ai.core.analyzer

import kotlin.math.log2

/**
 * Computes a [FeatureVector] from a byte sample.
 *
 * Phase 1 operates on an in-memory sample (the analyzer reads at most
 * [maxSampleBytes] from the front of the file) rather than the whole
 * stream - full-file streaming statistical analysis, adaptive per-chunk
 * classification, and the richer signal set described in the master spec
 * (magic-number sniffing, APK/ROM-specific analyzers, similarity search
 * against the Knowledge Database) are deferred to a later phase.
 */
class FileAnalyzer(private val maxSampleBytes: Int = 1 * 1024 * 1024) {

    fun analyze(data: ByteArray): FeatureVector {
        val sample = if (data.size > maxSampleBytes) data.copyOf(maxSampleBytes) else data
        val n = sample.size

        val histogram = IntArray(256)
        for (b in sample) {
            histogram[b.toInt() and 0xFF]++
        }

        val entropy = shannonEntropy(histogram, n)
        val uniqueCount = histogram.count { it > 0 }
        val runScore = runLengthScore(sample)
        val blockScore = repeatedBlockScore(sample)
        val zeroFreq = if (n == 0) 0.0 else histogram[0].toDouble() / n

        return FeatureVector(
            sampledBytes = n,
            entropyBitsPerByte = entropy,
            uniqueByteCount = uniqueCount,
            runLengthScore = runScore,
            repeatedBlockScore = blockScore,
            zeroByteFrequency = zeroFreq
        )
    }

    private fun shannonEntropy(histogram: IntArray, total: Int): Double {
        if (total == 0) return 0.0
        var entropy = 0.0
        for (count in histogram) {
            if (count == 0) continue
            val p = count.toDouble() / total
            entropy -= p * log2(p)
        }
        return entropy
    }

    private fun runLengthScore(data: ByteArray): Double {
        val n = data.size
        if (n == 0) return 0.0
        var bytesInRuns = 0
        var i = 0
        while (i < n) {
            var j = i + 1
            while (j < n && data[j] == data[i]) j++
            val runLen = j - i
            if (runLen >= 3) bytesInRuns += runLen
            i = j
        }
        return bytesInRuns.toDouble() / n
    }

    private fun repeatedBlockScore(data: ByteArray): Double {
        val blockSize = 8
        val n = data.size
        if (n < blockSize * 2) return 0.0

        val blockCount = n / blockSize
        val seen = HashMap<Long, Int>(blockCount)
        var repeatedBlocks = 0

        for (blockIndex in 0 until blockCount) {
            val offset = blockIndex * blockSize
            var hash = 1125899906842597L // large odd prime seed, standard FNV-ish rolling hash
            for (k in 0 until blockSize) {
                hash = hash * 31 + (data[offset + k].toInt() and 0xFF)
            }
            val priorCount = seen.getOrDefault(hash, 0)
            if (priorCount >= 1) repeatedBlocks++
            seen[hash] = priorCount + 1
        }

        return repeatedBlocks.toDouble() / blockCount
    }
}
