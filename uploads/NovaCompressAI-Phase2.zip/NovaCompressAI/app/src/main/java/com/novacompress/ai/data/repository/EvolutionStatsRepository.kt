package com.novacompress.ai.data.repository

import com.novacompress.ai.data.database.BenchmarkRecordDao
import com.novacompress.ai.data.database.GenomeDao
import kotlinx.coroutines.flow.Flow

/**
 * Read-only view over the evolving genome population, for the Dashboard.
 * Kept separate from [com.novacompress.ai.core.evolution.GenomeRepository]
 * (the Evolution Engine's write-side abstraction over plain suspend
 * functions) since the UI's needs - reactive counts - are a different
 * shape and have nothing to do with the evolutionary logic being testable
 * without Room.
 */
class EvolutionStatsRepository(
    private val genomeDao: GenomeDao,
    private val benchmarkRecordDao: BenchmarkRecordDao
) {
    fun observeGenomeCount(): Flow<Int> = genomeDao.observeCount()
    fun observeBenchmarkCount(): Flow<Int> = benchmarkRecordDao.observeCount()
}
