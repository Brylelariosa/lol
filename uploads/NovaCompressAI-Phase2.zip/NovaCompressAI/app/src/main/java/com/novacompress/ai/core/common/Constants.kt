package com.novacompress.ai.core.common

/**
 * Engine-wide constants. Centralized here so the Archive, Pipeline, and
 * Analyzer subsystems never hardcode magic numbers independently.
 */
object Constants {

    /** Default chunk size used when streaming a file through the compression pipeline. */
    const val DEFAULT_CHUNK_SIZE: Int = 256 * 1024 // 256 KB, per the Nova spec's chunk size options

    /** Nova archive file extension, without the leading dot. */
    const val ARCHIVE_EXTENSION: String = "nova"

    /** Current Nova archive format version. Future versions must remain able to read this. */
    const val ARCHIVE_FORMAT_VERSION: Int = 1

    /** Maximum number of plugin stages allowed in a single compression pipeline. */
    const val MAX_PIPELINE_STAGES: Int = 16

    /** Default maximum number of pipeline stages the Phase 1 genome presets use. */
    const val DEFAULT_PIPELINE_STAGES: Int = 6
}
