package com.novacompress.ai

import android.app.Application
import com.novacompress.ai.di.ServiceLocator

class NovaCompressApplication : Application() {

    lateinit var serviceLocator: ServiceLocator
        private set

    override fun onCreate() {
        super.onCreate()
        serviceLocator = ServiceLocator(this)
    }
}
