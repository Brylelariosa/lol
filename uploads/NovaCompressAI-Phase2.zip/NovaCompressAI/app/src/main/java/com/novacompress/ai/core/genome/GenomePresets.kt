package com.novacompress.ai.core.genome

import com.novacompress.ai.core.pipeline.PipelineDescriptor

/** Fixed seed population of genomes shipped with Phase 1. */
object GenomePresets {

    val BALANCED = CompressionGenome(
        genomeId = "balanced",
        displayName = "Balanced",
        pipeline = PipelineDescriptor.of("delta", "rle", "huffman"),
        rationale = "General-purpose pipeline: smooths gradual byte changes, collapses short runs, then entropy-codes what remains."
    )

    val MAXIMUM_COMPRESSION = CompressionGenome(
        genomeId = "max_compression",
        displayName = "Maximum Compression",
        pipeline = PipelineDescriptor.of("lz77", "huffman"),
        rationale = "Dictionary matching followed by entropy coding; favors files with repeated blocks or dictionary-like structure (text, markup, structured binaries)."
    )

    val FAST = CompressionGenome(
        genomeId = "fast",
        displayName = "Fast Compression",
        pipeline = PipelineDescriptor.of("rle", "huffman"),
        rationale = "Cheap run detection plus entropy coding; lower CPU cost than dictionary matching, still effective on repetitive data."
    )

    val BATTERY_SAVER = CompressionGenome(
        genomeId = "battery_saver",
        displayName = "Battery Saver",
        pipeline = PipelineDescriptor.of("rle"),
        rationale = "Single lightweight pass; lowest CPU/battery cost, most useful when the device is on low battery or the data is already near-random."
    )

    val all: List<CompressionGenome> = listOf(BALANCED, MAXIMUM_COMPRESSION, FAST, BATTERY_SAVER)

    fun byId(id: String): CompressionGenome =
        all.firstOrNull { it.genomeId == id } ?: BALANCED
}
