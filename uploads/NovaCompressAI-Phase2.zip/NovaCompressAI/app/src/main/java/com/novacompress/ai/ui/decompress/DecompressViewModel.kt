package com.novacompress.ai.ui.decompress

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.novacompress.ai.core.service.DecompressionOutcome
import com.novacompress.ai.core.service.DecompressionService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

enum class DecompressStage { IDLE, FILE_SELECTED, PROCESSING, SUCCESS, ERROR }

data class DecompressUiState(
    val stage: DecompressStage = DecompressStage.IDLE,
    val fileName: String? = null,
    val restoredFileName: String? = null,
    val restoredPath: String? = null,
    val errorMessage: String? = null
)

class DecompressViewModel(
    private val application: Application,
    private val decompressionService: DecompressionService
) : ViewModel() {

    private val _uiState = MutableStateFlow(DecompressUiState())
    val uiState: StateFlow<DecompressUiState> = _uiState.asStateFlow()

    fun onFileSelected(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val name = queryFileName(uri)
            _uiState.value = DecompressUiState(stage = DecompressStage.FILE_SELECTED, fileName = name)
        }
    }

    fun decompress(uri: Uri) {
        val current = _uiState.value
        val fileName = current.fileName ?: return
        _uiState.value = current.copy(stage = DecompressStage.PROCESSING, errorMessage = null)

        viewModelScope.launch(Dispatchers.IO) {
            val restoredDir = File(application.getExternalFilesDir(null), "NovaCompressRestored")
            restoredDir.mkdirs()
            val outputName = fileName.removeSuffix(".nova")
            val tempFile = File(application.cacheDir, "decompressing_${System.currentTimeMillis()}.tmp")

            when (
                val result = decompressionService.decompress(
                    openStream = { application.contentResolver.openInputStream(uri)!! },
                    tempDestination = tempFile
                )
            ) {
                is DecompressionOutcome.Success -> {
                    val finalFile = File(restoredDir, outputName)
                    tempFile.copyTo(finalFile, overwrite = true)
                    tempFile.delete()
                    _uiState.value = DecompressUiState(
                        stage = DecompressStage.SUCCESS,
                        fileName = fileName,
                        restoredFileName = result.metadata.originalFileName,
                        restoredPath = finalFile.absolutePath
                    )
                }
                is DecompressionOutcome.Failed -> {
                    _uiState.value = current.copy(
                        stage = DecompressStage.ERROR,
                        errorMessage = result.reason
                    )
                }
            }
        }
    }

    fun reset() {
        _uiState.value = DecompressUiState()
    }

    private fun queryFileName(uri: Uri): String {
        var name = "archive.nova"
        application.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && nameIndex >= 0) {
                name = cursor.getString(nameIndex) ?: name
            }
        }
        return name
    }
}
