package com.novacompress.ai.core.plugins

import com.novacompress.ai.core.common.BinaryIO
import java.io.ByteArrayOutputStream

/**
 * LZSS-style LZ77: a sliding-window match finder (hash chains over 3-byte
 * prefixes) plus a packed-flag literal/match token stream.
 *
 * Stream format:
 *   [originalLength: 4 bytes BE]
 *   repeated groups of:
 *     [flagByte: 1 byte]  (bit i, LSB-first, set => token i in this group is a literal)
 *     up to 8 tokens, each either:
 *       literal:  [byte value]
 *       match:    [distance: 2 bytes BE][length-MIN_MATCH: 1 byte]
 *
 * The final group may contain fewer than 8 tokens; the decoder stops once it
 * has produced exactly originalLength bytes, so unused flag bits at the end
 * are simply ignored.
 */
class Lz77Plugin : CompressionPlugin {

    override val id: String = "lz77"
    override val displayName: String = "LZ77"
    override val version: Int = 1

    private companion object {
        const val WINDOW_SIZE = 32768
        const val MIN_MATCH = 3
        const val MAX_MATCH = 258 // length byte stores (length - MIN_MATCH), 0..255
        const val MAX_CHAIN_TRIES = 64
        const val TOKENS_PER_GROUP = 8
    }

    override fun compress(input: ByteArray): ByteArray {
        val n = input.size
        val out = ByteArrayOutputStream()
        BinaryIO.writeU32(out, n)
        if (n == 0) return out.toByteArray()

        fun byteAt(i: Int): Int = input[i].toInt() and 0xFF
        fun hash3(i: Int): Int = (byteAt(i) shl 16) or (byteAt(i + 1) shl 8) or byteAt(i + 2)

        val head = HashMap<Int, Int>()
        val prev = IntArray(n) { -1 }

        fun insert(i: Int) {
            if (i + MIN_MATCH <= n) {
                val key = hash3(i)
                prev[i] = head[key] ?: -1
                head[key] = i
            }
        }

        fun findMatch(i: Int): Pair<Int, Int> { // (length, distance)
            if (i + MIN_MATCH > n) return 0 to 0
            val key = hash3(i)
            var bestLen = 0
            var bestDist = 0
            var pos = head[key] ?: -1
            var tries = 0
            val maxPossible = minOf(MAX_MATCH, n - i)
            while (pos != -1 && (i - pos) <= WINDOW_SIZE && tries < MAX_CHAIN_TRIES) {
                tries++
                var length = 0
                while (length < maxPossible && input[pos + length] == input[i + length]) {
                    length++
                }
                if (length > bestLen && length >= MIN_MATCH) {
                    bestLen = length
                    bestDist = i - pos
                    if (bestLen == maxPossible) break
                }
                pos = prev[pos]
            }
            return bestLen to bestDist
        }

        // Token group buffer: build one group (<=8 tokens) at a time and flush it.
        var flagByte = 0
        var tokenIndexInGroup = 0
        val body = ByteArrayOutputStream()

        fun flushGroup() {
            out.write(flagByte)
            body.writeTo(out)
            body.reset()
            flagByte = 0
            tokenIndexInGroup = 0
        }

        var i = 0
        while (i < n) {
            val (length, dist) = findMatch(i)
            if (length >= MIN_MATCH) {
                // match token: bit stays 0 (already the default)
                body.write((dist shr 8) and 0xFF)
                body.write(dist and 0xFF)
                body.write(length - MIN_MATCH)
                val end = i + length
                while (i < end) {
                    insert(i)
                    i++
                }
            } else {
                flagByte = flagByte or (1 shl tokenIndexInGroup)
                body.write(byteAt(i))
                insert(i)
                i++
            }
            tokenIndexInGroup++
            if (tokenIndexInGroup == TOKENS_PER_GROUP) {
                flushGroup()
            }
        }
        if (tokenIndexInGroup > 0) {
            flushGroup()
        }

        return out.toByteArray()
    }

    override fun decompress(input: ByteArray): ByteArray {
        val n = BinaryIO.readU32(input, 0)
        var pos = 4
        val out = ByteArray(n)
        var written = 0

        while (written < n) {
            val flagByte = input[pos].toInt() and 0xFF
            pos++
            var gi = 0
            while (gi < TOKENS_PER_GROUP && written < n) {
                val isLiteral = (flagByte shr gi) and 1
                if (isLiteral == 1) {
                    out[written] = input[pos]
                    pos++
                    written++
                } else {
                    val dist = ((input[pos].toInt() and 0xFF) shl 8) or (input[pos + 1].toInt() and 0xFF)
                    val length = (input[pos + 2].toInt() and 0xFF) + MIN_MATCH
                    pos += 3
                    val start = written - dist
                    for (k in 0 until length) {
                        out[written] = out[start + k]
                        written++
                    }
                }
                gi++
            }
        }
        return out
    }
}
