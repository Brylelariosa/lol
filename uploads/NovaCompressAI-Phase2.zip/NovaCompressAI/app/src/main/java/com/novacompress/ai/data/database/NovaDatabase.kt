package com.novacompress.ai.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        CompressionRecordEntity::class,
        GenomeEntity::class,
        BenchmarkRecordEntity::class
    ],
    version = 1,
    // Schema export is off for Phase 1/2 (nothing has shipped to real users
    // yet, so there's no migration to test against a recorded snapshot).
    // Turn this on and wire a room.schemaLocation KSP arg once a version 2
    // migration needs to be tested for real.
    exportSchema = false
)
abstract class NovaDatabase : RoomDatabase() {

    abstract fun compressionRecordDao(): CompressionRecordDao
    abstract fun genomeDao(): GenomeDao
    abstract fun benchmarkRecordDao(): BenchmarkRecordDao

    companion object {
        @Volatile
        private var instance: NovaDatabase? = null

        fun getInstance(context: Context): NovaDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    NovaDatabase::class.java,
                    "nova_knowledge.db"
                ).build().also { instance = it }
            }
    }
}
