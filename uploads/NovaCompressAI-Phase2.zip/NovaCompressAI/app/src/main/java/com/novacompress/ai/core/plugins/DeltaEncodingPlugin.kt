package com.novacompress.ai.core.plugins

/**
 * Delta Encoding: each byte is replaced with the difference (mod 256) from
 * the previous original byte. Excellent as a pre-processing stage ahead of
 * entropy coding for data with smoothly changing byte values (e.g. audio
 * samples, sorted numeric sequences).
 *
 * Format: output length always equals input length. No header needed.
 */
class DeltaEncodingPlugin : CompressionPlugin {

    override val id: String = "delta"
    override val displayName: String = "Delta Encoding"
    override val version: Int = 1

    override fun compress(input: ByteArray): ByteArray {
        val out = ByteArray(input.size)
        var prev = 0
        for (i in input.indices) {
            val current = input[i].toInt() and 0xFF
            out[i] = ((current - prev) and 0xFF).toByte()
            prev = current
        }
        return out
    }

    override fun decompress(input: ByteArray): ByteArray {
        val out = ByteArray(input.size)
        var prev = 0
        for (i in input.indices) {
            val delta = input[i].toInt() and 0xFF
            val value = (delta + prev) and 0xFF
            out[i] = value.toByte()
            prev = value
        }
        return out
    }
}
