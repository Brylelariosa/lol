package com.novacompress.ai.ui.decompress

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.novacompress.ai.R
import com.novacompress.ai.ui.common.novaViewModel

@Composable
fun DecompressScreen() {
    val viewModel: DecompressViewModel = novaViewModel()
    val uiState by viewModel.uiState.collectAsState()
    var selectedUri by remember { mutableStateOf<Uri?>(null) }

    val pickFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedUri = uri
            viewModel.onFileSelected(uri)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(stringResource(R.string.decompress_title), style = MaterialTheme.typography.headlineMedium)

        when (uiState.stage) {
            DecompressStage.IDLE -> {
                Button(onClick = { pickFileLauncher.launch("*/*") }) {
                    Text(stringResource(R.string.decompress_pick_file))
                }
            }

            DecompressStage.FILE_SELECTED -> {
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(uiState.fileName ?: "")
                    }
                }
                Button(onClick = { selectedUri?.let { viewModel.decompress(it) } }) {
                    Text(stringResource(R.string.decompress_start))
                }
                OutlinedButton(onClick = { pickFileLauncher.launch("*/*") }) {
                    Text(stringResource(R.string.decompress_pick_file))
                }
            }

            DecompressStage.PROCESSING -> {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(48.dp))
                    Text(stringResource(R.string.decompress_in_progress))
                }
            }

            DecompressStage.SUCCESS -> {
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            stringResource(R.string.decompress_done, uiState.restoredFileName ?: ""),
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            uiState.restoredPath ?: "",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Button(onClick = {
                    viewModel.reset()
                    selectedUri = null
                }) {
                    Text(stringResource(R.string.decompress_pick_file))
                }
            }

            DecompressStage.ERROR -> {
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            stringResource(R.string.decompress_failed, uiState.errorMessage ?: ""),
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
                Button(onClick = {
                    viewModel.reset()
                    selectedUri = null
                }) {
                    Text(stringResource(R.string.decompress_pick_file))
                }
            }
        }
    }
}
