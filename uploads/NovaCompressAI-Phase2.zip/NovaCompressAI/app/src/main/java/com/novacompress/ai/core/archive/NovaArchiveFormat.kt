package com.novacompress.ai.core.archive

/** Fixed byte sequences that identify a valid .nova archive. */
object NovaArchiveFormat {
    val MAGIC: ByteArray = byteArrayOf('N'.code.toByte(), 'O'.code.toByte(), 'V'.code.toByte(), 'A'.code.toByte())
    val FOOTER_MAGIC: ByteArray = byteArrayOf('E'.code.toByte(), 'N'.code.toByte(), 'D'.code.toByte(), 'N'.code.toByte())

    /** Length of a SHA-256 digest in bytes. */
    const val SHA256_LENGTH = 32
}
