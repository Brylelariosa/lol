package com.novacompress.ai.core.archive

import com.novacompress.ai.core.common.BinaryIO
import com.novacompress.ai.core.common.ByteCursor
import java.io.ByteArrayOutputStream

/**
 * Everything needed to decompress a .nova archive, and everything shown in
 * the (future) Archive Inspector screen. Encoded as simple length-prefixed
 * fields rather than JSON: it is just as self-describing and avoids a JSON
 * library entirely (the platform's org.json throws "not mocked" in plain
 * JVM unit tests unless a second, test-only implementation is added - this
 * format sidesteps that whole class of problem).
 */
data class ArchiveMetadata(
    val originalFileName: String,
    val originalSize: Long,
    val chunkSize: Int,
    val chunkCount: Int,
    val createdAtEpochMillis: Long,
    val genomeId: String,
    val pipelinePluginIds: List<String>
)

object ArchiveMetadataCodec {

    fun encode(metadata: ArchiveMetadata): ByteArray {
        val out = ByteArrayOutputStream()
        BinaryIO.writeString(out, metadata.originalFileName)
        BinaryIO.writeLong(out, metadata.originalSize)
        BinaryIO.writeU32(out, metadata.chunkSize)
        BinaryIO.writeU32(out, metadata.chunkCount)
        BinaryIO.writeLong(out, metadata.createdAtEpochMillis)
        BinaryIO.writeString(out, metadata.genomeId)
        BinaryIO.writeStringList(out, metadata.pipelinePluginIds)
        return out.toByteArray()
    }

    fun decode(bytes: ByteArray): ArchiveMetadata {
        val cursor = ByteCursor(bytes)
        val originalFileName = cursor.readString()
        val originalSize = cursor.readLong()
        val chunkSize = cursor.readU32()
        val chunkCount = cursor.readU32()
        val createdAtEpochMillis = cursor.readLong()
        val genomeId = cursor.readString()
        val pipelinePluginIds = cursor.readStringList()
        return ArchiveMetadata(
            originalFileName = originalFileName,
            originalSize = originalSize,
            chunkSize = chunkSize,
            chunkCount = chunkCount,
            createdAtEpochMillis = createdAtEpochMillis,
            genomeId = genomeId,
            pipelinePluginIds = pipelinePluginIds
        )
    }
}
