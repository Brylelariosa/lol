package com.novacompress.ai.core.plugins

/**
 * A single reversible transform stage in a compression pipeline.
 *
 * Every plugin MUST guarantee: decompress(compress(data)) == data, for any
 * byte array including empty input. This is the foundational safety
 * contract of the entire engine - the AI is only ever allowed to combine
 * and configure plugins that satisfy this contract, never to invent new
 * irreversible transforms.
 *
 * Phase 1 ships a simplified subset of the full Plugin SDK surface
 * described in the master spec (analyze/estimateRatio/estimateRAM/etc. are
 * deferred to the Benchmark Laboratory phase); every plugin here is a
 * complete, real, production implementation of its algorithm.
 */
interface CompressionPlugin {

    /** Stable identifier used in pipeline descriptors and archive metadata. Never changes once shipped. */
    val id: String

    /** Human-readable name shown in the UI (Pipeline Viewer, Genome Explorer). */
    val displayName: String

    /** Plugin version. Bump when the on-disk format this plugin produces changes. */
    val version: Int

    /** Compresses [input]. Must be pure (no shared mutable state between calls). */
    fun compress(input: ByteArray): ByteArray

    /** Reverses [compress]. Must reproduce the original bytes exactly. */
    fun decompress(input: ByteArray): ByteArray
}
