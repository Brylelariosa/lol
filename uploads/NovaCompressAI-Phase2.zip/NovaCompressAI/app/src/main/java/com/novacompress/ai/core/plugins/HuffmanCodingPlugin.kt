package com.novacompress.ai.core.plugins

import java.io.ByteArrayOutputStream
import java.util.PriorityQueue

/**
 * Canonical Huffman coding.
 *
 * Stream format:
 *   [magic: 1 byte]
 *     0 = EMPTY   -> no further data, original input was empty.
 *     1 = SINGLE  -> [symbol: 1 byte][originalLength: 4 bytes BE]
 *                    (only one distinct byte value in the input; storing a
 *                    real Huffman table for a single symbol is meaningless,
 *                    so this is a dedicated fast path)
 *     2 = NORMAL  -> [symbolCount: 2 bytes BE]
 *                    then symbolCount * [symbol: 1 byte][codeLength: 1 byte]
 *                    [originalLength: 4 bytes BE]
 *                    [packed bitstream, MSB-first per byte]
 *
 * Code lengths are canonical: the decoder rebuilds the exact same codes from
 * the (symbol, length) list alone, so the tree topology used while encoding
 * never needs to be stored or replayed.
 */
class HuffmanCodingPlugin : CompressionPlugin {

    override val id: String = "huffman"
    override val displayName: String = "Huffman Coding"
    override val version: Int = 1

    private companion object {
        const val MAGIC_EMPTY = 0
        const val MAGIC_SINGLE = 1
        const val MAGIC_NORMAL = 2
    }

    // --- Tree construction -------------------------------------------------

    private sealed class HuffNode(val freq: Int) {
        class Leaf(freq: Int, val symbol: Int) : HuffNode(freq)
        class Internal(freq: Int, val left: HuffNode, val right: HuffNode) : HuffNode(freq)
    }

    private fun buildCodeLengths(freqs: Map<Int, Int>): Map<Int, Int> {
        val queue = PriorityQueue<HuffNode>(compareBy { it.freq })
        freqs.forEach { (sym, f) -> queue.add(HuffNode.Leaf(f, sym)) }
        while (queue.size > 1) {
            val a = queue.poll()
            val b = queue.poll()
            queue.add(HuffNode.Internal(a.freq + b.freq, a, b))
        }
        val root = queue.poll()
        val lengths = HashMap<Int, Int>()
        fun walk(node: HuffNode, depth: Int) {
            when (node) {
                is HuffNode.Leaf -> lengths[node.symbol] = maxOf(depth, 1)
                is HuffNode.Internal -> {
                    walk(node.left, depth + 1)
                    walk(node.right, depth + 1)
                }
            }
        }
        walk(root, 0)
        return lengths
    }

    private fun canonicalCodes(lengths: Map<Int, Int>): Map<Int, Pair<Int, Int>> {
        val symbolsSorted = lengths.keys.sortedWith(compareBy({ lengths.getValue(it) }, { it }))
        val codes = HashMap<Int, Pair<Int, Int>>()
        var code = 0
        var prevLen = 0
        for (sym in symbolsSorted) {
            val length = lengths.getValue(sym)
            code = code shl (length - prevLen)
            codes[sym] = code to length
            code++
            prevLen = length
        }
        return codes
    }

    // --- Bit I/O -------------------------------------------------------------

    private class BitWriter {
        val out = ByteArrayOutputStream()
        private var cur = 0
        private var nbits = 0
        fun writeBits(value: Int, length: Int) {
            for (i in length - 1 downTo 0) {
                val bit = (value shr i) and 1
                cur = (cur shl 1) or bit
                nbits++
                if (nbits == 8) {
                    out.write(cur and 0xFF)
                    cur = 0
                    nbits = 0
                }
            }
        }
        fun finish(): ByteArray {
            if (nbits > 0) {
                cur = cur shl (8 - nbits)
                out.write(cur and 0xFF)
                nbits = 0
            }
            return out.toByteArray()
        }
    }

    private class BitReader(private val data: ByteArray, private val startOffset: Int) {
        private var bitPos = 0
        fun readBit(): Int {
            val byteIndex = startOffset + bitPos / 8
            val bitIndex = 7 - (bitPos % 8)
            val bit = (data[byteIndex].toInt() shr bitIndex) and 1
            bitPos++
            return bit
        }
    }

    private fun writeU16(out: ByteArrayOutputStream, value: Int) {
        out.write((value shr 8) and 0xFF)
        out.write(value and 0xFF)
    }

    private fun writeU32(out: ByteArrayOutputStream, value: Int) {
        out.write((value shr 24) and 0xFF)
        out.write((value shr 16) and 0xFF)
        out.write((value shr 8) and 0xFF)
        out.write(value and 0xFF)
    }

    private fun readU16(data: ByteArray, offset: Int): Int {
        return ((data[offset].toInt() and 0xFF) shl 8) or (data[offset + 1].toInt() and 0xFF)
    }

    private fun readU32(data: ByteArray, offset: Int): Int {
        return ((data[offset].toInt() and 0xFF) shl 24) or
            ((data[offset + 1].toInt() and 0xFF) shl 16) or
            ((data[offset + 2].toInt() and 0xFF) shl 8) or
            (data[offset + 3].toInt() and 0xFF)
    }

    // --- Public API ------------------------------------------------------

    override fun compress(input: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        val n = input.size
        if (n == 0) {
            out.write(MAGIC_EMPTY)
            return out.toByteArray()
        }

        val freqs = HashMap<Int, Int>()
        for (b in input) {
            val sym = b.toInt() and 0xFF
            freqs[sym] = (freqs[sym] ?: 0) + 1
        }

        if (freqs.size == 1) {
            val sym = freqs.keys.first()
            out.write(MAGIC_SINGLE)
            out.write(sym)
            writeU32(out, n)
            return out.toByteArray()
        }

        val lengths = buildCodeLengths(freqs)
        val codes = canonicalCodes(lengths)
        val symbolsSorted = lengths.keys.sortedWith(compareBy({ lengths.getValue(it) }, { it }))

        out.write(MAGIC_NORMAL)
        writeU16(out, symbolsSorted.size) // 1..256, fits in 2 bytes
        for (sym in symbolsSorted) {
            out.write(sym)
            out.write(lengths.getValue(sym)) // max possible length for <=256 symbols is <=255, fits in 1 byte
        }
        writeU32(out, n)

        val bw = BitWriter()
        for (b in input) {
            val sym = b.toInt() and 0xFF
            val (code, length) = codes.getValue(sym)
            bw.writeBits(code, length)
        }
        out.write(bw.finish())
        return out.toByteArray()
    }

    override fun decompress(input: ByteArray): ByteArray {
        require(input.isNotEmpty()) { "corrupt Huffman stream: empty" }
        val magic = input[0].toInt() and 0xFF
        var pos = 1

        when (magic) {
            MAGIC_EMPTY -> return ByteArray(0)
            MAGIC_SINGLE -> {
                val sym = input[pos].toInt() and 0xFF
                pos += 1
                val n = readU32(input, pos)
                return ByteArray(n) { sym.toByte() }
            }
            MAGIC_NORMAL -> {
                // fall through below
            }
            else -> throw IllegalArgumentException("corrupt Huffman stream: bad magic $magic")
        }

        val symbolCount = readU16(input, pos)
        pos += 2
        val entries = ArrayList<Pair<Int, Int>>(symbolCount) // (symbol, length)
        repeat(symbolCount) {
            val sym = input[pos].toInt() and 0xFF
            pos += 1
            val length = input[pos].toInt() and 0xFF
            pos += 1
            entries.add(sym to length)
        }
        val n = readU32(input, pos)
        pos += 4

        val entriesSorted = entries.sortedWith(compareBy({ it.second }, { it.first }))
        val symbolsList = IntArray(entriesSorted.size) { entriesSorted[it].first }
        val lengthsList = IntArray(entriesSorted.size) { entriesSorted[it].second }
        val maxLen = lengthsList.maxOrNull() ?: 0

        val countPerLen = IntArray(maxLen + 1)
        for (l in lengthsList) countPerLen[l]++

        val firstCode = IntArray(maxLen + 2)
        val firstIndex = IntArray(maxLen + 2)
        var code = 0
        var idx = 0
        for (l in 1..maxLen) {
            firstCode[l] = code
            firstIndex[l] = idx
            code = (code + countPerLen[l]) shl 1
            idx += countPerLen[l]
        }

        val reader = BitReader(input, pos)
        val out = ByteArray(n)
        var written = 0
        while (written < n) {
            var codeVal = 0
            var length = 0
            while (true) {
                val bit = reader.readBit()
                codeVal = (codeVal shl 1) or bit
                length++
                if (length > maxLen) {
                    throw IllegalArgumentException("corrupt Huffman stream: no matching code")
                }
                val cnt = if (length < countPerLen.size) countPerLen[length] else 0
                if (cnt > 0 && codeVal >= firstCode[length] && codeVal < firstCode[length] + cnt) {
                    val symIdx = firstIndex[length] + (codeVal - firstCode[length])
                    out[written] = symbolsList[symIdx].toByte()
                    written++
                    break
                }
            }
        }
        return out
    }
}
