package com.novacompress.ai.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.novacompress.ai.data.database.CompressionRecordEntity
import com.novacompress.ai.data.repository.CompressionRepository
import com.novacompress.ai.data.repository.EvolutionStatsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class DashboardUiState(
    val totalArchives: Int = 0,
    val totalBytesSaved: Long = 0,
    val recentRecords: List<CompressionRecordEntity> = emptyList(),
    val genomesDiscovered: Int = 0,
    val benchmarksRun: Int = 0
)

class DashboardViewModel(
    repository: CompressionRepository,
    evolutionStatsRepository: EvolutionStatsRepository
) : ViewModel() {

    val uiState: StateFlow<DashboardUiState> = combine(
        repository.observeTotalCount(),
        repository.observeTotalBytesSaved(),
        repository.observeRecent(10),
        evolutionStatsRepository.observeGenomeCount(),
        evolutionStatsRepository.observeBenchmarkCount()
    ) { count, bytesSaved, recent, genomesDiscovered, benchmarksRun ->
        DashboardUiState(
            totalArchives = count,
            totalBytesSaved = bytesSaved,
            recentRecords = recent,
            genomesDiscovered = genomesDiscovered,
            benchmarksRun = benchmarksRun
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = DashboardUiState()
    )
}
