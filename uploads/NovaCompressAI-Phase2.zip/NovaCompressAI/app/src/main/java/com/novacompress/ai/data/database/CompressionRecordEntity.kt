package com.novacompress.ai.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One completed compression job. This is Phase 1's minimal slice of the
 * full spec's Knowledge Database (which also tracks per-experiment
 * benchmarks, genome fitness history, and species statistics - those
 * arrive with the Benchmark Laboratory and Evolution Engine phases).
 */
@Entity(tableName = "compression_records")
data class CompressionRecordEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val originalFileName: String,
    val originalSize: Long,
    val compressedSize: Long,
    val genomeId: String,
    val pipelineDescription: String,
    val archiveFilePath: String,
    val createdAtEpochMillis: Long
) {
    val compressionRatio: Double
        get() = if (compressedSize == 0L) 0.0 else originalSize.toDouble() / compressedSize.toDouble()
}
