package com.novacompress.ai.core.pipeline

import com.novacompress.ai.core.common.Constants
import com.novacompress.ai.core.plugins.PluginRegistry

/**
 * An ordered list of plugin IDs describing one complete compression
 * strategy. This is the "DNA" referenced throughout the project docs -
 * Phase 1 stores it as a simple ordered list; the Evolution Engine (a
 * later phase) will mutate and recombine these.
 */
data class PipelineDescriptor(val pluginIds: List<String>) {

    init {
        require(pluginIds.isNotEmpty()) { "A pipeline must contain at least one plugin" }
        require(pluginIds.size <= Constants.MAX_PIPELINE_STAGES) {
            "Pipeline exceeds the maximum of ${Constants.MAX_PIPELINE_STAGES} stages"
        }
        require(pluginIds.size == pluginIds.toSet().size) {
            "Pipeline contains duplicate plugins: $pluginIds"
        }
        pluginIds.forEach { id ->
            require(PluginRegistry.exists(id)) { "Unknown plugin id in pipeline: $id" }
        }
    }

    /** Human-readable form, e.g. "Delta -> RLE -> Huffman". */
    fun describe(): String =
        pluginIds.joinToString(" \u2192 ") { PluginRegistry.get(it).displayName }

    companion object {
        fun of(vararg ids: String) = PipelineDescriptor(ids.toList())
    }
}
