package com.novacompress.ai.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Unarchive
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.novacompress.ai.R
import com.novacompress.ai.ui.compress.CompressScreen
import com.novacompress.ai.ui.dashboard.DashboardScreen
import com.novacompress.ai.ui.decompress.DecompressScreen
import com.novacompress.ai.ui.settings.SettingsScreen

private sealed class NovaDestination(val route: String, val labelRes: Int, val icon: ImageVector) {
    object Dashboard : NovaDestination("dashboard", R.string.nav_dashboard, Icons.Filled.Dashboard)
    object Compress : NovaDestination("compress", R.string.nav_compress, Icons.Filled.Archive)
    object Decompress : NovaDestination("decompress", R.string.nav_decompress, Icons.Filled.Unarchive)
    object Settings : NovaDestination("settings", R.string.nav_settings, Icons.Filled.Settings)
}

private val bottomBarDestinations = listOf(
    NovaDestination.Dashboard,
    NovaDestination.Compress,
    NovaDestination.Decompress,
    NovaDestination.Settings
)

@Composable
fun NovaNavHost() {
    val navController = rememberNavController()

    Scaffold(
        bottomBar = {
            val backStackEntry by navController.currentBackStackEntryAsState()
            val currentRoute = backStackEntry?.destination?.route

            NavigationBar {
                bottomBarDestinations.forEach { destination ->
                    NavigationBarItem(
                        selected = currentRoute == destination.route,
                        onClick = {
                            navController.navigate(destination.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(destination.icon, contentDescription = null) },
                        label = { Text(stringResource(destination.labelRes)) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = NovaDestination.Dashboard.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(NovaDestination.Dashboard.route) { DashboardScreen() }
            composable(NovaDestination.Compress.route) { CompressScreen() }
            composable(NovaDestination.Decompress.route) { DecompressScreen() }
            composable(NovaDestination.Settings.route) { SettingsScreen() }
        }
    }
}
