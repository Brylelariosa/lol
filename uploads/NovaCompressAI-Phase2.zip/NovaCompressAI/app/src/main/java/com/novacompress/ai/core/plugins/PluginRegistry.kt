package com.novacompress.ai.core.plugins

/**
 * Central lookup from stable plugin ID (as stored in archives and genomes)
 * to the plugin instance. The core engine never needs to change when new
 * plugins are added here.
 */
object PluginRegistry {

    private val plugins: Map<String, CompressionPlugin> = listOf(
        DeltaEncodingPlugin(),
        RunLengthEncodingPlugin(),
        HuffmanCodingPlugin(),
        Lz77Plugin(),
        MoveToFrontPlugin()
    ).associateBy { it.id }

    fun get(id: String): CompressionPlugin =
        plugins[id] ?: throw IllegalArgumentException("Unknown plugin id: $id")

    fun all(): List<CompressionPlugin> = plugins.values.toList()

    fun exists(id: String): Boolean = plugins.containsKey(id)
}
