package com.novacompress.ai.plugins

import com.novacompress.ai.testutil.TestSamples
import org.junit.Assert.assertArrayEquals
import org.junit.Test

class HuffmanCodingPluginTest {

    private val plugin = HuffmanCodingPlugin()

    @Test
    fun `round trip preserves all sample data exactly`() {
        for ((label, data) in TestSamples.all()) {
            val compressed = plugin.compress(data)
            val decompressed = plugin.decompress(compressed)
            assertArrayEquals("failed round trip for sample: $label", data, decompressed)
        }
    }

    @Test
    fun `empty input encodes to a single magic byte`() {
        val compressed = plugin.compress(ByteArray(0))
        assert(compressed.size == 1)
        assertArrayEquals(ByteArray(0), plugin.decompress(compressed))
    }

    @Test
    fun `single repeated symbol uses the dedicated fast path`() {
        val data = ByteArray(10_000) { 200.toByte() }
        val compressed = plugin.compress(data)
        // Fast path header is only 6 bytes (magic + symbol + 4-byte length), regardless of input size.
        assert(compressed.size == 6) { "expected 6-byte single-symbol encoding, got ${compressed.size}" }
        assertArrayEquals(data, plugin.decompress(compressed))
    }

    @Test
    fun `all 256 distinct byte values round trip correctly`() {
        val data = ByteArray(256) { it.toByte() }
        val compressed = plugin.compress(data)
        assertArrayEquals(data, plugin.decompress(compressed))
    }

    @Test
    fun `highly skewed frequency distribution round trips correctly`() {
        // Deliberately lopsided so some codes end up much longer than others.
        val data = ByteArray(1000) { 0 } + ByteArray(1) { 1 } + ByteArray(1) { 2 }
        val compressed = plugin.compress(data)
        assertArrayEquals(data, plugin.decompress(compressed))
    }
}
