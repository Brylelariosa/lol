package com.novacompress.ai.verification

import com.novacompress.ai.core.pipeline.CompressionPipeline
import com.novacompress.ai.core.verification.VerificationEngine
import com.novacompress.ai.testutil.TestSamples
import org.junit.Assert.assertTrue
import org.junit.Test

class VerificationEngineTest {

    @Test
    fun `verification passes for every correct pipeline on every sample`() {
        val pipeline = CompressionPipeline.from(listOf("delta", "rle", "huffman"))
        for ((label, data) in TestSamples.all()) {
            val result = VerificationEngine.verifyRoundTrip(data, pipeline)
            assertTrue("expected pass for sample $label but got: ${result.reason}", result.passed)
        }
    }

    @Test
    fun `sha256 is deterministic and sensitive to any byte change`() {
        val a = byteArrayOf(1, 2, 3, 4, 5)
        val b = byteArrayOf(1, 2, 3, 4, 6)
        val hashA1 = VerificationEngine.sha256(a)
        val hashA2 = VerificationEngine.sha256(a)
        val hashB = VerificationEngine.sha256(b)
        assertTrue(hashA1.contentEquals(hashA2))
        assertTrue(!hashA1.contentEquals(hashB))
    }
}
