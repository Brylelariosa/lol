package com.novacompress.ai.evolution

import com.novacompress.ai.core.evolution.CrossoverEngine
import com.novacompress.ai.core.pipeline.PipelineDescriptor
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class CrossoverEngineTest {

    @Test
    fun `crossover always produces a valid, duplicate-free pipeline even with overlapping parents`() {
        val parentA = PipelineDescriptor.of("delta", "rle", "huffman")
        val parentB = PipelineDescriptor.of("rle", "lz77", "huffman", "mtf") // shares "rle" and "huffman" with A
        val random = Random(55)

        repeat(500) {
            val child = CrossoverEngine.crossover(parentA, parentB, random)
            assertTrue(child.pluginIds.isNotEmpty())
            assertTrue("crossover produced a duplicate: ${child.pluginIds}", child.pluginIds.size == child.pluginIds.toSet().size)
        }
    }

    @Test
    fun `crossover of identical parents reproduces a prefix of that same pipeline`() {
        val parent = PipelineDescriptor.of("delta", "rle", "huffman")
        val random = Random(3)
        repeat(100) {
            val child = CrossoverEngine.crossover(parent, parent, random)
            assertTrue(parent.pluginIds.containsAll(child.pluginIds))
        }
    }
}
