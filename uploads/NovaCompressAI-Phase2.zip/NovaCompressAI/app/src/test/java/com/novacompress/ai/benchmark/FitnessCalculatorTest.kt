package com.novacompress.ai.benchmark

import com.novacompress.ai.core.benchmark.BenchmarkResult
import com.novacompress.ai.core.benchmark.FitnessCalculator
import com.novacompress.ai.core.genome.GenomePresets
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FitnessCalculatorTest {

    @Test
    fun `an unverified result always scores zero regardless of ratio`() {
        val result = BenchmarkResult(
            genome = GenomePresets.BALANCED,
            originalSize = 1000,
            compressedSize = 10,
            compressionTimeNanos = 1,
            decompressionTimeNanos = 1,
            verified = false
        )
        assertEquals(0.0, FitnessCalculator.calculate(result), 0.0001)
    }

    @Test
    fun `a faster pipeline scores higher than a slower one at the same ratio`() {
        val fast = BenchmarkResult(GenomePresets.BALANCED, 1000, 500, 1_000_000, 1_000_000, true)
        val slow = BenchmarkResult(GenomePresets.BALANCED, 1000, 500, 500_000_000, 500_000_000, true)
        assertTrue(FitnessCalculator.calculate(fast) > FitnessCalculator.calculate(slow))
    }

    @Test
    fun `a much better ratio outweighs being somewhat slower`() {
        val slowButBetterRatio = BenchmarkResult(GenomePresets.MAXIMUM_COMPRESSION, 1000, 100, 50_000_000, 50_000_000, true) // 10x ratio
        val fastButWorseRatio = BenchmarkResult(GenomePresets.FAST, 1000, 500, 1_000_000, 1_000_000, true) // 2x ratio
        assertTrue(FitnessCalculator.calculate(slowButBetterRatio) > FitnessCalculator.calculate(fastButWorseRatio))
    }
}
