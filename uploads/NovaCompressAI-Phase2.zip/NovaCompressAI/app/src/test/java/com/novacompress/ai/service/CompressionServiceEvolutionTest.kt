package com.novacompress.ai.service

import com.novacompress.ai.core.evolution.EvolutionEngine
import com.novacompress.ai.core.service.CompressionService
import com.novacompress.ai.testutil.InMemoryGenomeRepository
import com.novacompress.ai.testutil.TestSamples
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.File
import kotlin.random.Random

class CompressionServiceEvolutionTest {

    @Test
    fun `compression routed through the Evolution Engine produces a real benchmark and a working archive`() = runTest {
        val repository = InMemoryGenomeRepository()
        val engine = EvolutionEngine(repository, random = Random(42))
        val service = CompressionService(evolutionEngine = engine)

        val data = "evolution-driven compression test ".repeat(400).toByteArray()
        val archiveFile = File.createTempFile("nova_evo_test", ".nova")
        try {
            val outcome = service.compress(
                openStream = { ByteArrayInputStream(data) },
                originalFileName = "notes.txt",
                originalSize = data.size.toLong(),
                tempDestination = archiveFile
            )

            assertNotNull("expected a benchmark result when the Evolution Engine is used", outcome.benchmark)
            assertTrue(outcome.benchmark!!.verified)
            assertTrue(outcome.chosenGenome.explanation.contains("Benchmarked"))
            assertTrue(repository.benchmarkCount() >= 3)

            // The archive itself must still be a fully valid, decodable .nova file.
            val recovered = java.io.ByteArrayOutputStream()
            val readResult = com.novacompress.ai.core.archive.NovaArchiveReader.readAndVerify(
                archiveFile.inputStream(),
                recovered
            )
            assertTrue(readResult is com.novacompress.ai.core.archive.ArchiveReadResult.Success)
            assertArrayEquals(data, recovered.toByteArray())
        } finally {
            archiveFile.delete()
        }
    }

    @Test
    fun `low power mode bypasses the Evolution Engine entirely`() = runTest {
        val repository = InMemoryGenomeRepository()
        val engine = EvolutionEngine(repository, random = Random(1))
        val service = CompressionService(evolutionEngine = engine)

        val data = TestSamples.randomBytes(2000, seed = 6)
        val archiveFile = File.createTempFile("nova_lowpower_test", ".nova")
        try {
            val outcome = service.compress(
                openStream = { ByteArrayInputStream(data) },
                originalFileName = "photo.bin",
                originalSize = data.size.toLong(),
                tempDestination = archiveFile,
                preferLowPower = true
            )

            assertNull("low-power mode should skip the Evolution Engine and report no benchmark", outcome.benchmark)
            assertTrue(repository.benchmarkCount() == 0)
        } finally {
            archiveFile.delete()
        }
    }
}
