package com.novacompress.ai.plugins

import com.novacompress.ai.testutil.TestSamples
import org.junit.Assert.assertArrayEquals
import org.junit.Test

class Lz77PluginTest {

    private val plugin = Lz77Plugin()

    @Test
    fun `round trip preserves all sample data exactly`() {
        for ((label, data) in TestSamples.all()) {
            val compressed = plugin.compress(data)
            val decompressed = plugin.decompress(compressed)
            assertArrayEquals("failed round trip for sample: $label", data, decompressed)
        }
    }

    @Test
    fun `overlapping self-referential copy (distance less than length) round trips correctly`() {
        // "aaaaa...", 500 times: the very first match will need to copy from
        // a distance of 1 while the run being copied is much longer than 1,
        // which is the trickiest correctness case for an LZ77 decoder.
        val data = ByteArray(500) { 'a'.code.toByte() }
        val compressed = plugin.compress(data)
        assertArrayEquals(data, plugin.decompress(compressed))
    }

    @Test
    fun `data spanning multiple window sizes round trips correctly`() {
        val data = TestSamples.randomBytes(size = 32768 * 3 + 123, seed = 5).let { base ->
            // Repeat a recognizable pattern so matches are forced across window boundaries.
            ByteArray(base.size) { base[it % 4096] }
        }
        val compressed = plugin.compress(data)
        assertArrayEquals(data, plugin.decompress(compressed))
    }

    @Test
    fun `incompressible random data still round trips (allowed to expand)`() {
        val data = TestSamples.randomBytes(size = 5000, seed = 99)
        val compressed = plugin.compress(data)
        assertArrayEquals(data, plugin.decompress(compressed))
    }
}
