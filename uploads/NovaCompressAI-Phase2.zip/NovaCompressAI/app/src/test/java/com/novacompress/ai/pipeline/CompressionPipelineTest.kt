package com.novacompress.ai.pipeline

import com.novacompress.ai.testutil.TestSamples
import org.junit.Assert.assertArrayEquals
import org.junit.Test

class CompressionPipelineTest {

    private val combos = listOf(
        listOf("delta", "huffman"),
        listOf("rle", "huffman"),
        listOf("delta", "rle", "huffman"),
        listOf("lz77", "huffman"),
        listOf("lz77"),
        listOf("delta"),
        listOf("rle"),
        listOf("huffman")
    )

    @Test
    fun `every plugin combination round trips every sample`() {
        for (combo in combos) {
            val pipeline = CompressionPipeline.from(combo)
            for ((label, data) in TestSamples.all()) {
                val compressed = pipeline.compress(data)
                val decompressed = pipeline.decompress(compressed)
                assertArrayEquals(
                    "pipeline ${combo.joinToString("->")} failed on sample $label",
                    data,
                    decompressed
                )
            }
        }
    }

    @Test
    fun `descriptor rejects an empty pipeline`() {
        try {
            PipelineDescriptor(emptyList())
            assert(false) { "expected IllegalArgumentException for an empty pipeline" }
        } catch (e: IllegalArgumentException) {
            // expected
        }
    }

    @Test
    fun `descriptor rejects an unknown plugin id`() {
        try {
            PipelineDescriptor(listOf("not_a_real_plugin"))
            assert(false) { "expected IllegalArgumentException for an unknown plugin id" }
        } catch (e: IllegalArgumentException) {
            // expected
        }
    }

    @Test
    fun `descriptor rejects duplicate plugins`() {
        try {
            PipelineDescriptor(listOf("huffman", "delta", "huffman"))
            assert(false) { "expected IllegalArgumentException for duplicate plugins" }
        } catch (e: IllegalArgumentException) {
            // expected
        }
    }
}
