package com.novacompress.ai.analyzer

import com.novacompress.ai.core.analyzer.FileAnalyzer
import com.novacompress.ai.testutil.TestSamples
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FileAnalyzerTest {

    private val analyzer = FileAnalyzer()

    @Test
    fun `all-identical bytes have zero entropy and a high run-length score`() {
        val data = ByteArray(2000) { 7 }
        val features = analyzer.analyze(data)
        assertEquals(0.0, features.entropyBitsPerByte, 0.0001)
        assertEquals(1, features.uniqueByteCount)
        assertTrue(features.runLengthScore > 0.99)
    }

    @Test
    fun `uniformly random bytes have entropy close to 8 bits per byte`() {
        val data = TestSamples.randomBytes(50_000, seed = 3)
        val features = analyzer.analyze(data)
        assertTrue("expected entropy near 8.0, got ${features.entropyBitsPerByte}", features.entropyBitsPerByte > 7.9)
        assertTrue(features.looksAlreadyRandom)
    }

    @Test
    fun `repeated block pattern is detected by the repeated-block score`() {
        val block = byteArrayOf(1, 2, 3, 4, 5, 6, 7, 8)
        val data = ByteArray(8 * 200) { block[it % 8] }
        val features = analyzer.analyze(data)
        assertTrue("expected a high repeated-block score, got ${features.repeatedBlockScore}", features.repeatedBlockScore > 0.9)
    }

    @Test
    fun `empty input does not throw and reports zero entropy`() {
        val features = analyzer.analyze(ByteArray(0))
        assertEquals(0.0, features.entropyBitsPerByte, 0.0001)
        assertEquals(0, features.sampledBytes)
    }

    @Test
    fun `sample is capped at the configured maximum`() {
        val cappedAnalyzer = FileAnalyzer(maxSampleBytes = 100)
        val data = TestSamples.randomBytes(10_000, seed = 4)
        val features = cappedAnalyzer.analyze(data)
        assertEquals(100, features.sampledBytes)
    }
}
