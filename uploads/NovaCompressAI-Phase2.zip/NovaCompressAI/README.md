# NovaCompress AI — Phase 1 + 2

This covers **Phase 1 and Phase 2** of NovaCompress AI: a real, working,
buildable Android app implementing the foundational compression engine
*and* a genuinely working genome Evolution Engine + Benchmark Laboratory.
It is not the whole spec — see [PROGRESS.md](PROGRESS.md) for what's here
vs. what's next.

## What actually works right now

- **Five real, lossless compression plugins**: Delta Encoding, Run-Length
  Encoding (PackBits-style), canonical Huffman coding, LZ77 (LZSS-style
  with hash-chain matching), and Move-To-Front. Every plugin was first
  prototyped and round-trip-tested in Python (empty input, single-byte
  input, all-256-byte-values, overlapping LZ77 copies, window-boundary
  crossings, etc.) before being ported to Kotlin, to catch algorithmic
  bugs before they became Kotlin bugs.
- **A real pipeline engine** that chains plugins in sequence and reverses
  them correctly for decompression - and correctly rejects invalid
  pipelines (empty, over the stage limit, unknown plugin, or duplicate
  plugins), per the spec's pipeline validation rules.
- **A real, chunked, streaming `.nova` archive format** — magic header,
  self-describing metadata, per-chunk SHA-256, and a whole-file SHA-256
  footer. Reading is fully verified: any corrupted byte, truncated file, or
  hash mismatch is caught and reported, never silently ignored.
- **A real Verification Engine**: every chunk is compressed, decompressed,
  and compared byte-for-byte (plus an independent SHA-256 check) *before*
  its compressed bytes are ever written to the archive. A failing chunk
  throws immediately and the partial archive is deleted — nothing
  unverified ever reaches disk.
- **A real Benchmark Laboratory**: every candidate genome is actually
  compressed, decompressed, timed with `System.nanoTime()`, and verified
  against the real file — never an estimate.
- **A real Evolution Engine**: mutation (insert/delete/swap/replace) and
  crossover (single-point recombination), both guaranteed to produce
  structurally valid, duplicate-free pipelines. Every compression job
  benchmarks the best known genomes plus fresh mutated/crossed candidates,
  records *every* result as permanent knowledge, and picks the genuinely
  measured winner - not a guess.
- **A real (if simple) File Analyzer**: Shannon entropy, byte histogram,
  run-length score, and a repeated-block heuristic, computed from a bounded
  sample so large files don't blow up memory. Used as a fast fallback path
  (low-power mode) alongside the Evolution Engine.
- **A growing Knowledge Database**: genomes carry generation, species,
  lifecycle status, and parent lineage; every benchmark experiment is
  permanently recorded, win or lose.
- **A working Compose UI**: Dashboard (stats + recent activity + live
  genome/benchmark counts from Room), Compress (file picker → analysis →
  evolved & verified compression → result with a real explanation), and
  Decompress (file picker → verified decompression → result), plus a
  minimal Settings screen.
- **50 JUnit test methods** across plugins, pipeline validation, the
  archive format (including deliberate corruption injection), the
  analyzer, the verification engine, mutation/crossover validity, the
  benchmark lab, the fitness function, the evolution engine (against an
  in-memory fake repository), and full compress→decompress round trips
  through the service layer.

## What's deliberately not here yet

Burrows-Wheeler Transform, Arithmetic Coding, Predictive Coding (BWT
specifically needs a proper suffix-array construction to be both correct
*and* efficient - see PROGRESS.md for why that's staged as its own careful
pass rather than rushed), the Research Dashboard/visualizations,
thermal/battery-aware scheduling, WorkManager background research, Hilt,
the Plugin SDK, multi-file archives, and the "share to compress" / "open
.nova" external intents. These are staged into later phases rather than
bolted on half-finished — see PROGRESS.md.

## About the Gradle Wrapper

The build environment for this project is GitHub Actions, per the project's
own build instructions. The sandbox this project was generated in has **no
network access and no local Gradle/Android SDK/Kotlin compiler** — so a
`gradle-wrapper.jar` binary (normally produced by running `gradle wrapper`
against a real Gradle install) could not be generated or verified here.

Rather than commit a guessed-at binary that might be silently wrong, the
CI workflow (`.github/workflows/android-ci.yml`) installs a real Gradle
distribution first and runs `gradle wrapper --gradle-version 8.6` as its
first step, regenerating `gradlew`, `gradlew.bat`, and `gradle-wrapper.jar`
before anything else runs. This is a standard, well-known pattern and means
CI never depends on a wrapper jar that was never actually executed.

If you clone this locally and want to run `./gradlew` directly, you'll need
to run `gradle wrapper --gradle-version 8.6` yourself once (with any Gradle
8.x install), or just use your own `gradle` command directly.

## Verified version matrix

Every version below was cross-checked (not assumed) against current
compatibility tables before being pinned:

| Component | Version |
|---|---|
| Gradle | 8.6 (per the project's own pinned target) |
| Android Gradle Plugin | 8.4.0 |
| Kotlin | 1.9.24 |
| Compose Compiler extension | 1.5.14 |
| KSP | 1.9.24-1.0.20 |
| compileSdk / targetSdk | 34 |
| minSdk | 26 (Android 8.0) |

Note: as of mid-2026 the ecosystem has moved on to Gradle 9.x / AGP 9.x
(which changes Kotlin integration significantly). This project deliberately
stays on the version matrix the project's own build spec pinned (Gradle
8.6, NDK 25.x, CMake 3.22.1) rather than jumping to the newer major
versions; upgrading is a reasonable future task if you'd rather ride the
current tooling.

## Building

Push to GitHub and let `.github/workflows/android-ci.yml` build it, or
locally:

```bash
gradle wrapper --gradle-version 8.6   # one-time, if gradlew isn't already valid
./gradlew testDebugUnitTest           # run the 50 unit tests
./gradlew assembleDebug               # produce app/build/outputs/apk/debug/app-debug.apk
```

## Project layout

```
app/src/main/java/com/novacompress/ai/
  core/
    analyzer/     FileAnalyzer, FeatureVector
    plugins/      CompressionPlugin + Delta/RLE/Huffman/LZ77/MTF + PluginRegistry
    pipeline/     PipelineDescriptor, CompressionPipeline
    genome/       CompressionGenome, GenomeStatus, GenomePresets, GenomeSelector
    verification/ VerificationEngine
    archive/      NovaArchiveWriter/Reader, ArchiveMetadata, format constants
    benchmark/    BenchmarkLaboratory, BenchmarkResult, FitnessCalculator
    evolution/    EvolutionEngine, MutationEngine, CrossoverEngine, GenomeRepository (interface)
    service/      CompressionService, DecompressionService (orchestration)
    common/       Constants, EngineResult, BinaryIO, ByteCursor
  data/           Room database (compression history + genomes + benchmarks), DAOs, repositories
  di/             ServiceLocator + ViewModel factory (no Hilt yet, see below)
  ui/             Compose screens + ViewModels (dashboard/compress/decompress/settings)
app/src/test/java/com/novacompress/ai/   50 JUnit tests mirroring the above
```

## Notable engineering decisions

- **No Hilt yet.** A handful of hand-wired singletons doesn't justify the
  KSP/annotation-processor surface area yet; `ServiceLocator` is a plain
  Kotlin class. Hilt is a sensible addition once WorkManager workers need
  injection (Phase 4).
- **No JSON library for archive metadata.** `org.json` (Android's built-in
  JSON classes) throws `RuntimeException: not mocked` in plain JVM unit
  tests unless a second, real implementation is added as a test dependency
  — a well-known Android testing gotcha. Archive metadata instead uses
  simple length-prefixed fields (see `ArchiveMetadataCodec`), which are
  just as self-describing and behave identically in tests and production.
- **`GenomeRepository` is an interface** specifically so `EvolutionEngine`'s
  mutation/crossover/selection logic can be unit tested against an
  in-memory fake (`InMemoryGenomeRepository`, test-only) instead of
  requiring Room's real SQLite backing, which doesn't work in plain JVM
  unit tests without adding Robolectric.
- **Duplicate-plugin pipelines are rejected**, per the spec's own pipeline
  validation rules. This was a real gap in Phase 1 that surfaced while
  building Phase 2's mutation engine (see PROGRESS.md) and was fixed there.
- **R8/minification is off for release builds** for now. Enabling it
  safely needs keep rules for Room and the plugin registry; that's staged
  for when release signing is actually set up.
- **Files are saved to app-scoped external storage**
  (`getExternalFilesDir()`), not a user-chosen SAF destination, so no
  storage permissions are needed yet. A "save to..." picker is a natural
  addition for a later phase.
