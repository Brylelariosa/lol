package com.novacompress.bench.novacompress

import com.novacompress.bench.novacompress.predictor.ContextPredictor
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class ContextPredictorTest {
    private fun runAndScore(data: ByteArray, range: IntRange = data.indices): Double {
        val predictor = ContextPredictor()
        var prevPrev = 0
        var prev = 0
        var hits = 0
        var counted = 0
        for (pos in data.indices) {
            val predicted = predictor.predict(data, pos, prevPrev, prev)
            val actual = data[pos]
            if (pos in range) {
                counted++
                if (predicted == actual) hits++
            }
            predictor.update(data, pos, prevPrev, prev, actual)
            prevPrev = prev
            prev = actual.toInt() and 0xFF
        }
        return hits.toDouble() / counted
    }

    @Test fun predictsAFlatRepeatingStride() {
        // byte[pos] == byte[pos - 3] for the whole buffer - the case tier
        // 2's flat hypothesis is built for.
        val pattern = byteArrayOf(10, 20, 30)
        val data = ByteArray(30000) { pattern[it % 3] }
        val accuracy = runAndScore(data)
        assertTrue("Expected high accuracy on a flat stride-3 repeat, got $accuracy", accuracy > 0.9)
    }

    @Test fun predictsARampAlongAStride() {
        // A smooth +1-per-step ramp within each of 3 interleaved channels,
        // e.g. byte N usually equals byte N-3 plus a constant delta. The
        // value 3 positions back is almost never exactly right on its own
        // (it changes every step) - only the trend (3-back plus the last
        // observed step size, tier 2's delta hypothesis) is - mirroring a
        // gradient image's per-channel behavior.
        val data = ByteArray(30000)
        for (i in data.indices) {
            val channel = i % 3
            val step = i / 3
            data[i] = ((channel * 50 + step) and 0xFF).toByte()
        }
        val accuracy = runAndScore(data)
        assertTrue("Expected high accuracy on a stride-3 ramp (delta hypothesis), got $accuracy", accuracy > 0.7)
    }

    @Test fun adaptsWithinAFewThousandBytesAfterARegimeChange() {
        // Flat stride-3 for the first half, then a ramp for the second -
        // scores built up favoring the flat hypothesis in the first half
        // shouldn't stop the predictor from doing well once the character
        // of the data changes.
        val pattern = byteArrayOf(10, 20, 30)
        val flatPart = ByteArray(20000) { pattern[it % 3] }
        val rampPart = ByteArray(20000) { (((it % 3) * 50 + it / 3) and 0xFF).toByte() }
        val data = flatPart + rampPart

        // Skip the first 8000 bytes of the ramp to give the predictor room
        // to adapt, then require strong accuracy for the rest of it.
        val accuracy = runAndScore(data, (flatPart.size + 8000) until data.size)
        assertTrue("Expected the predictor to recover well after the regime change, got $accuracy", accuracy > 0.6)
    }

    @Test fun neverCrashesOnRandomData() {
        val r = Random(1)
        val data = ByteArray(20000)
        r.nextBytes(data)
        // Just verifying predict/update run cleanly across fully
        // unpredictable data with no out-of-bounds access - near-1/256
        // accuracy is expected and fine, this isn't asserting a floor.
        val accuracy = runAndScore(data)
        assertTrue(accuracy in 0.0..1.0)
    }

    @Test fun neverCrashesOnTinyBuffers() {
        for (size in 0..8) {
            val data = ByteArray(size) { (it * 7).toByte() }
            runAndScore(data)
        }
    }
}
