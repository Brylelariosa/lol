package com.novacompress.bench.novacompress

import com.novacompress.bench.novacompress.entropy.FreqModel
import com.novacompress.bench.novacompress.entropy.RangeDecoder
import com.novacompress.bench.novacompress.entropy.RangeEncoder
import org.junit.Assert.assertArrayEquals
import org.junit.Test
import kotlin.random.Random

class RangeCoderTest {
    private fun roundTrip(symbols: IntArray, alphabet: Int): IntArray {
        val encModel = FreqModel(alphabet)
        val enc = RangeEncoder()
        for (s in symbols) enc.encode(encModel, s)
        val encoded = enc.finish()

        val decModel = FreqModel(alphabet)
        val dec = RangeDecoder(encoded)
        return IntArray(symbols.size) { dec.decodeSymbol(decModel) }
    }

    @Test fun empty() = assertArrayEquals(IntArray(0), roundTrip(IntArray(0), 258))

    @Test fun singleSymbol() = assertArrayEquals(intArrayOf(5), roundTrip(intArrayOf(5), 258))

    @Test fun allSameSymbol() {
        val seq = IntArray(200) { 42 }
        assertArrayEquals(seq, roundTrip(seq, 258))
    }

    @Test fun alternatingTwoSymbols() {
        val seq = IntArray(500) { if (it % 2 == 0) 0 else 1 }
        assertArrayEquals(seq, roundTrip(seq, 258))
    }

    @Test fun fullAlphabetSweep() {
        val seq = IntArray(258) { it }
        assertArrayEquals(seq, roundTrip(seq, 258))
    }

    @Test fun uniformRandom() {
        val r = Random(1234)
        repeat(10) {
            val seq = IntArray(5000) { r.nextInt(258) }
            assertArrayEquals(seq, roundTrip(seq, 258))
        }
    }

    @Test fun skewedRandom() {
        val r = Random(5678)
        repeat(30) {
            val len = 1000 + r.nextInt(20000)
            val seq = IntArray(len) {
                val u = r.nextDouble()
                (258 * Math.pow(u, 4.0)).toInt().coerceAtMost(257)
            }
            assertArrayEquals(seq, roundTrip(seq, 258))
        }
    }

    @Test fun longRunForcingRescale() {
        val seq = IntArray(100000) { 7 }
        assertArrayEquals(seq, roundTrip(seq, 258))
    }

    @Test fun carryPropagationStress() {
        val r = Random(999)
        val seq = IntArray(50000) { if (r.nextBoolean()) 257 else r.nextInt(258) }
        assertArrayEquals(seq, roundTrip(seq, 258))
    }
}
