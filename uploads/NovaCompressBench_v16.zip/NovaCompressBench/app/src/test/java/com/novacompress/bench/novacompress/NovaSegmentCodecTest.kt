package com.novacompress.bench.novacompress

import org.junit.Assert.assertArrayEquals
import org.junit.Test
import java.io.ByteArrayOutputStream
import kotlin.random.Random

class NovaSegmentCodecTest {
    private fun roundTrip(data: ByteArray): ByteArray {
        val block = NovaSegmentCodec.encode(data)
        return NovaSegmentCodec.decode(block, data.size)
    }

    @Test fun empty() = assertArrayEquals(ByteArray(0), roundTrip(ByteArray(0)))

    @Test fun singleByte() = assertArrayEquals(byteArrayOf(7), roundTrip(byteArrayOf(7)))

    @Test fun allZeros() {
        val data = ByteArray(1000)
        assertArrayEquals(data, roundTrip(data))
    }

    @Test fun allSameByte() {
        val data = ByteArray(5000) { 0xAB.toByte() }
        assertArrayEquals(data, roundTrip(data))
    }

    @Test fun runThenDifferentRun() {
        val data = ByteArray(1000) { if (it < 500) 1 else 2 }
        assertArrayEquals(data, roundTrip(data))
    }

    @Test fun randomData() {
        val r = Random(42)
        val data = ByteArray(50000)
        r.nextBytes(data)
        assertArrayEquals(data, roundTrip(data))
    }

    @Test fun textLikeRepeatedWords() {
        val words = listOf("the", "quick", "brown", "fox", "compression", "research")
        val r = Random(1)
        val sb = StringBuilder()
        while (sb.length < 20000) sb.append(words[r.nextInt(words.size)]).append(' ')
        val data = sb.toString().toByteArray()
        assertArrayEquals(data, roundTrip(data))
    }

    @Test fun jsonLikeRecords() {
        val r = Random(2)
        val sb = StringBuilder()
        var id = 0
        while (sb.length < 15000) {
            sb.append("{\"id\":").append(id++).append(",\"score\":").append(r.nextInt(1000)).append("}\n")
        }
        val data = sb.toString().toByteArray()
        assertArrayEquals(data, roundTrip(data))
    }

    @Test fun selfOverlappingRunLengthLike() {
        val r = Random(3)
        val out = ByteArrayOutputStream()
        var v = r.nextInt(256).toByte()
        while (out.size() < 3000) {
            val runLen = 1 + r.nextInt(40)
            repeat(runLen) { if (out.size() < 3000) out.write(v.toInt()) }
            v = r.nextInt(256).toByte()
        }
        val data = out.toByteArray()
        assertArrayEquals(data, roundTrip(data))
    }

    @Test fun repetitiveStructureWithVaryingField() {
        val record = byteArrayOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16)
        val out = ByteArrayOutputStream()
        var i = 0
        while (out.size() < 10000) {
            record[3] = (i % 7).toByte()
            out.write(record)
            i++
        }
        val data = out.toByteArray()
        assertArrayEquals(data, roundTrip(data))
    }

    @Test fun fuzzedMixedContent() {
        val r = Random(99)
        repeat(15) {
            val target = 500 + r.nextInt(30000)
            val out = ByteArrayOutputStream()
            while (out.size() < target) {
                when (r.nextInt(4)) {
                    0 -> { val b = ByteArray(1 + r.nextInt(50)); r.nextBytes(b); out.write(b) }
                    1 -> { val v = r.nextInt(256); repeat(1 + r.nextInt(100)) { out.write(v) } }
                    2 -> { val words = listOf("alpha", "beta", "gamma"); repeat(1 + r.nextInt(20)) { out.write((words[r.nextInt(3)] + " ").toByteArray()) } }
                    else -> { out.write("{\"x\":${r.nextInt(999)}}\n".toByteArray()) }
                }
            }
            val data = out.toByteArray().copyOf(target)
            assertArrayEquals(data, roundTrip(data))
        }
    }

    @Test fun largerPerformanceSanityCheck() {
        val r = Random(5)
        val words = listOf("alpha", "beta", "gamma", "delta", "record", "field", "compress")
        val sb = StringBuilder()
        while (sb.length < 2_000_000) {
            if (r.nextInt(10) < 7) sb.append(words[r.nextInt(words.size)]).append(' ')
            else sb.append((32 + r.nextInt(95)).toChar())
        }
        val data = sb.toString().toByteArray().copyOf(2_000_000)
        assertArrayEquals(data, roundTrip(data))
    }
}
