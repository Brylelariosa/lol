package com.novacompress.bench.novacompress

import com.novacompress.bench.novacompress.analyzer.EntropyCalculator
import com.novacompress.bench.novacompress.analyzer.FileAnalyzer
import com.novacompress.bench.novacompress.analyzer.Region
import com.novacompress.bench.novacompress.analyzer.RegionKind
import com.novacompress.bench.novacompress.analyzer.RegionStats
import com.novacompress.bench.novacompress.segment.SegmentStrategy
import com.novacompress.bench.novacompress.segment.Segmenter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class EntropyCalculatorTest {
    @Test fun constantDataHasZeroEntropy() {
        val data = ByteArray(1000) { 5 }
        assertEquals(0.0, EntropyCalculator.shannonEntropy(data), 0.0001)
    }

    @Test fun uniformRandomDataHasNearMaxEntropy() {
        val data = ByteArray(100000)
        Random(1).nextBytes(data)
        val entropy = EntropyCalculator.shannonEntropy(data)
        assertTrue("Expected near-8 bits/byte for random data, got $entropy", entropy > 7.9)
    }

    @Test fun textHasModerateEntropy() {
        val data = "the quick brown fox jumps over the lazy dog ".repeat(200).toByteArray()
        val entropy = EntropyCalculator.shannonEntropy(data)
        assertTrue("Expected moderate entropy for text, got $entropy", entropy in 3.0..5.5)
    }

    @Test fun emptyDataHasZeroEntropy() {
        assertEquals(0.0, EntropyCalculator.shannonEntropy(ByteArray(0)), 0.0001)
    }
}

class FileAnalyzerSegmenterTest {
    @Test fun classifiesHighEntropyDataForStore() {
        val data = ByteArray(200000)
        Random(2).nextBytes(data)
        val regions = FileAnalyzer.analyze(data)
        val segments = Segmenter.segment(regions)
        assertTrue(segments.isNotEmpty())
        assertTrue(
            "High-entropy random data should be routed to STORE",
            segments.all { it.strategy == SegmentStrategy.STORE },
        )
    }

    @Test fun classifiesTextForNovaPipeline() {
        val data = "the quick brown fox ".repeat(20000).toByteArray()
        val regions = FileAnalyzer.analyze(data)
        val segments = Segmenter.segment(regions)
        assertTrue(segments.isNotEmpty())
        assertTrue(
            "Repetitive text should be routed to the NovaCompress pipeline",
            segments.all { it.strategy == SegmentStrategy.NOVA },
        )
    }

    @Test fun segmentsCoverTheWholeBufferWithNoGapsOrOverlap() {
        val r = Random(3)
        val out = java.io.ByteArrayOutputStream()
        while (out.size() < 300000) {
            if (r.nextBoolean()) {
                val b = ByteArray(10000); r.nextBytes(b); out.write(b)
            } else {
                out.write("structured text content ".repeat(200).toByteArray())
            }
        }
        val data = out.toByteArray()
        val regions = FileAnalyzer.analyze(data)
        val segments = Segmenter.segment(regions)

        var expectedOffset = 0
        for (seg in segments) {
            assertEquals(expectedOffset, seg.offset)
            expectedOffset += seg.length
        }
        assertEquals(data.size, expectedOffset)
    }

    @Test fun pngMagicBytesDetected() {
        val pngHeader = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 1, 2, 3, 4, 5, 6, 7, 8)
        val data = pngHeader + ByteArray(1000)
        val regions = FileAnalyzer.analyze(data)
        assertEquals(RegionKind.IMAGE_LIKE, regions.first().kind)
    }

    @Test fun detectsMixedContentSmallerThanTheOldWindowSize() {
        // Alternating 8KB text and 8KB high-entropy blocks - a stand-in for,
        // say, an APK's manifest text sitting next to compressed entries.
        // At a 64KB window this entire 256KB file was reported as a single
        // uniform region: every window spanned four blocks of each kind, so
        // per-window stats never cleanly matched either profile, and 0 of
        // the 128KB that should have routed to STORE was detected.
        val r = Random(7)
        val out = java.io.ByteArrayOutputStream()
        var textBlock = true
        while (out.size() < 256000) {
            if (textBlock) {
                out.write("the quick brown fox jumps over the lazy dog ".repeat(200).toByteArray().copyOf(8192))
            } else {
                val b = ByteArray(8192); r.nextBytes(b); out.write(b)
            }
            textBlock = !textBlock
        }
        val data = out.toByteArray()
        val regions = FileAnalyzer.analyze(data)
        val segments = Segmenter.segment(regions)

        val storeBytes = segments.filter { it.strategy == SegmentStrategy.STORE }.sumOf { it.length }
        assertTrue(
            "Expected a meaningful fraction of this alternating-content file to be " +
                "routed to STORE, but only $storeBytes of ${data.size} bytes were " +
                "(the analyzer window may be too coarse to see the block boundaries)",
            storeBytes > data.size / 4,
        )
        assertTrue("Expected more than one segment for genuinely mixed content", segments.size > 1)
    }

    @Test fun splitsOnAKindTransitionEvenWithinOneStrategy() {
        // Structured text directly followed by a repetitive binary table -
        // both route to the NOVA strategy (neither looks like already-
        // compressed data to the classifier), so before this rewrite these
        // stayed one segment despite being two very different kinds of
        // content sharing one dictionary/entropy model.
        val text = "{\"id\":1,\"user\":\"alice\",\"active\":true}\n".repeat(3000).toByteArray()
        val table = ByteArray(80000) { i -> ((i % 24) * 7 + i / 24).toByte() }
        val data = text + table

        val regions = FileAnalyzer.analyze(data)
        val segments = Segmenter.segment(regions)

        assertTrue(
            "Expected the text/table kind transition to produce more than one segment, got: " +
                segments.map { it.dominantKind },
            segments.size > 1,
        )
    }

    @Test fun entropyDeltaSplitsIndependentlyOfKind() {
        // Direct unit test of the entropy-delta pathway, bypassing
        // FileAnalyzer entirely: same RegionKind throughout, but a clear
        // entropy jump partway through. Only the entropy check (not any
        // kind change) can be responsible for a split here.
        val low = List(6) { i -> Region(i * 4096, 4096, RegionKind.TEXT, RegionStats(3.0, 0.5, 0.0, 0.0)) }
        val high = List(6) { i -> Region((6 + i) * 4096, 4096, RegionKind.TEXT, RegionStats(7.0, 0.5, 0.0, 0.0)) }
        val regions = low + high

        val split = Segmenter.segment(regions)
        assertEquals("A clear, sustained entropy jump should split into two segments", 2, split.size)

        // The same regions, run through a version of the algorithm that
        // would need a much larger jump to react, shouldn't split - proves
        // the split above came from ENTROPY_DELTA_THRESHOLD specifically,
        // not some other effect of the entropy value being present at all.
        val unsplit = segmentWithEntropyDelta(regions, entropyDelta = 10.0)
        assertEquals(1, unsplit.size)
    }

    @Test fun minSegmentSizeSuppressesSplitsOnShortRuns() {
        // A kind transition arrives after only one window (4KB, well under
        // MIN_SEGMENT_SIZE) - should be absorbed into the current segment
        // rather than immediately producing a tiny second one.
        val regions = listOf(
            Region(0, 4096, RegionKind.TEXT, RegionStats(4.0, 0.9, 0.0, 0.0)),
            Region(4096, 4096, RegionKind.REPETITIVE_BINARY, RegionStats(4.0, 0.1, 0.0, 0.5)),
            Region(8192, 4096, RegionKind.TEXT, RegionStats(4.0, 0.9, 0.0, 0.0)),
        )
        val segments = Segmenter.segment(regions)
        assertEquals(
            "A one-window blip below MIN_SEGMENT_SIZE shouldn't fragment the run",
            1,
            segments.size,
        )
    }

    /** Test-only variant of [Segmenter.segment] with a configurable entropy
     *  threshold, to isolate ENTROPY_DELTA_THRESHOLD's effect from
     *  everything else the real function does. Deliberately duplicated
     *  rather than exposing an overload on [Segmenter] itself - production
     *  code has exactly one policy, and it shouldn't grow a parameter whose
     *  only caller is a test. */
    private fun segmentWithEntropyDelta(regions: List<Region>, entropyDelta: Double): List<com.novacompress.bench.novacompress.segment.Segment> {
        if (regions.isEmpty()) return emptyList()
        val segments = ArrayList<com.novacompress.bench.novacompress.segment.Segment>()
        var runStart = regions[0].offset
        var runLength = regions[0].length
        var runKind = regions[0].kind
        var entropySum = regions[0].stats.entropy
        var windowCount = 1
        for (i in 1 until regions.size) {
            val r = regions[i]
            val runningAverage = entropySum / windowCount
            val structuralChange = r.kind != runKind || kotlin.math.abs(r.stats.entropy - runningAverage) >= entropyDelta
            if (!structuralChange || runLength < Segmenter.MIN_SEGMENT_SIZE) {
                runLength += r.length
                entropySum += r.stats.entropy
                windowCount++
            } else {
                segments.add(
                    com.novacompress.bench.novacompress.segment.Segment(
                        runStart, runLength, SegmentStrategy.NOVA, runKind, entropySum / windowCount,
                    ),
                )
                runStart = r.offset
                runLength = r.length
                runKind = r.kind
                entropySum = r.stats.entropy
                windowCount = 1
            }
        }
        segments.add(
            com.novacompress.bench.novacompress.segment.Segment(
                runStart, runLength, SegmentStrategy.NOVA, runKind, entropySum / windowCount,
            ),
        )
        return segments
    }
}
