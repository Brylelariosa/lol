package com.novacompress.bench.novacompress.matcher

import android.os.Build
import com.novacompress.bench.novacompress.SearchBudget
import com.novacompress.bench.novacompress.dictionary.MultiLevelDictionary
import java.util.Arrays

/**
 * Finds repeated byte sequences across the whole buffer passed to [tokenize] - not a small fixed
 * sliding window like Deflate's 32KB, hence "long-range". Matches are tried against the
 * repeat-offset list first (cheap to encode), then a hash table.
 *
 * ## Two search strategies, chosen by input size
 *
 * [tokenize] dispatches on `data.size` against [LARGE_INPUT_THRESHOLD]:
 *
 *  - **Below the threshold** ([tokenizeSmall]/[bestMatchAtSmall]): the original matcher's exact
 *    algorithm - a single fixed-size (2^17 bucket) hash chain, walked up to [SMALL_MAX_CHAIN] deep,
 *    fresh arrays allocated per call. Measured to already be close to optimal at this scale: a
 *    128KB-ish segment's natural chain length is short regardless of table-sizing formula, so
 *    there's nothing here for a bigger table or a long-anchor fast path to win back, and every
 *    attempt at routing small inputs through the pooled/tiered machinery below (even a
 *    byte-for-byte equivalent reimplementation of this same algorithm, just parameterized instead
 *    of hardcoded) measured 15-35% *slower* on low-match-share small fixtures (`random.bin`, the
 *    BMP) - seemingly small differences like reading a hash-table size out of a passed-in
 *    parameter instead of a compile-time constant are enough to change what the JIT/ART compiler
 *    is willing to do with the hot loop. See BENCHMARKS.md Entry 6, "size-gating the new
 *    machinery" for the measurements this threshold is based on.
 *  - **At or above the threshold** ([tokenizeLarge]/[bestMatchAt]): the redesigned matcher this
 *    entry adds - a [MultiLevelDictionary] pooled per compression thread, an added 8-byte-anchor
 *    tier for O(1) long-match discovery, and an adaptive chain-depth cutback during sustained
 *    miss streaks. This is where all of it earns its cost: a real 16MB GBA ROM benchmark went
 *    from 2.76x/69.3s to a meaningfully faster compress with an equal-or-better ratio - see
 *    BENCHMARKS.md Entry 6 for the full numbers.
 *
 * 1 MiB was the smallest threshold that eliminated the small-fixture regression entirely in
 * testing; every one of the six built-in sample fixtures is well under it and therefore takes the
 * small path unchanged, while any real multi-megabyte file (or a same-chunk merge of many
 * segments) takes the large path.
 *
 * Both paths share [rankScore]'s cost-aware candidate ranking (a repeat-offset match beats a
 * modestly longer fresh one - see "Cost-aware candidate ranking" below) and the *same* lazy
 * matching shape: defer to the position one byte later for as long as it keeps strictly
 * improving, not a fixed lookahead depth. That chained-deferral behavior turned out to matter on
 * its own - an earlier version of the large path capped it at a fixed 2 steps (reasoning that
 * *bounding* an unbounded loop counts as "better lazy matching"), and that alone cost real ratio
 * for no speed benefit, because the original's chain is already exactly the right amount of
 * thorough: keep deferring only while it's still paying off, however many steps that takes.
 *
 * Token semantics are unchanged: a [Token.Match] still just says "copy this many bytes from this
 * distance back," so [MatchFieldCoder] and everything downstream needs no changes.
 *
 * ### Cost-aware candidate ranking
 *
 * Both paths' chain walk and lazy lookahead rank candidates by [rankScore], not raw byte length
 * alone, because [MatchFieldCoder] writes a distance already in the repeat-offset MRU cache as
 * one cheap slot symbol, but a fresh distance costs a slot symbol *plus* its raw extra bits (up
 * to ~17-18 for this codec's typical buffer sizes) - measured on `text.txt`/`executable.bin`,
 * that side channel alone was 76-94% of total output (BENCHMARKS.md, "matcher's parsing
 * strategy"). A textbook fix is genuine cost-based (LZMA-style optimal) parsing, but an analytic
 * bit-cost model tried first measurably *hurt* `executable.bin` - its literal byte distribution is
 * skewed enough (~87% of bytes drawn from a ~10-value opcode alphabet, the rest near-uniform)
 * that no single formula for "cost of a literal byte" fit both it and text/JSON/table well; see
 * BENCHMARKS.md for the two formulations that were tried and reverted. [rankScore] instead applies
 * only the part of that reasoning with no literal-byte-cost guesswork in it at all: a candidate's
 * *own* distance-encoding cost, computed exactly from [MatchFieldCoder]'s own slot/extra-bits
 * scheme (see [distanceCostBits]) and converted to a small, capped length-equivalent credit -
 * see [rankScore]'s own KDoc for the full reasoning and what shipped vs. what was tried and
 * reverted alongside it. Never rejects a match outright (MIN_MATCH is still the only accept/reject
 * floor for anyone) - only which candidate wins when more than one qualifies.
 */
object LongRangeMatcher {
    const val MIN_MATCH = 4
    private const val MAX_MATCH = 1 shl 18
    private const val MIX_CONST = -1640531535 // 0x9E3779B1 as signed Int

    // See "Cost-aware candidate ranking" above for how these were picked. CREDIT_MIN_LEN plays
    // the role the old REPEAT_BONUS_MIN_LEN did (below this, "somewhat shorter but cheaper" stops
    // being a safe bet) - kept at the same value since nothing about that reasoning changed.
    private const val CREDIT_MIN_LEN = 8
    private const val REP_HIT_BITS = 2
    private const val FRESH_SLOT_BITS = 4
    private const val CREDIT_CAP_BITS = 20
    private const val BITS_PER_CREDIT_UNIT = 9

    // See class KDoc "Two search strategies" for how this was chosen.
    private const val LARGE_INPUT_THRESHOLD = 1 shl 20 // 1 MiB

    private fun isRepeatDistance(distance: Int, rep: IntArray): Boolean =
        rep[0] == distance || rep[1] == distance || rep[2] == distance || rep[3] == distance

    /** Promotes [foundDist] to the front of the matcher's own repeat-offset MRU list (a *separate*
     *  list from [MatchFieldCoder]'s - see that class's KDoc), called once per accepted match. Was
     *  duplicated verbatim across all five tokenize* variants; unlike the per-position hot loops in
     *  [bestMatchAtSmall] and friends, this runs at most once per match (not once per byte scanned),
     *  so pulling it out here has no bearing on the JIT-sensitivity described in this file's class
     *  KDoc - safe to share. No-op if [foundDist] is already the most recent offset. */
    private fun updateRepOffsets(rep: IntArray, foundDist: Int) {
        if (foundDist == rep[0]) return
        val idx = rep.indexOf(foundDist).let { if (it < 0) rep.size - 1 else it }
        for (m in idx downTo 1) rep[m] = rep[m - 1]
        rep[0] = foundDist
    }

    /** [MatchFieldCoder]'s own distance encoding, exactly: a repeat-offset hit costs one slot
     *  symbol ([REP_HIT_BITS], a small constant approximation of that symbol's entropy-coded
     *  cost); a fresh distance costs a slot symbol plus `slotOf(distance) - 1` raw extra bits.
     *  Decode-derived, not a guess - no literal-byte-cost estimate anywhere in it, which is the
     *  part that broke the earlier analytic-cost attempt (see "Cost-aware candidate ranking"
     *  above) - ranking only ever compares one match candidate's own cost against another's, never
     *  a match against the literal bytes it would otherwise displace. */
    private fun distanceCostBits(distance: Int, rep: IntArray): Int {
        if (isRepeatDistance(distance, rep)) return REP_HIT_BITS
        val slot = 32 - Integer.numberOfLeadingZeros(distance)
        val extraBits = maxOf(0, slot - 1)
        return extraBits + FRESH_SLOT_BITS
    }

    /** Effective length used to rank match candidates against each other. Generalizes the old
     *  flat "+2 if repeat-offset and long enough" rule into a graduated credit based on
     *  [distanceCostBits], capped at [CREDIT_CAP_BITS] bits so it can only ever influence a close
     *  tie between comparably-long candidates, never override a genuine length advantage - the
     *  same role the old flat bonus played, just no longer blind to *how much* cheaper a
     *  repeat-offset (or any other nearby/cheap) distance is. Reduces to the exact old behavior at
     *  a repeat-offset hit: cost = [REP_HIT_BITS] = 2, credit = (20-2)/9 = 2 = the old flat bonus.
     *  Verified via this pass's Java-port testing to be ratio-neutral-to-positive on every fixture
     *  tried (records.json +0.5%, everything else +0.0%/unchanged, nothing negative) - see the
     *  accompanying report. A companion "limited optimal parsing" change (a bounded look-ahead
     *  window, trying to generalize the lazy-deferral check below the same way) was tried
     *  alongside this and reverted: it measured a consistent 5-11% ratio *regression* on
     *  text/JSON/table content by skipping past good nearby matches chasing marginally-better
     *  distant ones. Still never affects whether a match is accepted at all (MIN_MATCH is still
     *  the only floor) - only which candidate wins. Shared by both search strategies. */
    private fun rankScore(distance: Int, length: Int, rep: IntArray): Int {
        if (length < CREDIT_MIN_LEN) return length
        val cost = distanceCostBits(distance, rep)
        val credit = maxOf(0, CREDIT_CAP_BITS - minOf(cost, CREDIT_CAP_BITS)) / BITS_PER_CREDIT_UNIT
        return length + credit
    }

    private fun matchLenByte(d: ByteArray, p: Int, i: Int, n: Int): Int {
        var len = 0
        val max = minOf(MAX_MATCH, n - i)
        while (len < max && d[p + len] == d[i + len]) len++
        return len
    }

    // Distance/length packed into one Long's two halves instead of allocating a Token.Match for
    // every candidate considered - see bestMatchAt's KDoc. Both are well within 32 bits for any
    // realistic chunk size (CHUNK_SIZE is 16MB), so no information is lost.
    private const val NO_MATCH = -1L
    private fun packMatch(dist: Int, len: Int): Long = (dist.toLong() shl 32) or (len.toLong() and 0xFFFFFFFFL)
    private fun unpackDist(packed: Long): Int = (packed ushr 32).toInt()
    private fun unpackLen(packed: Long): Int = packed.toInt()

    /** [tier] defaults to [SearchBudget.Tier.HIGH] (this matcher's original, unconditional
     *  behavior) so any existing caller that doesn't pass one is unaffected. See [SearchBudget]'s
     *  KDoc for how a tier is picked and why it ships together with the RegionClassifier
     *  periodicity fix. */
    fun tokenize(data: ByteArray, tier: SearchBudget.Tier = SearchBudget.Tier.HIGH): List<Token> {
        val n = data.size
        if (n < LARGE_INPUT_THRESHOLD) {
            return when (tier) {
                SearchBudget.Tier.HIGH_TEXT -> tokenizeSmallDeepText(data, n)
                SearchBudget.Tier.HIGH -> tokenizeSmall(data, n)
                SearchBudget.Tier.MEDIUM -> tokenizeSmallMedium(data, n)
                SearchBudget.Tier.WEAK -> tokenizeSmallWeak(data, n)
                SearchBudget.Tier.MINIMAL -> tokenizeSmallMinimal(data, n)
            }
        }
        return tokenizeLarge(data, n, SearchBudget.chainFor(tier))
    }

    // ============================================================================================
    // Small-input path: the original matcher, unchanged in every behavioral detail - see class
    // KDoc "Two search strategies" for why this is a deliberate design choice of the new matcher
    // and not leftover legacy code. Kept as its own compact, self-contained pair of functions
    // (not a code path shared with the large-input machinery below) specifically so the JIT/ART
    // compiler sees the exact same small, simple hot loop shape this always had.
    // ============================================================================================

    private const val SMALL_HASH_BITS = 17
    private const val SMALL_HASH_SIZE = 1 shl SMALL_HASH_BITS
    private const val SMALL_MAX_CHAIN = 64

    private fun hash4Small(d: ByteArray, i: Int): Int {
        var h = ((d[i].toInt() and 0xFF) shl 24) or
            ((d[i + 1].toInt() and 0xFF) shl 16) or
            ((d[i + 2].toInt() and 0xFF) shl 8) or
            (d[i + 3].toInt() and 0xFF)
        h *= MIX_CONST
        return (h ushr (32 - SMALL_HASH_BITS)) and (SMALL_HASH_SIZE - 1)
    }

    private fun bestMatchAtSmall(data: ByteArray, i: Int, n: Int, head: IntArray, prev: IntArray, rep: IntArray): Long {
        if (i + MIN_MATCH > n) return NO_MATCH
        var bestLen = 0
        var bestDist = 0
        var bestScore = -1

        for (rd in rep) {
            if (rd <= i) {
                val len = matchLenByte(data, i - rd, i, n)
                if (len >= MIN_MATCH) {
                    val score = rankScore(rd, len, rep)
                    if (score > bestScore) { bestScore = score; bestLen = len; bestDist = rd }
                }
            }
        }

        val h = hash4Small(data, i)
        var cand = head[h]
        var depth = 0
        while (cand >= 0 && depth < SMALL_MAX_CHAIN) {
            val len = matchLenByte(data, cand, i, n)
            if (len >= MIN_MATCH) {
                val dist = i - cand
                val score = rankScore(dist, len, rep)
                if (score > bestScore) { bestScore = score; bestLen = len; bestDist = dist }
            }
            if (bestLen >= MAX_MATCH) break
            cand = prev[cand]
            depth++
        }
        prev[i] = head[h]
        head[h] = i

        return if (bestLen >= MIN_MATCH) packMatch(bestDist, bestLen) else NO_MATCH
    }

    private fun tokenizeSmall(data: ByteArray, n: Int): List<Token> {
        val tokens = ArrayList<Token>(n)
        val head = IntArray(SMALL_HASH_SIZE) { -1 }
        val prev = IntArray(n)
        val rep = intArrayOf(1, 2, 3, 4)

        var i = 0
        var pending = NO_MATCH
        while (i < n) {
            val found = if (pending != NO_MATCH) pending else bestMatchAtSmall(data, i, n, head, prev, rep)
            pending = NO_MATCH

            if (found != NO_MATCH) {
                val foundLen = unpackLen(found)
                val foundDist = unpackDist(found)

                // Lazy matching: keep deferring to one position later for as long as it's
                // strictly better - see class KDoc for why this must stay unbounded, not capped.
                val next = bestMatchAtSmall(data, i + 1, n, head, prev, rep)
                if (next != NO_MATCH && rankScore(unpackDist(next), unpackLen(next), rep) > rankScore(foundDist, foundLen, rep)) {
                    tokens.add(Token.literalOf(data[i]))
                    i++
                    pending = next
                    continue
                }

                tokens.add(Token.Match(foundDist, foundLen))
                updateRepOffsets(rep, foundDist)

                var p = i + 2
                while (p < i + foundLen && p + MIN_MATCH <= n) {
                    val ph = hash4Small(data, p)
                    prev[p] = head[ph]
                    head[ph] = p
                    p += 4
                }
                i += foundLen
            } else {
                tokens.add(Token.literalOf(data[i]))
                i++
            }
        }
        return tokens
    }

    // ---- HIGH_TEXT: same reasoning as the MEDIUM/WEAK/MINIMAL variants below (a separate,
    // compile-time-constant-chain-depth function rather than a runtime parameter - see that
    // section's comment for the measured 15-35% cost of the parameterized alternative on this
    // same code path) - kept as its own pair here rather than folded into that section since it's
    // conceptually "deeper than HIGH", not part of the "less than HIGH" ladder those three are.
    // See SearchBudget's KDoc "HIGH_TEXT" (BENCHMARKS.md Entry 12) for what this is for. ----

    private const val DEEP_TEXT_CHAIN = SearchBudget.CHAIN_HIGH_TEXT

    private fun bestMatchAtSmallDeepText(data: ByteArray, i: Int, n: Int, head: IntArray, prev: IntArray, rep: IntArray): Long {
        if (i + MIN_MATCH > n) return NO_MATCH
        var bestLen = 0
        var bestDist = 0
        var bestScore = -1
        for (rd in rep) {
            if (rd <= i) {
                val len = matchLenByte(data, i - rd, i, n)
                if (len >= MIN_MATCH) {
                    val score = rankScore(rd, len, rep)
                    if (score > bestScore) { bestScore = score; bestLen = len; bestDist = rd }
                }
            }
        }
        val h = hash4Small(data, i)
        var cand = head[h]
        var depth = 0
        while (cand >= 0 && depth < DEEP_TEXT_CHAIN) {
            val len = matchLenByte(data, cand, i, n)
            if (len >= MIN_MATCH) {
                val dist = i - cand
                val score = rankScore(dist, len, rep)
                if (score > bestScore) { bestScore = score; bestLen = len; bestDist = dist }
            }
            if (bestLen >= MAX_MATCH) break
            cand = prev[cand]
            depth++
        }
        prev[i] = head[h]
        head[h] = i
        return if (bestLen >= MIN_MATCH) packMatch(bestDist, bestLen) else NO_MATCH
    }

    private fun tokenizeSmallDeepText(data: ByteArray, n: Int): List<Token> {
        val tokens = ArrayList<Token>(n)
        val head = IntArray(SMALL_HASH_SIZE) { -1 }
        val prev = IntArray(n)
        val rep = intArrayOf(1, 2, 3, 4)
        var i = 0
        var pending = NO_MATCH
        while (i < n) {
            val found = if (pending != NO_MATCH) pending else bestMatchAtSmallDeepText(data, i, n, head, prev, rep)
            pending = NO_MATCH
            if (found != NO_MATCH) {
                val foundLen = unpackLen(found)
                val foundDist = unpackDist(found)
                val next = bestMatchAtSmallDeepText(data, i + 1, n, head, prev, rep)
                if (next != NO_MATCH && rankScore(unpackDist(next), unpackLen(next), rep) > rankScore(foundDist, foundLen, rep)) {
                    tokens.add(Token.literalOf(data[i]))
                    i++
                    pending = next
                    continue
                }
                tokens.add(Token.Match(foundDist, foundLen))
                updateRepOffsets(rep, foundDist)
                var p = i + 2
                while (p < i + foundLen && p + MIN_MATCH <= n) {
                    val ph = hash4Small(data, p)
                    prev[p] = head[ph]
                    head[ph] = p
                    p += 4
                }
                i += foundLen
            } else {
                tokens.add(Token.literalOf(data[i]))
                i++
            }
        }
        return tokens
    }

    // ---- MEDIUM/WEAK/MINIMAL tier variants of the pair above - see SearchBudget's KDoc for what
    // picks a tier, and this class's KDoc "Two search strategies" for why these are separate,
    // compile-time-constant-chain-depth functions rather than one function taking chain depth as
    // a parameter: that's exactly the "reading a value out of a parameter instead of a
    // compile-time constant" shape already measured to cost 15-35% on this same small-input path.
    // Each is textually near-identical to bestMatchAtSmall/tokenizeSmall above, differing only in
    // the chain-depth constant (and, for MINIMAL, dropping the hash table entirely - see
    // bestMatchRepOnly's KDoc). ----

    private const val MEDIUM_CHAIN = SearchBudget.CHAIN_MEDIUM
    private const val WEAK_CHAIN = SearchBudget.CHAIN_WEAK

    private fun bestMatchAtSmallMedium(data: ByteArray, i: Int, n: Int, head: IntArray, prev: IntArray, rep: IntArray): Long {
        if (i + MIN_MATCH > n) return NO_MATCH
        var bestLen = 0
        var bestDist = 0
        var bestScore = -1
        for (rd in rep) {
            if (rd <= i) {
                val len = matchLenByte(data, i - rd, i, n)
                if (len >= MIN_MATCH) {
                    val score = rankScore(rd, len, rep)
                    if (score > bestScore) { bestScore = score; bestLen = len; bestDist = rd }
                }
            }
        }
        val h = hash4Small(data, i)
        var cand = head[h]
        var depth = 0
        while (cand >= 0 && depth < MEDIUM_CHAIN) {
            val len = matchLenByte(data, cand, i, n)
            if (len >= MIN_MATCH) {
                val dist = i - cand
                val score = rankScore(dist, len, rep)
                if (score > bestScore) { bestScore = score; bestLen = len; bestDist = dist }
            }
            if (bestLen >= MAX_MATCH) break
            cand = prev[cand]
            depth++
        }
        prev[i] = head[h]
        head[h] = i
        return if (bestLen >= MIN_MATCH) packMatch(bestDist, bestLen) else NO_MATCH
    }

    private fun tokenizeSmallMedium(data: ByteArray, n: Int): List<Token> {
        val tokens = ArrayList<Token>(n)
        val head = IntArray(SMALL_HASH_SIZE) { -1 }
        val prev = IntArray(n)
        val rep = intArrayOf(1, 2, 3, 4)
        var i = 0
        var pending = NO_MATCH
        while (i < n) {
            val found = if (pending != NO_MATCH) pending else bestMatchAtSmallMedium(data, i, n, head, prev, rep)
            pending = NO_MATCH
            if (found != NO_MATCH) {
                val foundLen = unpackLen(found)
                val foundDist = unpackDist(found)
                val next = bestMatchAtSmallMedium(data, i + 1, n, head, prev, rep)
                if (next != NO_MATCH && rankScore(unpackDist(next), unpackLen(next), rep) > rankScore(foundDist, foundLen, rep)) {
                    tokens.add(Token.literalOf(data[i]))
                    i++
                    pending = next
                    continue
                }
                tokens.add(Token.Match(foundDist, foundLen))
                updateRepOffsets(rep, foundDist)
                var p = i + 2
                while (p < i + foundLen && p + MIN_MATCH <= n) {
                    val ph = hash4Small(data, p)
                    prev[p] = head[ph]
                    head[ph] = p
                    p += 4
                }
                i += foundLen
            } else {
                tokens.add(Token.literalOf(data[i]))
                i++
            }
        }
        return tokens
    }

    private fun bestMatchAtSmallWeak(data: ByteArray, i: Int, n: Int, head: IntArray, prev: IntArray, rep: IntArray): Long {
        if (i + MIN_MATCH > n) return NO_MATCH
        var bestLen = 0
        var bestDist = 0
        var bestScore = -1
        for (rd in rep) {
            if (rd <= i) {
                val len = matchLenByte(data, i - rd, i, n)
                if (len >= MIN_MATCH) {
                    val score = rankScore(rd, len, rep)
                    if (score > bestScore) { bestScore = score; bestLen = len; bestDist = rd }
                }
            }
        }
        val h = hash4Small(data, i)
        var cand = head[h]
        var depth = 0
        while (cand >= 0 && depth < WEAK_CHAIN) {
            val len = matchLenByte(data, cand, i, n)
            if (len >= MIN_MATCH) {
                val dist = i - cand
                val score = rankScore(dist, len, rep)
                if (score > bestScore) { bestScore = score; bestLen = len; bestDist = dist }
            }
            if (bestLen >= MAX_MATCH) break
            cand = prev[cand]
            depth++
        }
        prev[i] = head[h]
        head[h] = i
        return if (bestLen >= MIN_MATCH) packMatch(bestDist, bestLen) else NO_MATCH
    }

    private fun tokenizeSmallWeak(data: ByteArray, n: Int): List<Token> {
        val tokens = ArrayList<Token>(n)
        val head = IntArray(SMALL_HASH_SIZE) { -1 }
        val prev = IntArray(n)
        val rep = intArrayOf(1, 2, 3, 4)
        var i = 0
        var pending = NO_MATCH
        while (i < n) {
            val found = if (pending != NO_MATCH) pending else bestMatchAtSmallWeak(data, i, n, head, prev, rep)
            pending = NO_MATCH
            if (found != NO_MATCH) {
                val foundLen = unpackLen(found)
                val foundDist = unpackDist(found)
                val next = bestMatchAtSmallWeak(data, i + 1, n, head, prev, rep)
                if (next != NO_MATCH && rankScore(unpackDist(next), unpackLen(next), rep) > rankScore(foundDist, foundLen, rep)) {
                    tokens.add(Token.literalOf(data[i]))
                    i++
                    pending = next
                    continue
                }
                tokens.add(Token.Match(foundDist, foundLen))
                updateRepOffsets(rep, foundDist)
                var p = i + 2
                while (p < i + foundLen && p + MIN_MATCH <= n) {
                    val ph = hash4Small(data, p)
                    prev[p] = head[ph]
                    head[ph] = p
                    p += 4
                }
                i += foundLen
            } else {
                tokens.add(Token.literalOf(data[i]))
                i++
            }
        }
        return tokens
    }

    /** MINIMAL tier: rep-offset checks only, no hash table at all - item 1/6's "skip deep
     *  searching entirely" for regions the classifier is confident are already-compressed or
     *  encrypted. No hash table because nothing would ever walk it: every position in a
     *  MINIMAL-tier call gets this same treatment, so inserting into a table only MINIMAL-tier
     *  lookups would ever read from is pure overhead for zero benefit. */
    private fun bestMatchRepOnly(data: ByteArray, i: Int, n: Int, rep: IntArray): Long {
        if (i + MIN_MATCH > n) return NO_MATCH
        var bestLen = 0
        var bestDist = 0
        var bestScore = -1
        for (rd in rep) {
            if (rd <= i) {
                val len = matchLenByte(data, i - rd, i, n)
                if (len >= MIN_MATCH) {
                    val score = rankScore(rd, len, rep)
                    if (score > bestScore) { bestScore = score; bestLen = len; bestDist = rd }
                }
            }
        }
        return if (bestLen >= MIN_MATCH) packMatch(bestDist, bestLen) else NO_MATCH
    }

    private fun tokenizeSmallMinimal(data: ByteArray, n: Int): List<Token> {
        val tokens = ArrayList<Token>(n)
        val rep = intArrayOf(1, 2, 3, 4)
        var i = 0
        var pending = NO_MATCH
        while (i < n) {
            val found = if (pending != NO_MATCH) pending else bestMatchRepOnly(data, i, n, rep)
            pending = NO_MATCH
            if (found != NO_MATCH) {
                val foundLen = unpackLen(found)
                val foundDist = unpackDist(found)
                val next = bestMatchRepOnly(data, i + 1, n, rep)
                if (next != NO_MATCH && rankScore(unpackDist(next), unpackLen(next), rep) > rankScore(foundDist, foundLen, rep)) {
                    tokens.add(Token.literalOf(data[i]))
                    i++
                    pending = next
                    continue
                }
                tokens.add(Token.Match(foundDist, foundLen))
                updateRepOffsets(rep, foundDist)
                i += foundLen
            } else {
                tokens.add(Token.literalOf(data[i]))
                i++
            }
        }
        return tokens
    }

    // ============================================================================================
    // Large-input path: pooled MultiLevelDictionary + 8-byte-anchor tier + adaptive chain depth.
    // See class KDoc and BENCHMARKS.md Entry 6 for the full story.
    // ============================================================================================

    private const val TIER_ANCHOR_LEN = 8
    private const val EARLY_ACCEPT_LEN = 128 // a tier hit at least this long skips the chain walk
    // Normal (non-miss-streak) chain depth is now the caller's ceilChain (from SearchBudget,
    // SearchBudget.CHAIN_HIGH = 64 = this constant's old value by default - see bestMatchAt).
    private const val REDUCED_CHAIN = 1 // chain depth once in a sustained-miss streak
    private const val MISS_THRESHOLD = 16 // consecutive full misses before the cutback applies

    /** One [MultiLevelDictionary] per compression thread, reused across every `tokenize()` call
     *  that thread makes rather than rebuilt per call - see [MultiLevelDictionary]'s own KDoc for
     *  the full reasoning (chunks run on a bounded [kotlinx.coroutines.Dispatchers.Default] pool,
     *  and each chunk's segments/merge-trials/split-trials all call in sequence on one thread). */
    private val workspace = ThreadLocal.withInitial { MultiLevelDictionary() }

    // ---- fast match extension, used only for tier hits (see matchLenFast KDoc) ----

    /** `true` only from API 33 (`Build.VERSION_CODES.TIRAMISU`) onward - this app's `minSdk` is
     *  26, and [java.util.Arrays.mismatch] was added in API 33. Computed once, not per call. */
    private val hasArraysMismatch: Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU

    /** MurmurHash3's fmix64 finalizer - cheap, well-tested avalanche for mixing the 8-byte anchor
     *  read below. Written as decimal literals, not hex: Kotlin's hex `Long` literal parsing
     *  can't safely express a value with the sign bit set the same way Java's can (confirmed via
     *  independent reports of the same "value out of range" error against unrelated 16-hex-digit
     *  constants - see e.g. the Kotlin forum threads on this), so these are the plain decimal
     *  (signed 64-bit) form of the standard `0xff51afd7ed558ccd`/`0xc4ceb9fe1a85ec53` constants,
     *  verified to round-trip back to those exact hex digits before use. */
    private fun mixLong(x0: Long): Long {
        var x = x0
        x = x xor (x ushr 33); x *= -49064778989728563L
        x = x xor (x ushr 33); x *= -4265267296055464877L
        x = x xor (x ushr 33)
        return x
    }

    private fun readLongLE(d: ByteArray, off: Int): Long =
        (d[off].toLong() and 0xFF) or
            ((d[off + 1].toLong() and 0xFF) shl 8) or
            ((d[off + 2].toLong() and 0xFF) shl 16) or
            ((d[off + 3].toLong() and 0xFF) shl 24) or
            ((d[off + 4].toLong() and 0xFF) shl 32) or
            ((d[off + 5].toLong() and 0xFF) shl 40) or
            ((d[off + 6].toLong() and 0xFF) shl 48) or
            ((d[off + 7].toLong() and 0xFF) shl 56)

    private fun anchorHash8(d: ByteArray, i: Int): Long = mixLong(readLongLE(d, i))

    /** Extends a match already confirmed to share at least [TIER_ANCHOR_LEN] bytes (a tier hit),
     *  via [java.util.Arrays.mismatch] where available ([hasArraysMismatch]) and a plain byte
     *  loop otherwise. Deliberately *not* used for the short chain's rep-offset/4-byte-hash
     *  candidates ([matchLenByte] handles those) - those are usually short or entirely wrong (an
     *  ordinary 4-byte hash collides far more often than an 8-byte-anchor-derived one), so most
     *  calls there terminate within the first few bytes; a fast bulk-compare's fixed per-call
     *  setup cost isn't worth paying when the common case is "wrong after 2 bytes anyway". A tier
     *  hit is a different regime - the anchor already all but guarantees a real, and often long,
     *  match - which is where bulk comparison actually pays for itself.
     *
     *  Two different "compare more than one byte at a time" techniques were measured in an
     *  isolated microbenchmark before choosing this one (BENCHMARKS.md Entry 6):
     *  - Manually shifting/OR-ing 8 individual byte reads together into a `Long` to compare (no
     *    JDK 9+ API needed, maximum portability): measured *slower* than the plain byte loop it
     *    was meant to replace, consistent with Entry 5's original finding about `matchLen` - the
     *    construction overhead isn't recovered without a genuine hardware-backed bulk read.
     *  - `java.lang.invoke.VarHandle`'s byte-array-view accessors: measured ~2.7x faster than the
     *    byte loop (a genuine hardware-backed unaligned read), but `VarHandle`'s access-mode
     *    methods are *signature-polymorphic* - special compiler support most JVM languages other
     *    than Java have had to add deliberately (Scala's own writeup on this is explicit: it took
     *    dedicated compiler work landing in 2.11.5, refined further through 2.12.16/3.3.0).
     *    Whether Kotlin's compiler emits the correct call-site descriptor for this to actually
     *    resolve to the fast intrinsic path (rather than silently falling back to a slow, boxing
     *    reflective path, or failing to compile at all) could not be verified in this sandbox -
     *    there's no Kotlin compiler available here to check the emitted bytecode against, and
     *    search didn't turn up a definitive answer either way.
     *
     *  [java.util.Arrays.mismatch] sidesteps that whole question: it's an ordinary, non-polymorphic
     *  static method (`(byte[], int, int, byte[], int, int) -> int`), so there's no special
     *  compiler-support question to begin with, and it measured *faster* than the VarHandle
     *  version in the same microbenchmark (0.60ms vs 0.67ms best-of-6 over the same 71,979
     *  same-array same-length-distribution candidate pairs, 4-8192 bytes each) - almost certainly
     *  because the JDK/ART implementation is free to use a platform-appropriate vectorized
     *  comparison internally, which is exactly what this method exists for. Same API-33 floor as
     *  `VarHandle` either way, so this doesn't buy back any device coverage over that approach -
     *  it buys back confidence that the fast path is real. Correct for self-overlapping
     *  (distance < length) runs for the same reason the byte-loop version is: both sides index
     *  the same static source array, so the comparison is well-defined regardless of stride. */
    private fun matchLenFast(d: ByteArray, p: Int, i: Int, n: Int): Int {
        val max = minOf(MAX_MATCH, n - i)
        if (hasArraysMismatch) {
            val mismatch = Arrays.mismatch(d, p, p + max, d, i, i + max)
            return if (mismatch < 0) max else mismatch
        }
        var len = 0
        while (len < max && d[p + len] == d[i + len]) len++
        return len
    }

    /** Single-slot (no chain) 8-byte-anchor lookup - an O(1) fast path for long-match discovery
     *  that runs *before* the 4-byte chain walk below. A longer anchor collides far less often
     *  than a 4-byte one, so trusting only the most recent occurrence per bucket (no chain to
     *  walk) is enough to make hits reliable: ~76% of lookups that find *any* candidate turn into
     *  a real >= MIN_MATCH match on the 16MB GBA ROM benchmark (BENCHMARKS.md Entry 6). 16- and
     *  32-byte anchor tiers on top of this one were also tried; both measured worse ratio on
     *  `table.bin` specifically (a long anchor can align on a window that happens to skip a
     *  record's one varying byte, finding a *different*, non-repeat-offset candidate that
     *  out-scores the ideal repeat-offset match) for real added cost, so this ships with exactly
     *  one - see Entry 6 for the numbers behind dropping them. */
    private fun tryTier(data: ByteArray, i: Int, n: Int, tierHead: IntArray, tierHeadGen: IntArray, tierHashBits: Int, gen: Int): Long {
        if (i + TIER_ANCHOR_LEN > n) return NO_MATCH
        val h = anchorHash8(data, i)
        val bucket = ((h xor (h ushr 32)) and ((1L shl tierHashBits) - 1)).toInt()
        val cand = if (tierHeadGen[bucket] == gen) tierHead[bucket] else -1
        tierHead[bucket] = i
        tierHeadGen[bucket] = gen
        if (cand < 0 || cand >= i) return NO_MATCH
        val len = matchLenFast(data, cand, i, n)
        return if (len >= MIN_MATCH) packMatch(i - cand, len) else NO_MATCH
    }

    private fun hash4(d: ByteArray, i: Int, bits: Int): Int {
        var h = ((d[i].toInt() and 0xFF) shl 24) or
            ((d[i + 1].toInt() and 0xFF) shl 16) or
            ((d[i + 2].toInt() and 0xFF) shl 8) or
            (d[i + 3].toInt() and 0xFF)
        h *= MIX_CONST
        return (h ushr (32 - bits)) and ((1 shl bits) - 1)
    }

    /** Rep-offsets plus the 4-byte hash chain only - textually near-identical to
     *  [bestMatchAtSmall] above (same parameter shape, same two-phase structure, same body size),
     *  deliberately kept that small: an earlier version of this rewrite folded the tier lookup
     *  directly into this method, and that alone (nothing else changed) measured a uniform 8-15%
     *  slowdown across *every* fixture, including ones where the tier branch never even fired,
     *  because the bigger method body pushed this hot per-position function past the JIT's
     *  inlining size threshold. Splitting the tier lookup into [tryTier] and combining the two
     *  results one level up in [bestMatchAt] recovered it - see BENCHMARKS.md Entry 6, "method
     *  size and inlining". */
    private fun bestMatchCore(
        data: ByteArray, i: Int, n: Int,
        shortHead: IntArray, shortHeadGen: IntArray, prev: IntArray, shortHashBits: Int, gen: Int,
        rep: IntArray, effChain: Int
    ): Long {
        if (i + MIN_MATCH > n) return NO_MATCH
        var bestLen = 0
        var bestDist = 0
        var bestScore = -1

        for (rd in rep) {
            if (rd <= i) {
                val len = matchLenByte(data, i - rd, i, n)
                if (len >= MIN_MATCH) {
                    val score = rankScore(rd, len, rep)
                    if (score > bestScore) { bestScore = score; bestLen = len; bestDist = rd }
                }
            }
        }

        val h = hash4(data, i, shortHashBits)
        val headVal = if (shortHeadGen[h] == gen) shortHead[h] else -1
        var cand = headVal
        var depth = 0
        while (cand >= 0 && depth < effChain) {
            val len = matchLenByte(data, cand, i, n)
            if (len >= MIN_MATCH) {
                val dist = i - cand
                val score = rankScore(dist, len, rep)
                if (score > bestScore) { bestScore = score; bestLen = len; bestDist = dist }
            }
            if (bestLen >= MAX_MATCH) break
            cand = prev[cand]
            depth++
        }
        prev[i] = headVal
        shortHead[h] = i
        shortHeadGen[h] = gen

        return if (bestLen >= MIN_MATCH) packMatch(bestDist, bestLen) else NO_MATCH
    }

    private fun pickBetter(a: Long, b: Long, rep: IntArray): Long {
        if (a == NO_MATCH) return b
        if (b == NO_MATCH) return a
        return if (rankScore(unpackDist(b), unpackLen(b), rep) > rankScore(unpackDist(a), unpackLen(a), rep)) b else a
    }

    /** Combines [tryTier] and [bestMatchCore]. A tier hit already at least [EARLY_ACCEPT_LEN]
     *  bytes long skips the chain walk entirely (further searching is very unlikely to beat an
     *  already-long match, and definitely isn't worth a 64-candidate walk to find out) - both a
     *  speed win (item 5/6: fewer hash lookups in the common "already found something great"
     *  case) and safe for ratio, since it only ever *adds* a candidate to what the chain walk
     *  would have found anyway via [pickBetter], never removes one, except in that specific
     *  provably-good-enough case.
     *
     *  [missCounter] is a single-element array used as a mutable out-parameter across the whole
     *  `tokenize()` call: once [MISS_THRESHOLD] consecutive positions have found *nothing* at all
     *  (not even a short chain match), the tier lookup is skipped and the chain walk's depth
     *  drops to [REDUCED_CHAIN] until something matches again. This is the "early-exit heuristic
     *  for incompressible regions" item 6 asks for, but shaped differently from the first attempt
     *  at it (BENCHMARKS.md Entry 5, "stall-based early exit within one chain walk", which
     *  measurably hurt ratio because cutting a *single* promising-looking walk short can miss a
     *  genuinely better, deeper candidate for a position that *does* have real repeats nearby).
     *  This version only cuts back after many *consecutive, unrelated* positions have all found
     *  nothing - evidence about a whole *region*, not one position's search - which is exactly
     *  the situation the tier lookup's fixed per-position cost (computing an 8-byte hash that
     *  will almost certainly land on an empty or useless bucket) stops paying for itself: measured
     *  as the difference between a real slowdown and a real speedup on `random.bin`/the BMP once
     *  applied - see Entry 6. */
    private fun bestMatchAt(
        data: ByteArray, i: Int, n: Int,
        shortHead: IntArray, shortHeadGen: IntArray, prev: IntArray, shortHashBits: Int,
        tierHead: IntArray, tierHeadGen: IntArray, tierHashBits: Int,
        gen: Int, rep: IntArray, missCounter: IntArray, ceilChain: Int
    ): Long {
        if (i + MIN_MATCH > n) return NO_MATCH
        val skipTier = missCounter[0] > MISS_THRESHOLD
        val tierResult = if (skipTier) NO_MATCH else tryTier(data, i, n, tierHead, tierHeadGen, tierHashBits, gen)

        val found = if (tierResult != NO_MATCH && unpackLen(tierResult) >= EARLY_ACCEPT_LEN) {
            tierResult
        } else {
            // ceilChain (from SearchBudget, per class/region) caps the normal depth; the existing
            // miss-streak reactive cutback still applies underneath that ceiling, never above it.
            val effChain = if (missCounter[0] > MISS_THRESHOLD) minOf(REDUCED_CHAIN, ceilChain) else ceilChain
            val core = bestMatchCore(data, i, n, shortHead, shortHeadGen, prev, shortHashBits, gen, rep, effChain)
            pickBetter(tierResult, core, rep)
        }

        missCounter[0] = if (found == NO_MATCH) missCounter[0] + 1 else 0
        return found
    }

    private fun insertOnly(
        data: ByteArray, p: Int, n: Int,
        shortHead: IntArray, shortHeadGen: IntArray, prev: IntArray, shortHashBits: Int,
        tierHead: IntArray, tierHeadGen: IntArray, tierHashBits: Int, gen: Int
    ) {
        if (p + MIN_MATCH <= n) {
            val h = hash4(data, p, shortHashBits)
            prev[p] = if (shortHeadGen[h] == gen) shortHead[h] else -1
            shortHead[h] = p
            shortHeadGen[h] = gen
        }
        if (p + TIER_ANCHOR_LEN <= n) {
            val h = anchorHash8(data, p)
            val bucket = ((h xor (h ushr 32)) and ((1L shl tierHashBits) - 1)).toInt()
            tierHead[bucket] = p
            tierHeadGen[bucket] = gen
        }
    }

    private fun tokenizeLarge(data: ByteArray, n: Int, ceilChain: Int): List<Token> {
        val dict = workspace.get()
        dict.beginCall(n)
        val shortHead = dict.shortHead
        val shortHeadGen = dict.shortHeadGen
        val prev = dict.prev
        val shortHashBits = dict.shortHashBits
        val tierHead = dict.tierHead
        val tierHeadGen = dict.tierHeadGen
        val tierHashBits = dict.tierHashBits
        val gen = dict.generation
        val rep = dict.repDistances

        val tokens = ArrayList<Token>(n)
        val missCounter = IntArray(1)

        var i = 0
        var pending = NO_MATCH
        while (i < n) {
            val found = if (pending != NO_MATCH) pending else {
                bestMatchAt(data, i, n, shortHead, shortHeadGen, prev, shortHashBits, tierHead, tierHeadGen, tierHashBits, gen, rep, missCounter, ceilChain)
            }
            pending = NO_MATCH

            if (found != NO_MATCH) {
                val foundLen = unpackLen(found)
                val foundDist = unpackDist(found)

                // Same unbounded chained-deferral lazy matching as tokenizeSmall - see class KDoc.
                val next = if (i + 1 < n) {
                    bestMatchAt(data, i + 1, n, shortHead, shortHeadGen, prev, shortHashBits, tierHead, tierHeadGen, tierHashBits, gen, rep, missCounter, ceilChain)
                } else NO_MATCH
                if (next != NO_MATCH && rankScore(unpackDist(next), unpackLen(next), rep) > rankScore(foundDist, foundLen, rep)) {
                    tokens.add(Token.literalOf(data[i]))
                    i++
                    pending = next
                    continue
                }

                tokens.add(Token.Match(foundDist, foundLen))
                updateRepOffsets(rep, foundDist)

                var p = i + 2
                while (p < i + foundLen && p + MIN_MATCH <= n) {
                    insertOnly(data, p, n, shortHead, shortHeadGen, prev, shortHashBits, tierHead, tierHeadGen, tierHashBits, gen)
                    p += 4
                }
                i += foundLen
            } else {
                tokens.add(Token.literalOf(data[i]))
                i++
            }
        }
        return tokens
    }
}
