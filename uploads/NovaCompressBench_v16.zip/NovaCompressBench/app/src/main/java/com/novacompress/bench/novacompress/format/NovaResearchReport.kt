package com.novacompress.bench.novacompress.format

import com.novacompress.bench.novacompress.segment.Segment

/**
 * Aggregated Stage-1-through-10 telemetry across every chunk of one
 * compress run, for the spec's "Research Mode" screen: entropy
 * before/after, detected structures, prediction accuracy, dictionary
 * activity. Everything here is a real by-product of compression, not a
 * separate estimation pass.
 */
data class NovaResearchReport(
    val chunkStats: List<ChunkResearchStats>,
    val originalSize: Long,
    val compressedSize: Long,
    /** Which source file this report belongs to. Left blank by
     *  [com.novacompress.bench.novacompress.NovaCompressAlgorithm.compressWithReport]
     *  itself (it only sees streams, not names) and filled in afterwards via
     *  [copy] by whoever calls it with a known source - see
     *  [com.novacompress.bench.ui.BenchmarkViewModel.runBenchmark], which does
     *  this once per sample when running a batch of multiple built-in
     *  samples so Research Mode can label each report. */
    val sourceName: String = "",
) {
    val totalTokens: Int get() = chunkStats.sumOf { it.tokenCount }
    val totalMatchTokens: Int get() = chunkStats.sumOf { it.matchTokenCount }
    val totalPredictHits: Int get() = chunkStats.sumOf { it.predictHitCount }
    val totalNovaInputBytes: Long get() = chunkStats.sumOf { it.novaInputBytes.toLong() }
    val totalStoreInputBytes: Long get() = chunkStats.sumOf { it.storeInputBytes.toLong() }
    val allSegments: List<Segment> get() = chunkStats.flatMap { it.segments }

    /** Prediction hit rate among literal (non-match) tokens - the tokens
     *  where a prediction was actually attempted. */
    val predictionAccuracy: Double
        get() {
            val literalTokens = chunkStats.sumOf { it.tokenCount - it.matchTokenCount }
            return if (literalTokens <= 0) 0.0 else totalPredictHits.toDouble() / literalTokens
        }

    val overallRatio: Double
        get() = if (compressedSize == 0L) 0.0 else originalSize.toDouble() / compressedSize
}
