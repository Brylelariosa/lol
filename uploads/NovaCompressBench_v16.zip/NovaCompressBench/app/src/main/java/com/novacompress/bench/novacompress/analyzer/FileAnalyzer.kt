package com.novacompress.bench.novacompress.analyzer

data class Region(
    val offset: Int,
    val length: Int,
    val kind: RegionKind,
    val stats: RegionStats,
)

/**
 * Stage 1 of the pipeline ("File Analyzer" in the spec): scans a buffer in
 * fixed windows, classifying each one, and sniffs known file-format magic
 * bytes at the very start. The result is a "file structure map" that
 * [com.novacompress.bench.novacompress.segment.Segmenter] merges into
 * variable-length segments.
 *
 * Windowed rather than whole-buffer so mixed files (e.g. an APK containing
 * both compressed entries and a bit of manifest text) get a structure map
 * that actually reflects the mix, not one average classification - but
 * only for structure at least as coarse as [WINDOW_SIZE]. Any window that
 * straddles a boundary between two differently-classified regions blends
 * both regions' stats into one classification for the whole window, which
 * can hide the boundary entirely rather than just blurring it: tested
 * against a file alternating same-size text and high-entropy blocks, a
 * window >= the block size reported the *entire* file as one uniform
 * region every time (0 bytes routed to STORE out of a file that was 50%
 * high-entropy content), regardless of how many multiples larger the
 * window was - it's specifically window-vs-block-size that matters, not
 * window-vs-file-size. The former 64KB default was comfortably larger than
 * that in most realistic mixed files (individual APK entries, embedded
 * resources, etc. are very often smaller than 64KB), which is why
 * segmentation rarely did anything on this kind of input. 4KB isn't a
 * guarantee for arbitrarily fine structure - the same failure mode returns
 * for structure smaller than *this* window - but it resolves the case
 * above and any coarser one, and classification was checked for stability
 * down to 1KB windows on uniform content, so this isn't trading away
 * reliability on the common case to get there.
 */
object FileAnalyzer {
    const val WINDOW_SIZE = 4 * 1024

    fun analyze(data: ByteArray): List<Region> {
        if (data.isEmpty()) return emptyList()
        val regions = ArrayList<Region>()
        val magic = RegionClassifier.sniffMagic(data)

        var offset = 0
        var first = true
        while (offset < data.size) {
            val length = minOf(WINDOW_SIZE, data.size - offset)
            val (statKind, stats) = RegionClassifier.classify(data, offset, length)
            val kind = if (first && magic != null) magic else statKind
            regions.add(Region(offset, length, kind, stats))
            offset += length
            first = false
        }
        return regions
    }
}
