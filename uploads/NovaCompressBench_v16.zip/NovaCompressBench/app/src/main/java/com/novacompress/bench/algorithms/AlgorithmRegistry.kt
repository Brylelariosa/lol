package com.novacompress.bench.algorithms

import com.novacompress.bench.core.CompressionAlgorithm
import com.novacompress.bench.novacompress.NovaCompressAlgorithm

object AlgorithmRegistry {
    /** All algorithms known to the app, standard and experimental. Order here
     *  is the default display/benchmark order. */
    fun all(): List<CompressionAlgorithm> = listOf(
        DeflateAlgorithm(),
        Bzip2Algorithm(),
        Lzma2Algorithm(),
        Lz4Algorithm(),
        ZstdAlgorithm(),
        SnappyAlgorithm(),
        BrotliAlgorithm(),
        NovaCompressAlgorithm(),
    )

    fun standard(): List<CompressionAlgorithm> =
        all().filter { it.category == com.novacompress.bench.core.AlgorithmCategory.STANDARD }

    fun experimental(): List<CompressionAlgorithm> =
        all().filter { it.category == com.novacompress.bench.core.AlgorithmCategory.EXPERIMENTAL }

    fun byId(id: String): CompressionAlgorithm? = all().find { it.id == id }
}
