package com.novacompress.bench

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.novacompress.bench.ui.BenchmarkViewModel
import com.novacompress.bench.ui.navigation.NovaNavGraph
import com.novacompress.bench.ui.theme.NovaCompressTheme

class MainActivity : ComponentActivity() {
    // No handling needed for a denial - KeepAliveService.updateProgress() is a no-op without the
    // permission, and starting the foreground service itself (the part that actually keeps the
    // process alive during a benchmark run) doesn't depend on this being granted - see that
    // service's KDoc. Denying this just means the person won't see live progress in the
    // notification tray while backgrounded, not that backgrounding becomes unsafe again.
    private val requestNotificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* result intentionally unused - see above */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestNotificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        val container = (application as NovaCompressApp).container
        val factory = BenchmarkViewModel.factory(container)

        setContent {
            NovaCompressBenchApp(factory)
        }
    }
}

@Composable
private fun NovaCompressBenchApp(factory: androidx.lifecycle.ViewModelProvider.Factory) {
    NovaCompressTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
            NovaNavGraph(viewModelFactory = factory)
        }
    }
}
