package com.novacompress.bench.novacompress

import com.novacompress.bench.novacompress.analyzer.RegionKind

/**
 * "Adaptive search budget": maps a segment's already-computed classifier signal (dominant
 * [RegionKind] + average entropy - both computed during segmentation, nothing new to measure) to
 * how many hash-chain candidates [com.novacompress.bench.novacompress.matcher.LongRangeMatcher]
 * spends per position. Computed once per [NovaSegmentCodec.encode] call, never inside the
 * matcher's hot per-position loop.
 *
 * Tier chain depths scale the spec's own illustrative 256/64/16/skip example down to this
 * codebase's already-tuned ceiling (MAX_CHAIN = 64, proven across five prior BENCHMARKS.md
 * entries) using the same 4x-per-step shape: 64 / 16 / 4 / 0.
 *
 * This ships together with the RegionClassifier periodicity fix (see its KDoc), not behind an
 * independent toggle: search effort is only safe to cut *because* the classification driving it
 * is more trustworthy now. Verified directly - running the search-budget tiers against the
 * *unfixed* classifier in this pass's Java-port testing (see the accompanying report) collapsed
 * synthetic_table.bin from 14.45x to 4.63x, because its still-misclassified
 * ALREADY_COMPRESSED_OR_ENCRYPTED segment got routed to MINIMAL effort instead of the HIGH effort
 * its real (periodic, highly matchable) content needs. With the classifier fix in place, that
 * same content classifies REPETITIVE_BINARY and correctly gets HIGH effort - table.bin's ratio is
 * unaffected (14.45x -> 14.45x) while its redundant store-trial-then-promote encode is eliminated.
 *
 * ## HIGH_TEXT (BENCHMARKS.md Entry 12)
 *
 * The "already-tuned ceiling" language above turned out to describe a narrower finding than it
 * reads as: every prior entry that touched `MAX_CHAIN` either tried *reducing* effective search
 * depth for speed (Entry 5's stall-based early exit - measured a real ratio cost, rejected) or
 * addressed a *different* problem entirely (Entry 7's fixed-size hash table becoming crowded on
 * large inputs, fixed by growing the table, not by raising the depth ceiling). None had actually
 * tested *raising* the small-input path's 64-candidate ceiling to see whether ratio improves - see
 * Entry 12's Java-port testing for why that turned out to matter: on content shaped like natural
 * text or JSON (a large, non-repetitive vocabulary), a handful of very common short sequences (a
 * frequent word, common punctuation) can accumulate far more than 64 occurrences within a single
 * segment even though the *average* chain length across the whole hash table stays low - meaning
 * MAX_CHAIN=64 was truncating those specific chains long before reaching a genuinely better,
 * further-back candidate, for exactly the content type where matches are hardest (and therefore
 * most valuable) to find. [Tier.HIGH_TEXT] is a *new*, deeper ceiling reached only from
 * [RegionKind.TEXT]/[RegionKind.STRUCTURED_TEXT] classified content, not a change to [Tier.HIGH]
 * itself - [RegionKind.REPETITIVE_BINARY] content (table-like/periodic data) measured *worse* with
 * deeper search in the same testing (already well-served by the cheap repeat-offset check that
 * runs before any hash-chain walk at all - see [com.novacompress.bench.novacompress.entropy.MatchFieldCoder]),
 * so it deliberately keeps the existing, unchanged [Tier.HIGH] budget.
 *
 * ## Dropping the entropy gate on TEXT/STRUCTURED_TEXT (BENCHMARKS.md Entry 13)
 *
 * The `avgEntropy < 4.5` condition [Tier.HIGH_TEXT] originally shipped behind (Entry 12) turned
 * out to exclude most real source code and prose from the deeper tier entirely: real Kotlin files
 * from this project measured 4.5-5.0 bits/byte, real markdown (this file's own KDoc included, by
 * extension) 4.7-4.9 - both *at or above* the cutoff, meaning that content was landing in
 * [Tier.MEDIUM] (chain=16, *shallower* than even the pre-Entry-12 default) rather than benefiting
 * from any of this class's search-depth work at all. Tested directly rather than assumed safe:
 * real Kotlin source (~154KB, this project's own matcher/codec/entropy files) and two real
 * markdown files gained +1.0-1.4% from the same deeper search, zero regression, chain-depth
 * ceiling landing in the same 256-512 range Entry 12 already validated - the entropy gate wasn't
 * protecting against a real risk for this [RegionKind], just excluding real content from a benefit
 * that applies to it too. [Tier.MEDIUM]'s `avgEntropy >= 7.0` guard on
 * [RegionKind.BINARY_UNKNOWN] is a different, still-justified case - unlike TEXT/STRUCTURED_TEXT,
 * that classification's high-entropy content plausibly includes genuinely incompressible data
 * (already-compressed streams the classifier didn't otherwise catch), where the regression risk
 * profile hasn't been tested and shouldn't be assumed to match this entry's findings.
 */
object SearchBudget {
    /** Declaration order is load-bearing: [com.novacompress.bench.novacompress.format.NovaContainerFormat.hintForRun]
     *  picks the smallest [Tier.ordinal] across a run of merged segments as "the most generous
     *  tier, so a merge never under-searches a segment that needed more effort than its neighbor" -
     *  [HIGH_TEXT] has to sort before [HIGH] for that comparison to treat it as strictly more
     *  generous, which is exactly what it is (a deeper ceiling than [HIGH], not an unrelated one). */
    enum class Tier { HIGH_TEXT, HIGH, MEDIUM, WEAK, MINIMAL }

    /** See [Tier] KDoc "HIGH_TEXT" - 512 was chosen from Entry 12's Java-port sweep as capturing
     *  ~98% of the measured achievable ratio gain on both text- and JSON-shaped content (further
     *  depth past this point showed diminishing-to-flat returns on both) while staying well short
     *  of the largest tested depth (1024)'s additional, less-justified compress-time cost. */
    const val CHAIN_HIGH_TEXT = 512
    const val CHAIN_HIGH = 64    // == existing MAX_CHAIN / SMALL_MAX_CHAIN, unchanged default
    const val CHAIN_MEDIUM = 16
    const val CHAIN_WEAK = 4
    const val CHAIN_MINIMAL = 0  // rep-offset checks only - no hash chain walk at all

    fun chainFor(tier: Tier): Int = when (tier) {
        Tier.HIGH_TEXT -> CHAIN_HIGH_TEXT
        Tier.HIGH -> CHAIN_HIGH
        Tier.MEDIUM -> CHAIN_MEDIUM
        Tier.WEAK -> CHAIN_WEAK
        Tier.MINIMAL -> CHAIN_MINIMAL
    }

    fun tierFor(kind: RegionKind, avgEntropy: Double): Tier = when (kind) {
        RegionKind.ALREADY_COMPRESSED_OR_ENCRYPTED -> Tier.MINIMAL
        RegionKind.REPETITIVE_BINARY -> Tier.HIGH
        RegionKind.TEXT, RegionKind.STRUCTURED_TEXT -> Tier.HIGH_TEXT
        // The matcher rarely carries image-like content on its own (ContextPredictor typically
        // does the heavy lifting there - e.g. synthetic_image.bmp's match share is ~0.1% against
        // an 83% prediction-hit rate), so a reduced budget costs little; kept at MEDIUM rather
        // than WEAK/MINIMAL as a safety margin since real (non-synthetic) images can have more
        // matcher-friendly structure (large flat regions, tiling) than this pass's test fixture.
        RegionKind.IMAGE_LIKE -> Tier.MEDIUM
        RegionKind.EXECUTABLE_LIKE -> Tier.MEDIUM
        RegionKind.BINARY_UNKNOWN -> if (avgEntropy >= 7.0) Tier.WEAK else Tier.MEDIUM
    }
}
