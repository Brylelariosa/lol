package com.novacompress.bench.ui.screens.home

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.novacompress.bench.benchmark.BenchmarkSource
import com.novacompress.bench.benchmark.UriBenchmarkSource
import com.novacompress.bench.core.AlgorithmCategory
import com.novacompress.bench.dataset.SampleDataset
import com.novacompress.bench.dataset.SampleDatasetGenerator
import com.novacompress.bench.ui.BenchmarkViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: BenchmarkViewModel,
    onRunComplete: () -> Unit,
    onOpenHistory: () -> Unit,
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()

    // Generated once and reused across recompositions (rather than calling
    // SampleDatasetGenerator.all() again on every recomposition), so
    // selection-state comparisons below always compare a sample against the
    // exact same instance shown in this list. That matters because
    // SampleDataset is a data class holding a ByteArray - two *separately
    // generated* instances aren't guaranteed to be `equal` (ByteArray
    // compares by reference), so a stable instance is what makes the
    // "is this sample checked?" lookup and the toggle in the ViewModel
    // reliable.
    val samples = remember { SampleDatasetGenerator.all() }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.addSource(UriBenchmarkSource(context, uri))
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("NovaCompress Bench") },
                actions = {
                    IconButton(onClick = onOpenHistory) {
                        Icon(Icons.Filled.History, contentDescription = "History")
                    }
                },
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text("Selected sources", style = MaterialTheme.typography.titleMedium)
                            if (uiState.sources.isNotEmpty()) {
                                TextButton(onClick = { viewModel.clearSources() }) { Text("Clear all") }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        if (uiState.sources.isEmpty()) {
                            Text(
                                "No sources selected yet",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        } else {
                            uiState.sources.forEach { src ->
                                SelectedSourceRow(source = src, onRemove = { viewModel.removeSource(src) })
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        OutlinedButton(onClick = { filePicker.launch(arrayOf("*/*")) }) {
                            Icon(Icons.Filled.Folder, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Add a file (APK, ZIP, image, ROM, video, anything)")
                        }
                    }
                }
            }

            item {
                Card {
                    Column(Modifier.padding(16.dp)) {
                        Text("Or try built-in samples", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Synthetic test files spanning the entropy/structure spectrum - not real copyrighted content. " +
                                "Check as many as you like to benchmark them together in one batch.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Spacer(Modifier.height(12.dp))
                        samples.forEach { sample ->
                            SampleSelectRow(
                                sample = sample,
                                checked = uiState.sources.contains(sample),
                                onToggle = { viewModel.toggleSample(sample) },
                            )
                        }
                    }
                }
            }

            item {
                Card {
                    Column(Modifier.padding(16.dp)) {
                        Text("Algorithms to benchmark", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        viewModel.algorithms.forEach { algo ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Checkbox(
                                    checked = algo.id in uiState.selectedAlgorithmIds,
                                    onCheckedChange = { viewModel.toggleAlgorithm(algo.id) },
                                )
                                Column {
                                    Text(algo.displayName, style = MaterialTheme.typography.bodyLarge)
                                    if (algo.category == AlgorithmCategory.EXPERIMENTAL) {
                                        Text(
                                            "Experimental",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.primary,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            uiState.errorMessage?.let { error ->
                item {
                    Text(error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                }
            }

            if (uiState.isRunning) {
                item {
                    Column(Modifier.fillMaxWidth()) {
                        val progress = if (uiState.progressTotal > 0) {
                            uiState.progressCompleted.toFloat() / uiState.progressTotal.toFloat()
                        } else {
                            0f
                        }
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            uiState.progressCurrentName?.let {
                                "Running $it (${uiState.progressCompleted + 1}/${uiState.progressTotal})"
                            } ?: "Starting benchmark…",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            item {
                FilledTonalButton(
                    onClick = { viewModel.runBenchmark(onRunComplete) },
                    enabled = uiState.sources.isNotEmpty() && uiState.selectedAlgorithmIds.isNotEmpty() && !uiState.isRunning,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    if (uiState.isRunning) {
                        Text("Running…")
                    } else {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            if (uiState.sources.size > 1) {
                                "Run Benchmark (${uiState.sources.size} sources)"
                            } else {
                                "Run Benchmark"
                            },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SelectedSourceRow(source: BenchmarkSource, onRemove: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Column(Modifier.weight(1f)) {
            Text(source.displayName, style = MaterialTheme.typography.bodyLarge)
            if (source.sizeBytes >= 0) {
                Text(
                    formatBytes(source.sizeBytes),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Spacer(Modifier.width(8.dp))
        IconButton(onClick = onRemove) {
            Icon(Icons.Filled.Close, contentDescription = "Remove ${source.displayName}")
        }
    }
}

@Composable
private fun SampleSelectRow(sample: SampleDataset, checked: Boolean, onToggle: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Checkbox(checked = checked, onCheckedChange = { onToggle() })
        Column(Modifier.weight(1f)) {
            Text(sample.name, style = MaterialTheme.typography.bodyLarge)
            Text(sample.description, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

internal fun formatBytes(bytes: Long): String {
    if (bytes < 0) return "unknown size"
    if (bytes < 1024) return "$bytes B"
    val units = listOf("KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var unitIndex = -1
    while (value >= 1024 && unitIndex < units.size - 1) {
        value /= 1024
        unitIndex++
    }
    return "%.1f %s".format(value, units[unitIndex])
}
