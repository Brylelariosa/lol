package com.novacompress.bench.novacompress.segment

import com.novacompress.bench.novacompress.analyzer.Region
import com.novacompress.bench.novacompress.analyzer.RegionKind

enum class SegmentStrategy { STORE, NOVA }

data class Segment(
    val offset: Int,
    val length: Int,
    val strategy: SegmentStrategy,
    val dominantKind: RegionKind,
    val avgEntropy: Double,
)

/**
 * Stage 2 ("Adaptive Segmentation" in the spec): merges the analyzer's
 * fixed-size classified windows into variable-length segments, each
 * assigned a strategy.
 *
 * Two things decide a segment boundary:
 *
 * 1. A STORE<->NOVA strategy change (as before - STORE is for regions the
 *    analyzer flagged as already-high-entropy; see [strategyFor]) always
 *    splits immediately. This isn't a tunable heuristic: literal bytes and
 *    an encoded block aren't interchangeable, so the boundary is
 *    structurally required regardless of how similar the neighboring
 *    content looks.
 * 2. A *structural* change - the window's [RegionKind] differs from the
 *    current run's, or its entropy has drifted more than
 *    [ENTROPY_DELTA_THRESHOLD] bits/byte from the run's average so far -
 *    splits once the current run has reached [MIN_SEGMENT_SIZE], gated so
 *    a single noisy window can't fragment the file into segments too small
 *    to be worth their own block. Kind changes catch the "different
 *    family of content" case directly (prose text next to a repetitive
 *    binary table, next to image pixel data, ...); the entropy check
 *    catches drift *within* one kind family that a coarse kind bucket
 *    alone would miss (verified directly: two same-kind synthetic regions
 *    with a deliberate entropy jump between them split correctly, and
 *    tightening the threshold past the jump's size correctly stops
 *    splitting them - see SegmenterTest).
 *
 * Splitting here only produces *candidate* segment boundaries - RegionKind
 * and entropy are read-only classifier signals, useful proxies for "this
 * content is statistically different from its neighbor" but not a
 * guarantee that encoding it separately actually pays for itself once
 * [MatchFieldCoder]-style per-block framing overhead and a fresh model's
 * warm-up cost are accounted for. [NovaContainerFormat.encodeChunk] is
 * where that's actually decided: every run of consecutive NOVA-strategy
 * segments this produces gets trial-encoded both as one merged block and
 * as separate per-segment blocks, and only kept split if that's smaller.
 * Segmenter's job is narrower than the class name suggests, in other
 * words: propose plausible boundaries from structural signals; leave
 * "does this actually help" to an encoder that can just measure it.
 *
 * Benchmarked on six single-character-family files (unchanged from
 * before - one segment each, both before and after this rewrite) and six
 * deliberately heterogeneous ones (before this rewrite, every one of these
 * was reported as one or two segments regardless of how many genuinely
 * different regions it actually contained, because only the STORE/NOVA
 * split could ever produce a boundary): splitting on structural transitions
 * gave a real compression benefit on files that actually contain more than
 * one kind of content (up to +1.5% smaller, plus fixing a real data-
 * corruption bug in the old single-shared-block design - see
 * NovaContainerFormat and BENCHMARKS.md), and cost nothing (down to a fixed
 * few bytes of format overhead) on files that don't. See BENCHMARKS.md for
 * the full sweep, including why [MIN_SEGMENT_SIZE] and
 * [ENTROPY_DELTA_THRESHOLD] were chosen and how sensitive the result is to
 * them (not very, within a reasonable range - the merge-vs-split trial
 * downstream in NovaContainerFormat already absorbs most of the risk of
 * proposing a boundary that turns out not to be worth it).
 */
object Segmenter {
    /** A structural-transition boundary is only honored once the current
     *  run has reached this many bytes - keeps a single noisy window from
     *  fragmenting the file into segments too small for their own block to
     *  pay for its framing overhead and model warm-up cost. Four analyzer
     *  windows' worth by construction, not a magic number - see class KDoc
     *  for how it was chosen. */
    const val MIN_SEGMENT_SIZE = 16 * 1024

    /** How far (bits/byte) a window's entropy has to drift from the
     *  current run's running average before it counts as a structural
     *  change on its own, independent of any [RegionKind] change - see
     *  class KDoc. */
    const val ENTROPY_DELTA_THRESHOLD = 1.0

    fun segment(regions: List<Region>): List<Segment> {
        if (regions.isEmpty()) return emptyList()

        val segments = ArrayList<Segment>()
        var runStart = regions[0].offset
        var runLength = regions[0].length
        var runStrategy = strategyFor(regions[0].kind)
        var runDominantKind = regions[0].kind
        var entropySum = regions[0].stats.entropy
        var windowCount = 1

        for (i in 1 until regions.size) {
            val r = regions[i]
            val s = strategyFor(r.kind)
            val runningAverage = entropySum / windowCount
            val strategyChanged = s != runStrategy
            val structuralChange = r.kind != runDominantKind ||
                kotlin.math.abs(r.stats.entropy - runningAverage) >= ENTROPY_DELTA_THRESHOLD
            val shouldSplit = strategyChanged || (structuralChange && runLength >= MIN_SEGMENT_SIZE)

            if (!shouldSplit) {
                runLength += r.length
                entropySum += r.stats.entropy
                windowCount++
            } else {
                segments.add(Segment(runStart, runLength, runStrategy, runDominantKind, entropySum / windowCount))
                runStart = r.offset
                runLength = r.length
                runStrategy = s
                runDominantKind = r.kind
                entropySum = r.stats.entropy
                windowCount = 1
            }
        }
        segments.add(Segment(runStart, runLength, runStrategy, runDominantKind, entropySum / windowCount))
        return segments
    }

    private fun strategyFor(kind: RegionKind): SegmentStrategy = when (kind) {
        RegionKind.ALREADY_COMPRESSED_OR_ENCRYPTED -> SegmentStrategy.STORE
        else -> SegmentStrategy.NOVA
    }
}
