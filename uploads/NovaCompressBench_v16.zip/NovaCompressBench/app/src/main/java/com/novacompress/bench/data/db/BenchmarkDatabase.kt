package com.novacompress.bench.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [BenchmarkResultEntity::class], version = 1, exportSchema = false)
abstract class BenchmarkDatabase : RoomDatabase() {
    abstract fun benchmarkResultDao(): BenchmarkResultDao

    companion object {
        @Volatile private var instance: BenchmarkDatabase? = null

        fun getInstance(context: Context): BenchmarkDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    BenchmarkDatabase::class.java,
                    "novacompress_bench.db",
                ).build().also { instance = it }
            }
    }
}
