package com.novacompress.bench.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.novacompress.bench.core.AlgorithmCategory
import com.novacompress.bench.core.BenchmarkMetrics
import com.novacompress.bench.core.VerificationResult

@Entity(tableName = "benchmark_results")
data class BenchmarkResultEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val algorithmId: String,
    val algorithmName: String,
    val category: String,
    val sourceFileName: String,
    val originalSizeBytes: Long,
    val compressedSizeBytes: Long,
    val compressionTimeMs: Long,
    val decompressionTimeMs: Long,
    val compressionCpuTimeMs: Long,
    val decompressionCpuTimeMs: Long,
    val peakMemoryDeltaBytes: Long,
    val verified: String,
    val timestampEpochMs: Long,
    val failureReason: String?,
) {
    fun toMetrics() = BenchmarkMetrics(
        algorithmId = algorithmId,
        algorithmName = algorithmName,
        category = AlgorithmCategory.valueOf(category),
        sourceFileName = sourceFileName,
        originalSizeBytes = originalSizeBytes,
        compressedSizeBytes = compressedSizeBytes,
        compressionTimeMs = compressionTimeMs,
        decompressionTimeMs = decompressionTimeMs,
        compressionCpuTimeMs = compressionCpuTimeMs,
        decompressionCpuTimeMs = decompressionCpuTimeMs,
        peakMemoryDeltaBytes = peakMemoryDeltaBytes,
        verified = VerificationResult.valueOf(verified),
        timestampEpochMs = timestampEpochMs,
        failureReason = failureReason,
    )

    companion object {
        fun fromMetrics(m: BenchmarkMetrics) = BenchmarkResultEntity(
            algorithmId = m.algorithmId,
            algorithmName = m.algorithmName,
            category = m.category.name,
            sourceFileName = m.sourceFileName,
            originalSizeBytes = m.originalSizeBytes,
            compressedSizeBytes = m.compressedSizeBytes,
            compressionTimeMs = m.compressionTimeMs,
            decompressionTimeMs = m.decompressionTimeMs,
            compressionCpuTimeMs = m.compressionCpuTimeMs,
            decompressionCpuTimeMs = m.decompressionCpuTimeMs,
            peakMemoryDeltaBytes = m.peakMemoryDeltaBytes,
            verified = m.verified.name,
            timestampEpochMs = m.timestampEpochMs,
            failureReason = m.failureReason,
        )
    }
}
