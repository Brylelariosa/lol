package com.novacompress.bench.algorithms

import com.novacompress.bench.core.AlgorithmCategory
import com.novacompress.bench.core.AlgorithmUnavailableException
import com.novacompress.bench.core.CompressionAlgorithm
import com.novacompress.bench.core.IoUtil
import org.brotli.dec.BrotliInputStream
import java.io.InputStream
import java.io.OutputStream

/**
 * Brotli decompression only.
 *
 * `org.brotli:dec` is a real, portable, pure-Java Brotli *decoder* published
 * by the Brotli project itself, so decompression here is genuine. There is
 * no equally standard portable-Java or prebuilt-Android *encoder* artifact
 * to depend on with confidence, and hand-rolling one is a substantial
 * undertaking in its own right (Brotli's encoder is considerably more
 * involved than its decoder). Rather than wire up an unverified encoder
 * dependency that might not resolve or work correctly, compression is left
 * as an explicit, documented gap - see README "Algorithm implementation
 * notes" for how to add a native encoder in a follow-up pass.
 */
class BrotliAlgorithm : CompressionAlgorithm {
    override val id = "brotli"
    override val displayName = "Brotli"
    override val category = AlgorithmCategory.STANDARD

    override fun isAvailable() = true // decoder is genuinely available

    override fun compress(input: InputStream, output: OutputStream) {
        throw AlgorithmUnavailableException(
            "Brotli encoding isn't included in this build (no verified portable " +
                "Android encoder dependency). Decompression works. See README."
        )
    }

    override fun decompress(input: InputStream, output: OutputStream) {
        BrotliInputStream(input).use { bis ->
            IoUtil.copyStream(bis, output)
        }
    }
}
