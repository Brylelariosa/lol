package com.novacompress.bench.benchmark

import android.os.Debug

object MemoryProfiler {
    fun currentUsedMemoryBytes(): Long {
        val rt = Runtime.getRuntime()
        return rt.totalMemory() - rt.freeMemory()
    }

    fun currentThreadCpuTimeMs(): Long = Debug.threadCpuTimeNanos() / 1_000_000L

    /**
     * Approximate memory delta around [block], via JVM heap used-memory
     * before/after with a forced GC boundary beforehand to reduce noise
     * from prior operations. This is inherently approximate - GC timing on
     * Android is nondeterministic and this measures one process's shared
     * heap, not an OS-level per-operation allocation trace - so treat it as
     * directional (useful for *comparing* algorithms in one run) rather
     * than an exact figure. See README "Benchmark measurement notes".
     */
    inline fun <T> measureMemoryDelta(block: () -> T): Pair<T, Long> {
        System.gc()
        val before = currentUsedMemoryBytes()
        val result = block()
        val after = currentUsedMemoryBytes()
        return result to maxOf(0L, after - before)
    }
}
