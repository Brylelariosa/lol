package com.novacompress.bench.algorithms

import com.novacompress.bench.core.AlgorithmCategory
import com.novacompress.bench.core.CompressionAlgorithm
import com.novacompress.bench.core.IoUtil
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.Deflater
import java.util.zip.DeflaterOutputStream
import java.util.zip.InflaterInputStream

/** Deflate (raw zlib-family), the same algorithm underlying ZIP. Built into
 *  every JVM/Android runtime - no external dependency, so this is the one
 *  backend guaranteed to work on every device. */
class DeflateAlgorithm : CompressionAlgorithm {
    override val id = "deflate"
    override val displayName = "Deflate (ZIP)"
    override val category = AlgorithmCategory.STANDARD

    override fun isAvailable() = true

    override fun compress(input: InputStream, output: OutputStream) {
        val deflater = Deflater(Deflater.BEST_COMPRESSION, false)
        DeflaterOutputStream(output, deflater, IoUtil.STREAM_BUFFER_SIZE).use { dos ->
            IoUtil.copyStream(input, dos)
        }
        deflater.end()
    }

    override fun decompress(input: InputStream, output: OutputStream) {
        InflaterInputStream(input, java.util.zip.Inflater(false), IoUtil.STREAM_BUFFER_SIZE).use { iis ->
            IoUtil.copyStream(iis, output)
        }
    }
}
