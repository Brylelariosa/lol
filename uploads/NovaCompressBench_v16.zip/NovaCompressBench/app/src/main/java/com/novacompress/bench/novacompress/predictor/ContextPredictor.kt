package com.novacompress.bench.novacompress.predictor

/**
 * Predicts the next byte from what's already been reconstructed, in three
 * tiers, each tried only when the one before has no confident answer:
 *
 * 1. Exact-context table: a bounded hash table of single (predicted-byte,
 *    confidence) slots keyed on the exact (prevPrev, prev) byte pair - a
 *    simplified, deterministic relative of Misra-Gries heavy-hitter
 *    counting, rather than a full per-context 256-way histogram (64K
 *    contexts x 256 counts would cost far more memory for limited extra
 *    benefit). Wins on data with recurring *exact* 2-byte contexts (text,
 *    repeated records/templates) - but a single early observation locks in
 *    a guess at confidence 1, and on data where 2-byte contexts are mostly
 *    one-off (tier 2's whole reason to exist) that guess is close to
 *    noise. [TIER1_MIN_CONFIDENCE] makes tier 1 prove itself - confirmed
 *    right at least twice, not just guessed once - before it can shadow
 *    tiers 2/3; testing on image-like data showed a single unconfirmed
 *    guess was blocking tier 2 on ~9 out of every 10 positions where tier
 *    2 actually had the better answer.
 * 2. Fixed-stride table: for a small set of candidate strides (2/3/4/8 -
 *    common record/pixel/word widths), tries *two* hypotheses per stride -
 *    "same value as `stride` back" (flat) and "the linear trend over the
 *    last two same-stride samples continues" (delta) - and uses whichever
 *    of the 2*4 candidates currently has the best track record. Flat wins
 *    on structured binary data with a fixed record width the matcher can't
 *    catch because it repeats byte-by-byte rather than in exact runs (e.g.
 *    interleaved image channels: byte N usually equals byte N-3, but
 *    rarely 4 bytes of that in a row - LongRangeMatcher's MIN_MATCH=4
 *    exact-run requirement never fires, but this does). Delta wins on the
 *    same kind of interleaved data when the channel is a smooth ramp
 *    rather than a flat run - measured on a synthetic gradient image, flat
 *    stride-3 predicted one channel correctly 0.4% of the time (it's
 *    almost never the same as the previous pixel) where delta stride-3 got
 *    98.8% (it almost always changes by the same amount each pixel).
 *    Without the delta hypothesis, tier 2 had no way to represent "this
 *    channel is trending", and MIN_MATCH=4 blocks the matcher from ever
 *    catching a single-byte-per-pixel ramp either, so that structure was
 *    invisible to the whole pipeline.
 * 3. Linear/delta fallback: predicted = 2*prev - prevPrev (mod 256) -
 *    assumes the current trend continues. Exact for constant-stride
 *    counters/gradients; a reasonable guess for anything smoothly-varying.
 *    Unlike tier 2's delta hypothesis, this looks at the immediately
 *    preceding bytes regardless of stride, so it only helps when *those*
 *    happen to be the meaningful sequence (e.g. non-interleaved data).
 *
 * A wrong guess here costs nothing beyond what an unpredicted literal
 * already costs - NovaSegmentCodec emits the literal byte value either
 * way, there's no separate "miss" symbol - so tiers 2 and 3 are pure
 * upside whenever tier 1 doesn't have a confirmed answer, which is why
 * this always returns *some* prediction rather than abstaining.
 *
 * Tier 2's scores are bounded by periodically halving all of them once any
 * one exceeds [RESCALE_THRESHOLD] - the same rescaling
 * [com.novacompress.bench.novacompress.entropy.FreqModel] uses for symbol
 * frequencies - rather than clamping each score at a fixed ceiling. A hard
 * clamp was the original design here, and it under-served exactly the case
 * tier 2 exists for: with a +4/-1 update, *any* candidate right more than
 * ~20% of the time keeps climbing indefinitely, so two candidates with very
 * different real accuracy (40% vs 83%, measured on the gradient image case
 * above) both saturate at the ceiling and become indistinguishable - the
 * choice between them degrades to noise well before the file ends. Halving
 * preserves relative order (the genuinely better candidate stays ahead)
 * while still bounding magnitude and adapting within a few thousand bytes
 * if the data's character changes - measured to adapt faster across a
 * regime change than the old hard clamp did, while also reaching much
 * higher steady-state accuracy once settled.
 *
 * This doubles as the spec's "Learning Component": every table here adapts
 * continuously as bytes stream through, with no cloud calls and no neural
 * network - just adaptive counters (plus the stateless linear fallback),
 * exactly as specified.
 *
 * Both encoder and decoder must call [update] after *every* reconstructed
 * byte (literals, prediction hits, and match-copied bytes alike) to stay in
 * lockstep - see NovaSegmentCodec, where this invariant is the single most
 * important correctness property of the whole pipeline. [predict] and
 * [update] only ever read [buffer] at indices strictly before [pos] - the
 * encoder (source data, already fully known) and the decoder (output
 * reconstructed so far) agree on every byte before [pos] by construction,
 * which is what keeps tier 2's stride lookups in lockstep too, the same way
 * tier 1's (prevPrev, prev) already was.
 */
class ContextPredictor {
    private val predicted = ByteArray(TABLE_SIZE)
    private val confidence = IntArray(TABLE_SIZE)
    private val flatScore = IntArray(STRIDES.size)
    private val deltaScore = IntArray(STRIDES.size)

    private fun hash(prevPrev: Int, prev: Int): Int {
        val h = (prevPrev * MIX_A) xor (prev * MIX_B)
        return (h xor (h ushr 15)) and MASK
    }

    fun predict(buffer: ByteArray, pos: Int, prevPrev: Int, prev: Int): Byte {
        val h = hash(prevPrev, prev)
        if (confidence[h] >= TIER1_MIN_CONFIDENCE) return predicted[h]

        var bestScore = 0
        var bestVal = 0
        var found = false
        for (i in STRIDES.indices) {
            val s = STRIDES[i]
            if (s <= pos && flatScore[i] > bestScore) {
                bestScore = flatScore[i]
                bestVal = buffer[pos - s].toInt() and 0xFF
                found = true
            }
            if (2 * s <= pos && deltaScore[i] > bestScore) {
                bestScore = deltaScore[i]
                val a = buffer[pos - s].toInt() and 0xFF
                val b = buffer[pos - 2 * s].toInt() and 0xFF
                bestVal = (2 * a - b) and 0xFF
                found = true
            }
        }
        if (found) return bestVal.toByte()

        return ((2 * prev - prevPrev) and 0xFF).toByte()
    }

    fun update(buffer: ByteArray, pos: Int, prevPrev: Int, prev: Int, actual: Byte) {
        val h = hash(prevPrev, prev)
        if (predicted[h] == actual) {
            if (confidence[h] < 1000) confidence[h]++
        } else {
            confidence[h]--
            if (confidence[h] <= 0) {
                predicted[h] = actual
                confidence[h] = 1
            }
        }
        // Every candidate (both hypotheses, every stride) learns from every
        // byte, regardless of which one predict() picked - a wrong guess
        // costs nothing, so there's no reason to only track the winner.
        var needsRescale = false
        for (i in STRIDES.indices) {
            val s = STRIDES[i]
            if (s <= pos) {
                val flatVal = buffer[pos - s]
                flatScore[i] = if (flatVal == actual) flatScore[i] + 4 else flatScore[i] - 1
                if (flatScore[i] > RESCALE_THRESHOLD || flatScore[i] < -RESCALE_THRESHOLD) needsRescale = true
            }
            if (2 * s <= pos) {
                val a = buffer[pos - s].toInt() and 0xFF
                val b = buffer[pos - 2 * s].toInt() and 0xFF
                val deltaVal = ((2 * a - b) and 0xFF).toByte()
                deltaScore[i] = if (deltaVal == actual) deltaScore[i] + 4 else deltaScore[i] - 1
                if (deltaScore[i] > RESCALE_THRESHOLD || deltaScore[i] < -RESCALE_THRESHOLD) needsRescale = true
            }
        }
        if (needsRescale) {
            for (i in STRIDES.indices) {
                flatScore[i] /= 2
                deltaScore[i] /= 2
            }
        }
    }

    companion object {
        private const val TABLE_SIZE = 1 shl 16
        private const val MASK = TABLE_SIZE - 1
        // Odd mixing constants for hash dispersion (bit patterns of
        // 0x9E3779B1 / 0x85EBCA77 written as signed decimals to avoid any
        // hex-literal Int/Long inference ambiguity). Only affects hash
        // spread/compression efficiency, not correctness - decoder and
        // encoder always compute the same value for the same context.
        private const val MIX_A = -1640531535
        private const val MIX_B = -2048144777

        private const val TIER1_MIN_CONFIDENCE = 3
        private const val RESCALE_THRESHOLD = 1500
        private val STRIDES = intArrayOf(2, 3, 4, 8)
    }
}
