package com.novacompress.bench.novacompress.matcher

sealed class Token {
    data class Literal(val byte: Byte) : Token()
    data class Match(val distance: Int, val length: Int) : Token()

    companion object {
        // Literal tokens vastly outnumber Match tokens on typical content (e.g. ~82% of all
        // tokens on the real-device GBA ROM benchmark - see BENCHMARKS.md Entry 6), and a
        // Literal is fully described by its one immutable Byte field, so every possible instance
        // can be precomputed once instead of allocated per occurrence. [literalOf] is the only
        // place that should construct a [Literal] outside this cache; [LongRangeMatcher] uses it
        // for every literal it emits.
        private val LITERAL_CACHE: Array<Literal> = Array(256) { Literal(it.toByte()) }

        fun literalOf(byte: Byte): Literal = LITERAL_CACHE[byte.toInt() and 0xFF]
    }
}
