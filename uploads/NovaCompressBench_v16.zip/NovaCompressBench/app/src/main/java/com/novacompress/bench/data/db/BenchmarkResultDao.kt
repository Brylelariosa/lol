package com.novacompress.bench.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface BenchmarkResultDao {
    @Insert
    suspend fun insertAll(results: List<BenchmarkResultEntity>)

    @Query("SELECT * FROM benchmark_results ORDER BY timestampEpochMs DESC")
    fun observeAll(): Flow<List<BenchmarkResultEntity>>

    @Query("SELECT * FROM benchmark_results WHERE sourceFileName = :fileName ORDER BY timestampEpochMs DESC")
    fun observeForFile(fileName: String): Flow<List<BenchmarkResultEntity>>

    @Query("SELECT DISTINCT sourceFileName FROM benchmark_results ORDER BY timestampEpochMs DESC")
    fun observeDistinctFileNames(): Flow<List<String>>

    @Delete
    suspend fun delete(result: BenchmarkResultEntity)

    @Query("DELETE FROM benchmark_results")
    suspend fun clearAll()
}
