package com.novacompress.bench.benchmark

import java.io.InputStream

/** A file-like input the benchmark runner can read repeatedly (once for
 *  compression, once more for the original-file SHA-256 used in
 *  verification). Implementations should open a fresh stream each call. */
interface BenchmarkSource {
    val displayName: String
    val sizeBytes: Long
    fun openStream(): InputStream
}
