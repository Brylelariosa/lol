package com.novacompress.bench.dataset

import com.novacompress.bench.benchmark.BenchmarkSource
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.security.SecureRandom
import kotlin.random.Random

data class SampleDataset(
    val name: String,
    val description: String,
    val bytes: ByteArray,
) : BenchmarkSource {
    override val displayName: String get() = name
    override val sizeBytes: Long get() = bytes.size.toLong()
    override fun openStream(): InputStream = ByteArrayInputStream(bytes)
}

/**
 * Built-in test files covering the entropy/structure spectrum the spec
 * asks to test against (text, structured records, high-entropy/"already
 * compressed", tabular/repetitive, image-like, executable-like) - without
 * bundling real copyrighted ROMs, APKs, or media. These are clearly labeled
 * synthetic fixtures for quick benchmarking; for real-world files (actual
 * APKs, ROMs, PDFs, video, etc.) the Home screen's file picker is the
 * intended path.
 */
object SampleDatasetGenerator {
    fun textLike(sizeBytes: Int = 256 * 1024): SampleDataset {
        val words = listOf(
            "the", "quick", "brown", "fox", "jumps", "over", "lazy", "dog", "compression",
            "algorithm", "research", "benchmark", "dictionary", "entropy", "segment", "pattern",
        )
        val r = Random(1)
        val sb = StringBuilder(sizeBytes + 32)
        while (sb.length < sizeBytes) {
            sb.append(words[r.nextInt(words.size)]).append(' ')
            if (r.nextInt(20) == 0) sb.append('\n')
        }
        return SampleDataset(
            "synthetic_text.txt",
            "Synthetic English-like text (word-soup, not real prose) - favors long-range matching and prediction.",
            sb.toString().substring(0, sizeBytes).toByteArray(Charsets.US_ASCII),
        )
    }

    fun jsonRecords(sizeBytes: Int = 256 * 1024): SampleDataset {
        val r = Random(2)
        val names = listOf("alice", "bob", "carol", "dave", "erin", "frank")
        val sb = StringBuilder(sizeBytes + 256)
        var id = 0
        while (sb.length < sizeBytes) {
            sb.append("{\"id\":").append(id++)
                .append(",\"user\":\"").append(names[r.nextInt(names.size)])
                .append("\",\"active\":").append(r.nextBoolean())
                .append(",\"score\":").append(r.nextInt(1000))
                .append("}\n")
        }
        return SampleDataset(
            "synthetic_records.json",
            "Synthetic repeated JSON records with varying fields - exercises structural pattern detection.",
            sb.toString().substring(0, sizeBytes).toByteArray(Charsets.US_ASCII),
        )
    }

    fun highEntropyRandom(sizeBytes: Int = 256 * 1024): SampleDataset {
        val bytes = ByteArray(sizeBytes)
        SecureRandom().nextBytes(bytes)
        return SampleDataset(
            "synthetic_random.bin",
            "Cryptographically random bytes - simulates already-compressed/encrypted content. No general-purpose compressor can shrink this; NovaCompress's segmenter is expected to fall back to STORE here.",
            bytes,
        )
    }

    fun repetitiveTable(sizeBytes: Int = 256 * 1024): SampleDataset {
        val r = Random(3)
        val out = ByteArrayOutputStream(sizeBytes + 64)
        val record = ByteArray(24)
        var i = 0
        while (out.size() < sizeBytes) {
            for (k in record.indices) record[k] = ((k * 7 + i) and 0xFF).toByte()
            record[5] = r.nextInt(256).toByte() // one varying "payload" field per record
            out.write(record)
            i++
        }
        val full = out.toByteArray()
        return SampleDataset(
            "synthetic_table.bin",
            "Synthetic fixed-stride records with one varying field per record - simulates tabular/database-like binary data.",
            full.copyOf(sizeBytes),
        )
    }

    /** A real, valid, uncompressed 24-bit BMP - not a copy of any existing image, generated pixel by pixel. */
    fun syntheticBmpImage(width: Int = 256, height: Int = 256): SampleDataset {
        val rowSize = ((width * 3 + 3) / 4) * 4
        val pixelDataSize = rowSize * height
        val fileSize = 54 + pixelDataSize
        val out = ByteArrayOutputStream(fileSize)

        fun writeLE(v: Int, bytes: Int) {
            var x = v
            repeat(bytes) { out.write(x and 0xFF); x = x ushr 8 }
        }

        out.write('B'.code); out.write('M'.code)
        writeLE(fileSize, 4)
        writeLE(0, 4)
        writeLE(54, 4)
        writeLE(40, 4)
        writeLE(width, 4)
        writeLE(height, 4)
        writeLE(1, 2)
        writeLE(24, 2)
        writeLE(0, 4)
        writeLE(pixelDataSize, 4)
        writeLE(2835, 4)
        writeLE(2835, 4)
        writeLE(0, 4)
        writeLE(0, 4)

        for (y in 0 until height) {
            var rowBytes = 0
            for (x in 0 until width) {
                // simple concentric-ring gradient plus a repeating tile pattern,
                // giving both smooth and repetitive regions like a real image
                val dx = x - width / 2
                val dy = y - height / 2
                val ring = (Math.sqrt((dx * dx + dy * dy).toDouble()) * 2).toInt() and 0xFF
                val tile = ((x / 16 + y / 16) % 2) * 40
                val r8 = (ring + tile).coerceIn(0, 255)
                val g8 = ((x * 255) / width)
                val b8 = ((y * 255) / height)
                out.write(b8); out.write(g8); out.write(r8)
                rowBytes += 3
            }
            while (rowBytes < rowSize) { out.write(0); rowBytes++ }
        }

        return SampleDataset(
            "synthetic_image.bmp",
            "A generated (not copied) 24-bit BMP with a gradient plus a repeating tile pattern - real, valid image bytes without any copyrighted source image.",
            out.toByteArray(),
        )
    }

    fun executableLikePadded(sizeBytes: Int = 256 * 1024): SampleDataset {
        // Not a real ELF/APK/DEX - synthetic bytes mimicking typical compiled
        // code characteristics: moderate entropy with recurring short
        // "opcode-like" patterns and null-padded alignment gaps.
        val r = Random(4)
        val out = ByteArrayOutputStream(sizeBytes + 64)
        val opcodes = listOf(
            byteArrayOf(0x55, 0x48, 0x89.toByte(), 0xE5.toByte()),
            byteArrayOf(0x48, 0x83.toByte(), 0xEC.toByte(), 0x10),
            byteArrayOf(0xC3.toByte()),
            byteArrayOf(0x89.toByte(), 0x45.toByte(), 0xFC.toByte()),
        )
        while (out.size() < sizeBytes) {
            out.write(opcodes[r.nextInt(opcodes.size)])
            if (r.nextInt(3) == 0) out.write(r.nextInt(256)) // operand-like random byte
            if (r.nextInt(32) == 0) repeat(r.nextInt(8)) { out.write(0) } // alignment padding
        }
        return SampleDataset(
            "synthetic_executable.bin",
            "Synthetic byte patterns mimicking compiled-code characteristics (repeated short sequences, null-padded alignment) - not a real executable.",
            out.toByteArray().copyOf(sizeBytes),
        )
    }

    fun all(): List<SampleDataset> = listOf(
        textLike(), jsonRecords(), highEntropyRandom(), repetitiveTable(), syntheticBmpImage(), executableLikePadded(),
    )
}
