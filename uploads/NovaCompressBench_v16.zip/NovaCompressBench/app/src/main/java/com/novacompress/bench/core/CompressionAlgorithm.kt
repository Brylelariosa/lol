package com.novacompress.bench.core

import java.io.InputStream
import java.io.OutputStream

/**
 * Category distinguishes established codecs from the experimental one so the
 * UI and benchmark reports can group/label them without string matching.
 */
enum class AlgorithmCategory { STANDARD, EXPERIMENTAL }

/**
 * A single lossless compression backend.
 *
 * Implementations MUST be streaming: [compress] and [decompress] should
 * consume [input] and produce [output] in bounded-size chunks rather than
 * buffering the whole payload in memory, so a single run can handle files
 * far larger than available RAM (see README "Streaming and large files").
 *
 * Implementations MUST be safe to call [isAvailable] before any real work -
 * several backends are native-library-backed (zstd, lz4, snappy) and can
 * fail to load on a given device/ABI. Callers should treat unavailability as
 * a normal, reportable benchmark outcome, not a crash.
 */
interface CompressionAlgorithm {
    val id: String
    val displayName: String
    val category: AlgorithmCategory

    /** Cheap capability check; must not throw. */
    fun isAvailable(): Boolean

    /** Compresses [input] fully into [output]. Streams internally. */
    @Throws(Exception::class)
    fun compress(input: InputStream, output: OutputStream)

    /** Decompresses [input] fully into [output]. Streams internally. */
    @Throws(Exception::class)
    fun decompress(input: InputStream, output: OutputStream)
}

/** Thrown by [CompressionAlgorithm] implementations that are structurally
 *  present (linked into the app) but non-functional on this device/build,
 *  e.g. a native encoder that isn't available for this ABI. */
class AlgorithmUnavailableException(message: String) : Exception(message)
