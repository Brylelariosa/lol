package com.novacompress.bench.core

import java.io.InputStream
import java.io.OutputStream

object IoUtil {
    /** 256KB strikes a reasonable balance for on-device streaming: large
     *  enough to avoid excessive syscall/JNI-crossing overhead, small enough
     *  to keep peak memory bounded even for 10GB+ inputs. */
    const val STREAM_BUFFER_SIZE = 256 * 1024

    fun copyStream(input: InputStream, output: OutputStream, bufferSize: Int = STREAM_BUFFER_SIZE): Long {
        val buffer = ByteArray(bufferSize)
        var total = 0L
        while (true) {
            val read = input.read(buffer)
            if (read == -1) break
            output.write(buffer, 0, read)
            total += read
        }
        return total
    }
}
