# Native-backed compression libraries resolve classes/methods via JNI or
# reflection; keep them intact under R8/ProGuard minification.
-keep class com.github.luben.zstd.** { *; }
-keep class org.lz4.** { *; }
-keep class org.xerial.snappy.** { *; }
-keep class org.brotli.dec.** { *; }
-keep class org.tukaani.xz.** { *; }
-keep class org.apache.commons.compress.** { *; }
-dontwarn org.apache.commons.compress.**

# snappy-java bundles an optional OSGi activator (SnappyBundleActivator) for
# use inside OSGi containers. It's dead code on Android - never registered
# or invoked - but the -keep rule above forces R8 to resolve the classes it
# references. org.osgi.framework.* isn't on the classpath (no OSGi runtime
# in an Android app), so R8's missing-class check hard-fails the build
# unless we tell it these are safe to ignore.
-dontwarn org.osgi.framework.BundleActivator
-dontwarn org.osgi.framework.BundleContext

# NovaCompress container/model classes are (de)serialized by field layout in
# places; keep field names stable for debuggability.
-keepclassmembers class com.novacompress.bench.novacompress.** { *; }
-keepclassmembers class com.novacompress.bench.data.db.** { *; }
